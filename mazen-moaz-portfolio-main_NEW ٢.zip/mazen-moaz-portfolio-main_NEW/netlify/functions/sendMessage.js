
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const { name, contact, message } = JSON.parse(event.body);
  const { TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID } = process.env;

  const text = `
🚀 *New Inquiry from Portfolio*
👤 *Name:* ${name}
📱 *Contact:* ${contact}
💬 *Message:* 
${message}
  `;

  try {
    const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHAT_ID,
        text,
        parse_mode: 'Markdown',
      }),
    });

    if (response.ok) {
      return { statusCode: 200, body: 'Message sent successfully!' };
    } else {
      return { statusCode: 500, body: 'Failed to send message' };
    }
  } catch (error) {
    return { statusCode: 500, body: 'Failed to send message' };
  }
};
