import React from "react";
import PremiumPortfolio from "@/components/PremiumPortfolio";

const Index = () => {
  return (
    <PremiumPortfolio />
  );
};

export default Index;
