import { motion } from "framer-motion";
import { MessageSquare, Zap, Search, Globe, Palette, Megaphone } from "lucide-react";

const services = [
  {
    icon: <MessageSquare className="text-primary" />,
    title: "Telegram Bot Development",
    desc: "Custom automated bots for management, customer support, and specialized business operations.",
  },
  {
    icon: <Zap className="text-accent" />,
    title: "Automation Tools",
    desc: "Streamline your repetitive tasks with custom scripts and tools designed for maximum efficiency.",
  },
  {
    icon: <Search className="text-primary" />,
    title: "Web Scraping",
    desc: "Extract valuable data from across the web with high-performance scraping solutions.",
  },
  {
    icon: <Globe className="text-accent" />,
    title: "API Integration",
    desc: "Seamlessly connect your platforms with professional third-party API implementation.",
  },
  {
    icon: <Palette className="text-primary" />,
    title: "Graphic Design",
    desc: "Professional branding, logos, and high-impact visual identity for your business.",
  },
  {
    icon: <Megaphone className="text-accent" />,
    title: "Ads & Social Media",
    desc: "Visually engaging social media creatives and high-conversion ad designs.",
  },
];

const ServicesSection = () => {
  return (
    <section id="services" className="section-padding relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-0 w-72 h-72 bg-primary/10 rounded-full blur-[100px] -translate-y-1/2" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-primary font-bold uppercase tracking-[0.3em] text-sm"
          >
            Services
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="font-display font-black text-4xl md:text-6xl mt-4"
          >
            How I Can <span className="text-gradient">Help You</span>
          </motion.h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, idx) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -10, scale: 1.02 }}
              className="glass p-10 rounded-[2.5rem] border-white/5 hover:border-primary/30 transition-all duration-500 group"
            >
              <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mb-8 group-hover:bg-primary/20 group-hover:rotate-6 transition-all duration-500">
                {service.icon}
              </div>
              <h3 className="font-display font-black text-2xl mb-4 group-hover:text-primary transition-colors">
                {service.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {service.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
