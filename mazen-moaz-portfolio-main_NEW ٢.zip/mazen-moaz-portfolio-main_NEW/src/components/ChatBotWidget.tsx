import { useState } from "react";
import { MessageCircle, X, Send, Bot } from "lucide-react";

const quickReplies = ["Tell me about your services", "How can AI help my business?", "Let's discuss a project"];

const botResponses: Record<string, string> = {
  "Tell me about your services": "I specialize in three core areas: AI Automation (chatbots & workflows), Digital Marketing & SEO (Meta/Google Ads, content strategy), and Graphic Design (branding & visual identity). Want to dive deeper into any of these?",
  "How can AI help my business?": "AI can automate your customer support 24/7, qualify leads automatically, personalize marketing campaigns, and reduce operational costs by up to 40%. I build custom AI solutions tailored to your business needs.",
  "Let's discuss a project": "I'd love to! Please reach out via email at moazmazen21@gmail.com or use the contact section below. I typically respond within 24 hours with a free consultation offer.",
};

const ChatBotWidget = () => {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<{ text: string; from: "bot" | "user" }[]>([
    { text: "Hi! 👋 I'm Mazen's AI assistant. How can I help you today?", from: "bot" },
  ]);
  const [input, setInput] = useState("");

  const sendMessage = (text: string) => {
    setMessages((prev) => [...prev, { text, from: "user" }]);
    setTimeout(() => {
      const reply = botResponses[text] || "Thanks for your message! For detailed inquiries, please email moazmazen21@gmail.com — Mazen will get back to you shortly.";
      setMessages((prev) => [...prev, { text: reply, from: "bot" }]);
    }, 800);
  };

  const handleSend = () => {
    if (!input.trim()) return;
    sendMessage(input.trim());
    setInput("");
  };

  return (
    <>
      {/* Toggle */}
      <button
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg animate-pulse-glow hover:scale-110 transition-transform"
      >
        {open ? <X size={22} /> : <MessageCircle size={22} />}
      </button>

      {/* Chat */}
      {open && (
        <div className="fixed bottom-24 right-6 z-50 w-80 sm:w-96 glass neon-border rounded-2xl overflow-hidden flex flex-col animate-fade-up" style={{ maxHeight: "28rem" }}>
          {/* Header */}
          <div className="px-5 py-4 border-b border-border flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
              <Bot size={16} className="text-primary" />
            </div>
            <div>
              <p className="font-display font-semibold text-sm">Mazen's AI Assistant</p>
              <p className="text-xs text-muted-foreground">Simulated Bot Demo</p>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3" style={{ maxHeight: "16rem" }}>
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.from === "user" ? "justify-end" : "justify-start"}`}>
                <div className={`max-w-[80%] px-4 py-2.5 rounded-xl text-sm leading-relaxed ${m.from === "user" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>
                  {m.text}
                </div>
              </div>
            ))}
          </div>

          {/* Quick replies */}
          <div className="px-4 pb-2 flex flex-wrap gap-2">
            {quickReplies.map((q) => (
              <button
                key={q}
                onClick={() => sendMessage(q)}
                className="text-xs px-3 py-1.5 rounded-full neon-border text-muted-foreground hover:text-primary transition-colors"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Input */}
          <div className="px-4 pb-4 flex gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              placeholder="Type a message..."
              className="flex-1 px-4 py-2.5 rounded-lg bg-muted border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            />
            <button onClick={handleSend} className="w-10 h-10 rounded-lg bg-primary text-primary-foreground flex items-center justify-center hover:opacity-90 transition-opacity">
              <Send size={16} />
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default ChatBotWidget;
