import { ArrowDown, Sparkles, Send, Briefcase, FileDown } from "lucide-react";
import { motion } from "framer-motion";

const HeroSection = () => {
  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  const handleDownloadCV = () => {
    const link = document.createElement('a');
    link.href = '/Mazen Moaz - CV.pdf';
    link.download = 'Mazen Moaz - CV.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center section-padding pt-28 overflow-hidden">
      {/* Background grid */}
      <div className="absolute inset-0 opacity-[0.05]" style={{
        backgroundImage: "linear-gradient(hsl(199 89% 58% / 0.3) 1px, transparent 1px), linear-gradient(90deg, hsl(199 89% 58% / 0.3) 1px, transparent 1px)",
        backgroundSize: "60px 60px"
      }} />
      
      {/* Premium Glow orbs */}
      <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-primary/20 rounded-full blur-[140px] animate-pulse-glow" />
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] bg-accent/20 rounded-full blur-[140px] animate-pulse-glow" style={{ animationDelay: "2s" }} />

      <div className="container mx-auto text-center relative z-10">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="inline-flex items-center gap-2 px-6 py-2 rounded-full glass border border-primary/20 mb-8 hover:border-primary/40 transition-all cursor-default shadow-lg shadow-primary/5"
        >
          <Sparkles size={16} className="text-primary animate-pulse" />
          <span className="text-sm font-bold text-primary uppercase tracking-[0.2em]">Automation & Creative Developer</span>
        </motion.div>

        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="font-display font-black text-5xl sm:text-6xl md:text-8xl leading-[1.1] mb-6 tracking-tight"
        >
          Building <span className="text-gradient">Intelligent</span><br />
          Automation Tools.
        </motion.h1>

        <motion.p 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-lg md:text-2xl text-muted-foreground max-w-3xl mx-auto mb-12 font-medium leading-relaxed"
        >
          I build Telegram bots, automation tools, and high-quality visual designs for brands and businesses.
        </motion.p>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col sm:flex-row gap-6 justify-center"
        >
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: "0 0 30px hsl(199 89% 58% / 0.5)" }}
            whileTap={{ scale: 0.95 }}
            onClick={() => scrollTo("web-projects")}
            className="px-10 py-4 rounded-2xl bg-primary text-primary-foreground font-display font-black text-lg flex items-center justify-center gap-3 transition-all duration-300 shadow-xl shadow-primary/20"
          >
            <Briefcase size={20} />
            View Projects
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.05, backgroundColor: "rgba(255, 255, 255, 0.08)" }}
            whileTap={{ scale: 0.95 }}
            onClick={handleDownloadCV}
            className="px-10 py-4 rounded-2xl glass border border-white/10 text-foreground font-display font-black text-lg flex items-center justify-center gap-3 transition-all duration-300"
          >
            <FileDown size={20} />
            Download CV
          </motion.button>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          onClick={() => scrollTo("about")}
          className="mt-20 inline-flex animate-bounce text-muted-foreground hover:text-primary transition-colors p-3 rounded-full bg-primary/5 border border-primary/10"
        >
          <ArrowDown size={32} />
        </motion.button>
      </div>
    </section>
  );
};

export default HeroSection;
