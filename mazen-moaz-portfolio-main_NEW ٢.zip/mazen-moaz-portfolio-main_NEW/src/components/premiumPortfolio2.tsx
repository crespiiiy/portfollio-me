import React, { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, AnimatePresence, useSpring } from 'framer-motion';
import { Dialog, DialogContent, DialogTitle } from './ui/dialog';
import { AspectRatio } from './ui/aspect-ratio';
import heroImage from '../assets/hero.jpg';
import project1 from '../assets/project1.png';
import project2 from '../assets/project2.png';
import project3 from '../assets/project3.png';
import project4 from '../assets/project4.png';
import { 
  Code2, 
  Bot, 
  Palette, 
  Zap, 
  Globe, 
  Database, 
  Cpu, 
  Layers,
  Send,
  Github,
  Linkedin,
  Twitter,
  Mail,
  ExternalLink,
  ChevronRight,
  Menu,
  X,
  Sparkles,
  Terminal,
  Figma,
  FileCode,
  ZoomIn,
  Play,
  FileDown,
  Shield,
  ShoppingCart,
  Layout,
  Users
} from 'lucide-react';

// Import all images from specified directories
const photos1 = import.meta.glob('../photos 1/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, import: 'default' });
const photos2 = import.meta.glob('../photos 2/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, import: 'default' });
const photos3 = import.meta.glob('../photos 3/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, import: 'default' });
const photos4 = import.meta.glob('../photos 4/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, import: 'default' });
const photos5 = import.meta.glob('../photos 5/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, import: 'default' });
const photos6 = import.meta.glob('../photos 6/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, import: 'default' });

const processPhotos = (photoGlob) => {
  return Object.keys(photoGlob)
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }))
    .map(path => photoGlob[path]);
};

const portfolioSections = [
  { title: "Design & Branding Projects", photos: processPhotos(photos1) },
  { title: "Digital Marketing Showcase", photos: processPhotos(photos2) },
  { title: "Creative Visual Works", photos: processPhotos(photos3) },
  { title: "Professional Portfolio", photos: processPhotos(photos4) },
  { title: "Recent Achievements", photos: [...processPhotos(photos5), ...processPhotos(photos6)] },
];

const aiVideos = [
  { url: '/videos/video_2026-03-24_08-35-46.mp4', title: 'AI Video Creation 1', description: 'Automated video generation based on text prompts.' },
  { url: '/videos/video_2026-03-24_08-35-54.mp4', title: 'AI Video Creation 2', description: 'AI-powered video editing and effects.' },
  { url: '/videos/video_2026-03-24_08-35-59.mp4', title: 'AI Video Creation 3', description: 'Generative video art from still images.' },
  { url: '/videos/video_2026-03-24_08-36-05.mp4', title: 'AI Video Creation 4', description: 'AI-driven character animation.' },
  { url: '/videos/video_2026-03-24_08-36-13.mp4', title: 'AI Video Creation 5', description: 'Dynamic video synthesis from data.' },
];

// ==========================================
// 🎨 DESIGN SYSTEM
// ==========================================

const colors = {
  primary: '#6366f1',      // Indigo
  secondary: '#8b5cf6',    // Violet
  accent: '#06b6d4',       // Cyan
  background: '#0a0a0f',   // Deep space
  surface: '#13131f',      // Glass base
  text: '#f8fafc',         // White
  muted: '#94a3b8',        // Slate
  success: '#10b981',      // Emerald
  warning: '#f59e0b',      // Amber
};

const projects = [
  {
    id: 1,
    title: "GreenHats Omega",
    url: "https://greenhats-omega.vercel.app/",
    category: "Cybersecurity",
    description: "Advanced AI Platform for cybersecurity professionals, featuring vulnerability analysis and security script generation.",
    tech: ["AI/ML", "React", "Next.js", "Cybersecurity"],
    icon: Shield,
    image: project1,
    featured: true
  },
  {
    id: 2,
    title: "Creative Snowy",
    url: "https://creative-snowy.vercel.app/",
    category: "Landing Page",
    description: "Modern premium business landing page showcasing creative tools and professional digital products.",
    tech: ["Modern UI", "Vite", "Tailwind CSS", "Responsive"],
    icon: Layout,
    image: project2,
    featured: false
  },
  {
    id: 3,
    title: "StoreOneCool",
    url: "http://storeonecool.netlify.app",
    category: "E-Commerce",
    description: "Specialized HVAC systems and cooling solutions e-commerce storefront for GREE authorized distribution.",
    tech: ["E-Commerce", "Product Catalog", "Cart System", "Business"],
    icon: ShoppingCart,
    image: project3,
    featured: false
  },
  {
    id: 4,
    title: "LinkedConnectPro",
    url: "https://linkedconnectpro.netlify.app/",
    category: "Social",
    description: "Professional networking platform designed to enhance LinkedIn growth and professional connectivity.",
    tech: ["Networking", "AI Targeting", "Analytics", "Marketing"],
    icon: Users,
    image: project4,
    featured: false
  },
  {
    id: 5,
    title: "GreenHats Platform",
    url: "https://greenhats.netlify.app/",
    category: "Cybersecurity",
    description: "Comprehensive community hub and tools platform for ethical hackers and security researchers.",
    tech: ["Encryption", "Security Tools", "Community", "React"],
    icon: Shield,
    image: "",
    featured: false
  },
  {
    id: 6,
    title: "StoreLuxe",
    url: "https://storeluxe.netlify.app/",
    category: "E-Commerce",
    description: "Premium luxury fashion and lifestyle e-commerce experience with curated signature pieces.",
    tech: ["Fashion UI", "Lifestyle", "Modern Design", "E-Commerce"],
    icon: ShoppingCart,
    image: "",
    featured: false
  },
  {
    id: 7,
    title: "TikTok VPN Gift",
    url: "https://tiktokvpn.netlify.app",
    category: "Social",
    description: "Specialized platform for TikTok account growth, live support, and gift management center.",
    tech: ["Social Media", "Support Center", "Live Boost", "Digital Growth"],
    icon: Globe,
    image: "",
    featured: false
  },
];

const projectCategories = ["All", "Cybersecurity", "E-Commerce", "Landing Page", "Social"];

const skills = [
  { name: "Bot Development", level: 95, icon: Bot, color: "from-violet-500 to-purple-600" },
  { name: "Web Development", level: 90, icon: Code2, color: "from-cyan-500 to-blue-600" },
  { name: "UI/UX Design", level: 88, icon: Palette, color: "from-pink-500 to-rose-600" },
  { name: "Automation", level: 92, icon: Zap, color: "from-amber-500 to-orange-600" },
  { name: "API Integration", level: 85, icon: Layers, color: "from-emerald-500 to-teal-600" },
  { name: "Data Scraping", level: 87, icon: Database, color: "from-indigo-500 to-violet-600" },
];

const services = [
  {
    icon: Bot,
    title: "Telegram Bot Development",
    description: "Custom automated bots for management, customer support, and specialized business operations",
    features: ["24/7 Uptime", "Scalable Architecture", "AI Integration"]
  },
  {
    icon: Zap,
    title: "Automation Tools",
    description: "Streamline repetitive tasks with custom scripts designed for maximum efficiency",
    features: ["Process Optimization", "Workflow Automation", "Error Handling"]
  },
  {
    icon: Database,
    title: "Web Scraping",
    description: "Extract valuable data with high-performance scraping solutions",
    features: ["Proxy Rotation", "Data Cleaning", "API Endpoints"]
  },
  {
    icon: Globe,
    title: "API Integration",
    description: "Seamlessly connect platforms with professional third-party implementations",
    features: ["REST/GraphQL", "Authentication", "Rate Limiting"]
  },
  {
    icon: Palette,
    title: "Graphic Design",
    description: "Professional branding, logos, and visual identity systems",
    features: ["Brand Strategy", "Visual Systems", "Print & Digital"]
  },
  {
    icon: Sparkles,
    title: "AI Content Creation",
    description: "Cutting-edge AI-generated visuals and video content",
    features: ["Image Generation", "Video Editing", "Motion Graphics"]
  }
];

const timeline = [
  {
    year: "2020 - Present",
    role: "Freelance Digital Specialist",
    company: "Independent",
    description: "Delivering end-to-end digital solutions including web development, digital marketing, and graphic design. 50+ projects completed."
  },
  {
    year: "2023 - Present",
    role: "Marketing Specialist",
    company: "One Cool Qatar",
    description: "Leading full-spectrum digital marketing campaigns, managing social media strategy, SEO, and paid advertising."
  },
  {
    year: "2021 - 2023",
    role: "Customer Service Representative",
    company: "Vodafone Cash",
    description: "Provided high-stakes financial customer support, mastering objection handling and retention techniques."
  },
  {
    year: "2019 - 2021",
    role: "Technical Support Specialist",
    company: "Uber (Middle East)",
    description: "Delivered technical support for the Middle East region, resolving complex issues across high-volume environment."
  }
];

// ==========================================
// 🧩 COMPONENTS
// ==========================================

const ParticleBackground = () => {
  const canvasRef = useRef(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let animationFrameId;
    let particles = [];
    
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    class Particle {
      constructor() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.size = Math.random() * 2 + 0.5;
        this.speedX = Math.random() * 0.5 - 0.25;
        this.speedY = Math.random() * 0.5 - 0.25;
        this.opacity = Math.random() * 0.5 + 0.1;
      }
      
      update() {
        this.x += this.speedX;
        this.y += this.speedY;
        
        if (this.x > canvas.width) this.x = 0;
        if (this.x < 0) this.x = canvas.width;
        if (this.y > canvas.height) this.y = 0;
        if (this.y < 0) this.y = canvas.height;
      }
      
      draw() {
        ctx.fillStyle = `rgba(99, 102, 241, ${this.opacity})`;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    
    const init = () => {
      particles = [];
      for (let i = 0; i < 50; i++) {
        particles.push(new Particle());
      }
    };
    
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      particles.forEach(particle => {
        particle.update();
        particle.draw();
      });
      
      // Connect particles
      particles.forEach((a, i) => {
        particles.slice(i + 1).forEach(b => {
          const dx = a.x - b.x;
          const dy = a.y - b.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance < 150) {
            ctx.strokeStyle = `rgba(99, 102, 241, ${0.1 * (1 - distance / 150)})`;
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(a.x, a.y);
            ctx.lineTo(b.x, b.y);
            ctx.stroke();
          }
        });
      });
      
      animationFrameId = requestAnimationFrame(animate);
    };
    
    resize();
    init();
    animate();
    
    window.addEventListener('resize', resize);
    
    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);
  
  return (
    <canvas 
      ref={canvasRef} 
      className="fixed inset-0 pointer-events-none z-0"
      style={{ opacity: 0.6 }}
    />
  );
};

const ProjectThumbnail = React.memo(({ title, category, customStyle }) => {
  const getTheme = () => {
    const themes = [
      { bg: 'from-indigo-600 to-violet-700', text: 'text-white', accent: 'bg-cyan-400' },
      { bg: 'from-emerald-600 to-teal-700', text: 'text-white', accent: 'bg-yellow-400' },
      { bg: 'from-rose-600 to-pink-700', text: 'text-white', accent: 'bg-indigo-300' },
      { bg: 'from-amber-500 to-orange-600', text: 'text-white', accent: 'bg-blue-400' },
      { bg: 'from-blue-600 to-cyan-700', text: 'text-white', accent: 'bg-emerald-300' },
      { bg: 'from-purple-600 to-fuchsia-700', text: 'text-white', accent: 'bg-green-400' }
    ];
    
    // Simple hash based on title
    let hash = 0;
    for (let i = 0; i < title.length; i++) {
      hash = title.charCodeAt(i) + ((hash << 5) - hash);
    }
    return themes[Math.abs(hash) % themes.length];
  };

  const theme = customStyle || getTheme();
  const initials = title.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

  return (
    <div className={`w-full h-full relative overflow-hidden bg-gradient-to-br ${theme.bg} flex items-center justify-center`}>
      {/* Decorative patterns */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full" style={{ backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)', backgroundSize: '24px 24px' }} />
      </div>
      
      <div className="relative z-10 flex flex-col items-center justify-center text-center p-6 w-full h-full">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className={`w-24 h-24 rounded-2xl ${theme.accent} flex items-center justify-center shadow-2xl relative z-20 mb-4`}
        >
          <span className="text-4xl font-black text-black/80">{initials}</span>
        </motion.div>
        
        <div className="flex flex-col items-center">
          <h3 className="text-2xl font-black tracking-tighter text-white mb-1 uppercase">
            {title}
          </h3>
          <div className="h-1 w-12 bg-white/30 rounded-full mb-2" />
          <p className="text-[10px] font-bold tracking-[0.2em] text-white/60 uppercase">
            {category}
          </p>
        </div>
      </div>

      {/* Floating elements */}
      <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl" />
      <div className="absolute -top-10 -left-10 w-32 h-32 bg-black/20 rounded-full blur-2xl" />
    </div>
  );
});

const GlassCard = ({ children, className = "", hover = true }) => (
  <motion.div
    whileHover={hover ? { y: -5, scale: 1.02 } : {}}
    className={`relative overflow-hidden rounded-2xl border border-white/10 bg-white/5 backdrop-blur-xl ${className}`}
    style={{
      boxShadow: "0 8px 32px 0 rgba(31, 38, 135, 0.37)",
    }}
  >
    <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />
    {children}
  </motion.div>
);

const SectionTitle = ({ title, subtitle, align = "center" }) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    className={`mb-16 ${align === "center" ? "text-center" : "text-left"}`}
  >
    <motion.span 
      className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-gradient-to-r from-indigo-500/20 to-violet-500/20 text-indigo-400 border border-indigo-500/30 mb-4"
    >
      {subtitle}
    </motion.span>
    <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-white via-white to-slate-400 bg-clip-text text-transparent">
      {title}
    </h2>
  </motion.div>
);

const AnimatedCounter = ({ value, suffix = "" }) => {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          let start = 0;
          const end = value;
          const duration = 2000;
          const increment = end / (duration / 16);
          
          const timer = setInterval(() => {
            start += increment;
            if (start >= end) {
              setCount(end);
              clearInterval(timer);
            } else {
              setCount(Math.floor(start));
            }
          }, 16);
          
          observer.disconnect();
        }
      },
      { threshold: 0.5 }
    );
    
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [value]);
  
  return <span ref={ref}>{count}{suffix}</span>;
};

// ==========================================
// 🏠 MAIN APP
// ==========================================

const PremiumPortfolio2 = () => {
  const [activeSection, setActiveSection] = useState('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedImage, setSelectedImage] = useState(null);
  const [projectFilter, setProjectFilter] = useState('All');
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  const handleImageError = (projectId) => {
    console.warn(`[Portfolio] Image not found for project ${projectId}.`);
  };
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  useEffect(() => {
    const handleMouseMove = (e) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const scrollToSection = (id) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setActiveSection(id);
      setIsMenuOpen(false);
    }
  };

  const handleDownloadCV = () => {
    const link = document.createElement('a');
    link.href = '/Mazen Moaz - CV.pdf';
    link.download = 'Mazen Moaz - CV.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'skills', label: 'Skills' },
    { id: 'services', label: 'Services' },
    { id: 'projects', label: 'Web Projects' },
    { id: 'portfolio', label: 'Visual Portfolio' },
    { id: 'ai-videos', label: 'AI Videos' },
    { id: 'contact', label: 'Contact' },
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white overflow-x-hidden selection:bg-indigo-500/30 selection:text-indigo-200">
      {/* Progress Bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-gradient-to-r from-indigo-500 via-violet-500 to-cyan-500 origin-left z-50"
        style={{ scaleX }}
      />
      
      {/* Custom Cursor Glow */}
      <div 
        className="fixed w-64 h-64 rounded-full pointer-events-none z-0 mix-blend-screen opacity-20 blur-3xl transition-transform duration-100 ease-out hidden md:block"
        style={{
          background: 'radial-gradient(circle, rgba(99,102,241,0.4) 0%, transparent 70%)',
          left: mousePosition.x - 128,
          top: mousePosition.y - 128,
        }}
      />
      
      {/* Particle Background */}
      <ParticleBackground />
      
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-40 px-6 py-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between px-6 py-3 rounded-full border border-white/10 bg-black/20 backdrop-blur-xl">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-2 text-xl font-bold bg-gradient-to-r from-indigo-400 to-violet-400 bg-clip-text text-transparent"
            >
              Mazen<span className="text-cyan-400">.</span>Moaz
            </motion.div>
            
            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                    activeSection === item.id 
                      ? 'bg-white/10 text-white' 
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                </button>
              ))}
              <button 
                onClick={() => scrollToSection('contact')}
                className="ml-4 px-6 py-2 rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 text-white text-sm font-medium hover:shadow-lg hover:shadow-indigo-500/25 transition-all duration-300"
              >
                Hire Me
              </button>
            </div>
            
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2 text-white"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
          
          {/* Mobile Menu */}
          <AnimatePresence>
            {isMenuOpen && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="md:hidden mt-4 p-4 rounded-2xl border border-white/10 bg-black/40 backdrop-blur-xl"
              >
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className="block w-full text-left px-4 py-3 rounded-xl text-slate-300 hover:text-white hover:bg-white/5 transition-colors"
                  >
                    {item.label}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center pt-20 px-6">
        <div className="max-w-7xl mx-auto w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-indigo-500/10 border border-indigo-500/30 text-indigo-400 text-sm"
              >
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
                </span>
                Available for new projects
              </motion.div>
              
              <h1 className="text-5xl md:text-7xl font-bold leading-tight">
                <motion.span
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                  className="block"
                >
                  Building{' '}
                </motion.span>
                <motion.span
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="bg-gradient-to-r from-indigo-400 via-violet-400 to-cyan-400 bg-clip-text text-transparent"
                >
                  Intelligent
                </motion.span>
                <br />
                <motion.span
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 }}
                >
                  Automation Tools
                </motion.span>
              </h1>
              
              <p className="text-lg md:text-xl text-slate-400 max-w-lg leading-relaxed">
                I craft Telegram bots, automation systems, and high-impact visual designs 
                that help businesses scale and stand out in the digital landscape.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => scrollToSection('projects')}
                  className="group px-8 py-4 rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 text-white font-semibold flex items-center gap-2 shadow-lg shadow-indigo-500/25 hover:shadow-indigo-500/40 transition-all"
                >
                  View My Work
                  <ChevronRight className="group-hover:translate-x-1 transition-transform" size={20} />
                </motion.button>
                
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleDownloadCV}
                  className="px-8 py-4 rounded-full border border-white/20 text-white font-semibold hover:bg-white/5 transition-all flex items-center gap-2"
                >
                  <FileDown size={20} />
                  Download CV
                </motion.button>
              </div>
              
              <div className="flex items-center gap-6 pt-4">
                <div className="flex -space-x-3">
                  {[1,2,3,4].map((i) => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-[#0a0a0f] bg-gradient-to-br from-indigo-500 to-violet-500 flex items-center justify-center text-xs font-bold">
                      {i === 4 ? '+' : ''}
                    </div>
                  ))}
                </div>
                <div className="text-sm text-slate-400">
                  <span className="text-white font-semibold">50+</span> Projects Delivered
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="relative hidden lg:block"
            >
              <div className="relative w-full aspect-square max-w-md mx-auto">
                {/* Glowing Orbs */}
                <div className="absolute top-0 right-0 w-72 h-72 bg-violet-500/30 rounded-full blur-3xl animate-pulse" />
                <div className="absolute bottom-0 left-0 w-72 h-72 bg-indigo-500/30 rounded-full blur-3xl animate-pulse delay-1000" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl" />
                
                {/* Code Window */}
                <GlassCard className="absolute top-0 right-0 w-64 p-4 transform rotate-6 hover:rotate-0 transition-transform duration-500">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-3 h-3 rounded-full bg-red-500" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500" />
                    <div className="w-3 h-3 rounded-full bg-green-500" />
                  </div>
                  <div className="space-y-2 font-mono text-xs text-slate-300">
                    <div className="text-violet-400">const <span className="text-cyan-400">bot</span> = <span className="text-green-400">new</span> TelegramBot();</div>
                    <div className="pl-4 text-slate-500">// Initialize automation</div>
                    <div className="text-yellow-400">await <span className="text-white">bot.deploy()</span>;</div>
                  </div>
                </GlassCard>
                
                {/* Stats Card */}
                <GlassCard className="absolute bottom-10 left-0 w-48 p-4 transform -rotate-3 hover:rotate-0 transition-transform duration-500">
                  <div className="text-3xl font-bold text-white mb-1">
                    <AnimatedCounter value={99} suffix="%" />
                  </div>
                  <div className="text-sm text-slate-400">Uptime Guarantee</div>
                  <div className="mt-3 h-2 bg-white/10 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: '99%' }}
                      transition={{ duration: 2, delay: 1 }}
                      className="h-full bg-gradient-to-r from-emerald-400 to-cyan-400"
                    />
                  </div>
                </GlassCard>
                
                {/* Main Image */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 rounded-2xl overflow-hidden border border-white/20 shadow-2xl">
                  <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/20 to-violet-600/20 z-10" />
                  <img 
                    src={heroImage} 
                    alt="Mazen Moaz"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </motion.div>
          </div>
          
          {/* Scroll Indicator */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
            className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-slate-500"
          >
            <span className="text-xs uppercase tracking-widest">Scroll</span>
            <motion.div 
              animate={{ y: [0, 10, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-6 h-10 rounded-full border-2 border-slate-600 flex justify-center p-1"
            >
              <motion.div className="w-1.5 h-3 bg-slate-400 rounded-full" />
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-32 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <SectionTitle 
            title="Combining Logic & Creativity" 
            subtitle="About Me" 
          />
          
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="relative rounded-3xl overflow-hidden border border-white/10">
                <div className="absolute inset-0 bg-gradient-to-tr from-indigo-600/30 to-transparent z-10" />
                <img 
                  src="https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&q=80" 
                  alt="Workspace"
                  className="w-full h-[500px] object-cover"
                />
              </div>
              
              {/* Floating Badge */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.3 }}
                className="absolute -bottom-6 -right-6 p-6 rounded-2xl bg-gradient-to-br from-indigo-600 to-violet-600 border border-white/20 shadow-2xl"
              >
                <div className="text-4xl font-bold text-white">7+</div>
                <div className="text-sm text-indigo-100">Years Experience</div>
              </motion.div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <p className="text-xl text-slate-300 leading-relaxed">
                I am an automation-focused developer and creative designer specializing in building 
                Telegram bots, automation tools, and high-quality visual content.
              </p>
              
              <p className="text-slate-400 leading-relaxed">
                I combine technical development with professional graphic design to create powerful 
                digital solutions that help businesses grow, automate processes, and stand out with 
                visually engaging content.
              </p>
              
              <div className="grid grid-cols-2 gap-4 pt-6">
                {[
                  { icon: Zap, title: "Fast Execution", desc: "Rapid development and deployment" },
                  { icon: Palette, title: "Precision Design", desc: "Pixel-perfect visual content" },
                  { icon: Globe, title: "Scale Up", desc: "Built for high-volume operations" },
                  { icon: Terminal, title: "Reliability", desc: "24/7 uptime monitoring" },
                ].map((item, i) => (
                  <GlassCard key={i} className="p-4">
                    <item.icon className="w-8 h-8 text-indigo-400 mb-3" />
                    <h4 className="font-semibold text-white mb-1">{item.title}</h4>
                    <p className="text-sm text-slate-400">{item.desc}</p>
                  </GlassCard>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-32 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <SectionTitle 
            title="Technical Arsenal" 
            subtitle="Expertise" 
          />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skills.map((skill, index) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <GlassCard className="p-6 group">
                  <div className="flex items-start justify-between mb-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-br ${skill.color} bg-opacity-20`}>
                      <skill.icon className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-2xl font-bold text-white">{skill.level}%</span>
                  </div>
                  
                  <h3 className="text-lg font-semibold text-white mb-3">{skill.name}</h3>
                  
                  <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      whileInView={{ width: `${skill.level}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1.5, delay: 0.2 }}
                      className={`h-full rounded-full bg-gradient-to-r ${skill.color}`}
                    />
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
          
          {/* Tech Stack */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16"
          >
            <GlassCard className="p-8">
              <h3 className="text-xl font-semibold text-white mb-6 text-center">Technologies I Work With</h3>
              <div className="flex flex-wrap justify-center gap-4">
                {['Python', 'JavaScript', 'React', 'Node.js', 'Telegram API', 'TensorFlow', 'PostgreSQL', 'Redis', 'Docker', 'AWS', 'Figma', 'Adobe CC'].map((tech) => (
                  <span 
                    key={tech}
                    className="px-4 py-2 rounded-full bg-white/5 border border-white/10 text-slate-300 hover:bg-white/10 hover:border-indigo-500/50 hover:text-white transition-all cursor-default"
                  >
                    {tech}
                  </span>
                ))}
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-32 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <SectionTitle 
            title="How I Can Help You" 
            subtitle="Services" 
          />
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, index) => (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
              >
                <GlassCard className="p-6 h-full group cursor-pointer">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-violet-500/20 border border-indigo-500/30 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                    <service.icon className="w-7 h-7 text-indigo-400" />
                  </div>
                  
                  <h3 className="text-xl font-semibold text-white mb-3">{service.title}</h3>
                  <p className="text-slate-400 mb-6 leading-relaxed">{service.description}</p>
                  
                  <ul className="space-y-2">
                    {service.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-2 text-sm text-slate-300">
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-32 px-6 relative">
        <div className="max-w-4xl mx-auto">
          <SectionTitle 
            title="Professional Journey" 
            subtitle="Experience" 
          />
          
          <div className="relative">
            <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-indigo-500 via-violet-500 to-transparent" />
            
            {timeline.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.2 }}
                className={`relative flex items-center gap-8 mb-12 ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}
              >
                <div className="hidden md:block w-1/2 text-right">
                  {index % 2 === 0 && (
                    <GlassCard className="p-6 inline-block text-left">
                      <span className="text-indigo-400 font-mono text-sm">{item.year}</span>
                      <h3 className="text-xl font-semibold text-white mt-2">{item.role}</h3>
                      <p className="text-violet-400 font-medium mb-3">{item.company}</p>
                      <p className="text-slate-400 text-sm leading-relaxed">{item.description}</p>
                    </GlassCard>
                  )}
                </div>
                
                <div className="absolute left-8 md:left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-indigo-500 border-4 border-[#0a0a0f] z-10" />
                
                <div className="ml-16 md:ml-0 md:w-1/2">
                  {index % 2 !== 0 && (
                    <GlassCard className="p-6">
                      <span className="text-indigo-400 font-mono text-sm">{item.year}</span>
                      <h3 className="text-xl font-semibold text-white mt-2">{item.role}</h3>
                      <p className="text-violet-400 font-medium mb-3">{item.company}</p>
                      <p className="text-slate-400 text-sm leading-relaxed">{item.description}</p>
                    </GlassCard>
                  )}
                </div>
                
                {/* Mobile View */}
                <div className="md:hidden ml-16 w-full">
                  <GlassCard className="p-6">
                    <span className="text-indigo-400 font-mono text-sm">{item.year}</span>
                    <h3 className="text-xl font-semibold text-white mt-2">{item.role}</h3>
                    <p className="text-violet-400 font-medium mb-3">{item.company}</p>
                    <p className="text-slate-400 text-sm leading-relaxed">{item.description}</p>
                  </GlassCard>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-32 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <SectionTitle 
            title="Digital Creations" 
            subtitle="Portfolio" 
          />

          {/* Project Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-16">
            {projectCategories.map((cat) => (
              <motion.button
                key={cat}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setProjectFilter(cat)}
                className={`px-6 py-2 rounded-full text-sm font-semibold transition-all duration-300 ${
                  projectFilter === cat 
                    ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/25' 
                    : 'bg-white/5 text-slate-400 border border-white/10 hover:border-indigo-500/50'
                }`}
              >
                {cat}
              </motion.button>
            ))}
          </div>
          
          <motion.div 
            layout
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            <AnimatePresence mode="popLayout">
              {projects
                .filter(p => projectFilter === 'All' || p.category === projectFilter)
                .map((project, index) => (
                  <motion.div
                    key={project.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    transition={{ duration: 0.4 }}
                  >
                    <GlassCard className="group h-full flex flex-col overflow-hidden" hover={false}>
                      <div className="relative h-56 overflow-hidden">
                        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] via-transparent to-transparent z-10" />
                        {project.image && project.image !== "" ? (
                          <motion.img 
                            whileHover={{ scale: 1.1 }}
                            transition={{ duration: 0.6 }}
                            src={project.image} 
                            alt={project.title}
                            className="w-full h-full object-cover"
                            loading="lazy"
                            onError={() => handleImageError(project.id)}
                          />
                        ) : (
                          <ProjectThumbnail title={project.title} category={project.category} />
                        )}
                        <div className="absolute top-4 right-4 z-20 flex gap-2">
                          <div className="p-2 rounded-xl bg-black/40 backdrop-blur-md border border-white/10">
                            <project.icon className="w-5 h-5 text-indigo-400" />
                          </div>
                        </div>
                      </div>
                      
                      <div className="p-6 flex-1 flex flex-col">
                        <div className="flex items-center gap-2 mb-3">
                          <span className="px-2 py-0.5 rounded-md bg-indigo-500/10 text-indigo-400 text-[10px] font-bold uppercase tracking-wider border border-indigo-500/20">
                            {project.category}
                          </span>
                        </div>
                        
                        <h3 className="text-xl font-bold text-white mb-3 group-hover:text-indigo-400 transition-colors">
                          {project.title}
                        </h3>

                        <p className="text-slate-400 text-sm leading-relaxed mb-6 flex-1">
                          {project.description}
                        </p>
                        
                        <div className="flex flex-wrap gap-2 mb-6">
                          {project.tech.map((t) => (
                            <span key={t} className="text-[10px] text-slate-500 font-medium">#{t}</span>
                          ))}
                        </div>
                        
                        <motion.a 
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          href={project.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-full py-3 rounded-xl bg-indigo-500 hover:bg-indigo-600 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/20 transition-all"
                        >
                          Enter Site
                          <ExternalLink size={16} />
                        </motion.a>
                      </div>
                    </GlassCard>
                  </motion.div>
                ))}
            </AnimatePresence>
          </motion.div>
          
          {/* Testimonials */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16"
          >
            <GlassCard className="p-8 md:p-12">
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-2xl font-bold text-white mb-6">What Clients Say</h3>
                  <div className="space-y-6">
                    <blockquote className="relative pl-6 border-l-2 border-indigo-500">
                      <p className="text-slate-300 italic mb-2">"Outstanding web development skills. Delivered our project ahead of schedule with perfect execution."</p>
                      <footer className="text-sm font-semibold text-white">— Sarah Johnson, Tech Solutions</footer>
                    </blockquote>
                    <blockquote className="relative pl-6 border-l-2 border-violet-500">
                      <p className="text-slate-300 italic mb-2">"The Telegram bot Mazen built transformed our customer service workflow. Highly recommended!"</p>
                      <footer className="text-sm font-semibold text-white">— Ahmed Al-Kuwari, Qatar Retail</footer>
                    </blockquote>
                  </div>
                </div>
                <div className="bg-gradient-to-br from-indigo-500/10 to-violet-500/10 rounded-2xl p-8 border border-white/5 flex flex-col items-center justify-center text-center">
                  <div className="w-16 h-16 rounded-full bg-indigo-500 flex items-center justify-center mb-6">
                    <Send className="text-white" size={32} />
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-4">Ready to start a project?</h3>
                  <p className="text-slate-400 mb-8">Let's discuss how I can help your business grow with intelligent automation.</p>
                  <motion.button 
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => scrollToSection('contact')}
                    className="px-8 py-3 rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 text-white font-semibold shadow-lg shadow-indigo-500/25 transition-all"
                  >
                    Get In Touch
                  </motion.button>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        </div>
      </section>

      {/* Visual Portfolio Section */}
      <section id="portfolio" className="py-32 px-6 relative bg-white/5">
        <div className="max-w-7xl mx-auto">
          <SectionTitle 
            title="Visual Showcase" 
            subtitle="Portfolio" 
          />
          
          {portfolioSections.map((section, sectionIdx) => (
            <div key={section.title} className="mb-20 last:mb-0">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="flex items-center gap-4 mb-8"
              >
                <div className="h-px flex-1 bg-indigo-500/20"></div>
                <h3 className="text-2xl font-bold text-indigo-400 whitespace-nowrap px-4">
                  {section.title}
                </h3>
                <div className="h-px flex-1 bg-indigo-500/20"></div>
              </motion.div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {section.photos.map((photo, photoIdx) => (
                  <motion.div
                    key={photo}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: (photoIdx % 10) * 0.05 }}
                    viewport={{ once: true }}
                    className="group relative cursor-pointer rounded-xl overflow-hidden bg-white/5 backdrop-blur-sm border border-white/10 shadow-lg hover:border-indigo-500/50 transition-all duration-500"
                    onClick={() => setSelectedImage(photo)}
                  >
                    <AspectRatio ratio={1 / 1} className="relative overflow-hidden">
                      <img
                        src={photo}
                        alt={`Portfolio item ${photoIdx + 1}`}
                        loading="lazy"
                        className="w-full h-full object-contain p-2 transition-all duration-700 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-end pb-6">
                        <div className="bg-white/90 p-3 rounded-full shadow-xl transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 mb-3">
                          <ZoomIn className="text-indigo-600 w-6 h-6" />
                        </div>
                      </div>
                    </AspectRatio>
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* AI Videos Section */}
      <section id="ai-videos" className="py-32 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <SectionTitle 
            title="AI Video Creation" 
            subtitle="AI Creations" 
          />
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {aiVideos.map((video, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="group relative"
              >
                <GlassCard className="p-4 h-full flex flex-col hover:shadow-2xl hover:shadow-indigo-500/10 transition-all duration-500" hover={false}>
                  <AspectRatio ratio={16 / 9} className="rounded-xl overflow-hidden mb-4 bg-black/40">
                    <video
                      src={video.url}
                      controls
                      className="w-full h-full object-contain"
                    />
                  </AspectRatio>
                  <div className="p-2">
                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-indigo-400 transition-colors">
                      {video.title}
                    </h3>
                    <p className="text-slate-400 text-sm leading-relaxed">
                      {video.description}
                    </p>
                  </div>
                </GlassCard>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-32 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <SectionTitle 
            title="Let's Build Something Powerful" 
            subtitle="Get In Touch" 
          />
          
          <div className="grid lg:grid-cols-2 gap-16">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <p className="text-xl text-slate-300 mb-8 leading-relaxed">
                Have a project in mind or just want to say hi? Fill out the form and I'll get back to you within 24 hours.
              </p>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-indigo-500/20 flex items-center justify-center">
                    <Mail className="w-5 h-5 text-indigo-400" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-500">Email</p>
                    <p className="text-white font-medium">moazmazen21@gmail.com</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-violet-500/20 flex items-center justify-center">
                    <Globe className="w-5 h-5 text-violet-400" />
                  </div>
                  <div>
                    <p className="text-sm text-slate-500">Location</p>
                    <p className="text-white font-medium">Cairo, Egypt (Available Globally)</p>
                  </div>
                </div>
                
                <div className="pt-6">
                  <p className="text-sm text-slate-500 mb-4">Follow Me</p>
                  <div className="flex gap-3">
                    {[Github, Linkedin, Twitter].map((Icon, i) => (
                      <motion.a
                        key={i}
                        href="#"
                        whileHover={{ scale: 1.1, y: -2 }}
                        className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 hover:border-indigo-500/50 transition-all"
                      >
                        <Icon size={18} />
                      </motion.a>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <GlassCard className="p-8">
                <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="relative">
                      <input 
                        type="text" 
                        id="name"
                        className="peer w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 text-white placeholder-transparent focus:outline-none focus:border-indigo-500 transition-colors"
                        placeholder="Name"
                      />
                      <label 
                        htmlFor="name"
                        className="absolute left-4 top-4 text-slate-500 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-4 peer-focus:top-1 peer-focus:text-xs peer-focus:text-indigo-400"
                      >
                        Your Name
                      </label>
                    </div>
                    <div className="relative">
                      <input 
                        type="email" 
                        id="email"
                        className="peer w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 text-white placeholder-transparent focus:outline-none focus:border-indigo-500 transition-colors"
                        placeholder="Email"
                      />
                      <label 
                        htmlFor="email"
                        className="absolute left-4 top-4 text-slate-500 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-4 peer-focus:top-1 peer-focus:text-xs peer-focus:text-indigo-400"
                      >
                        Email Address
                      </label>
                    </div>
                  </div>
                  
                  <div className="relative">
                    <input 
                      type="text" 
                      id="subject"
                      className="peer w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 text-white placeholder-transparent focus:outline-none focus:border-indigo-500 transition-colors"
                      placeholder="Subject"
                    />
                    <label 
                      htmlFor="subject"
                      className="absolute left-4 top-4 text-slate-500 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-4 peer-focus:top-1 peer-focus:text-xs peer-focus:text-indigo-400"
                    >
                      Subject
                    </label>
                  </div>
                  
                  <div className="relative">
                    <textarea 
                      id="message"
                      rows={4}
                      className="peer w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 text-white placeholder-transparent focus:outline-none focus:border-indigo-500 transition-colors resize-none"
                      placeholder="Message"
                    />
                    <label 
                      htmlFor="message"
                      className="absolute left-4 top-4 text-slate-500 text-sm transition-all peer-placeholder-shown:text-base peer-placeholder-shown:top-4 peer-focus:top-1 peer-focus:text-xs peer-focus:text-indigo-400"
                    >
                      Your Message
                    </label>
                  </div>
                  
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    type="submit"
                    className="w-full py-4 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 text-white font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-indigo-500/25 transition-all"
                  >
                    <Send size={18} />
                    Send Message
                  </motion.button>
                </form>
              </GlassCard>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-6 border-t border-white/10">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-2 text-2xl font-bold bg-gradient-to-r from-indigo-400 to-violet-400 bg-clip-text text-transparent">
            Mazen<span className="text-cyan-400">.</span>Moaz
          </div>
          
          <p className="text-slate-500 text-sm">
            © 2026 Mazen Moaz. Professional Digital Solutions.
          </p>
          
          <div className="flex gap-6 text-sm text-slate-400">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
          </div>
        </div>
      </footer>

      {/* Image Preview Dialog */}
      <Dialog open={!!selectedImage} onOpenChange={(open) => !open && setSelectedImage(null)}>
        <DialogContent className="max-w-[95vw] max-h-[95vh] p-0 border-none bg-black/95 overflow-hidden flex items-center justify-center">
          <DialogTitle className="sr-only">Image Preview</DialogTitle>
          <AnimatePresence mode="wait">
            {selectedImage && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="relative w-full h-full flex items-center justify-center p-4"
              >
                <img
                  src={selectedImage}
                  alt="Full view"
                  className="max-w-full max-h-[90vh] object-contain shadow-2xl"
                />
                <button
                  onClick={() => setSelectedImage(null)}
                  className="absolute top-4 right-4 bg-white/10 hover:bg-white/20 text-white p-2 rounded-full transition-colors backdrop-blur-md"
                >
                  <X size={24} />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PremiumPortfolio2;
