import { useState } from "react";
import { Mail, MapPin, Send, CheckCircle2, AlertCircle, Phone, User, MessageSquare } from "lucide-react";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

const ContactSection = () => {
  const { ref, isVisible } = useScrollReveal();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    contact: "",
    message: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch("/.netlify/functions/sendMessage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        toast.success("Message sent successfully! I will get back to you soon.", {
          description: "Thank you for reaching out.",
          icon: <CheckCircle2 className="text-green-500" />,
        });
        setFormData({ name: "", contact: "", message: "" });
      } else {
        throw new Error("Failed to send message");
      }
    } catch (error) {
      toast.error("Failed to send message. Please try again later.", {
        icon: <AlertCircle className="text-red-500" />,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="contact" className="section-padding relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/5 blur-[120px] rounded-full pointer-events-none" />
      
      <div ref={ref} className="container mx-auto max-w-5xl relative z-10">
        <div className={`text-center mb-16 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          <span className="text-primary text-sm font-bold uppercase tracking-[0.3em]">Connect</span>
          <h2 className="font-display font-black text-4xl md:text-6xl mt-4">
            Let’s Build Something <span className="text-gradient">Powerful Together</span>
          </h2>
          <p className="text-muted-foreground mt-6 max-w-xl mx-auto text-lg font-medium leading-relaxed">
            Have a project in mind or just want to say hi? Fill out the form below and I'll get back to you within 24 hours.
          </p>
        </div>

        <div className="grid md:grid-cols-5 gap-12 items-start">
          {/* Contact Info */}
          <div className={`md:col-span-2 space-y-8 transition-all duration-700 delay-200 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"}`}>
            <div className="glass neon-border rounded-2xl p-8 space-y-6">
              <h3 className="font-display font-bold text-xl mb-4">Contact Information</h3>
              
              <div className="flex items-start gap-4 group">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                  <Mail className="text-primary w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Email Me</p>
                  <a href="mailto:moazmazen21@gmail.com" className="text-sm font-medium hover:text-primary transition-colors">moazmazen21@gmail.com</a>
                </div>
              </div>

              <div className="flex items-start gap-4 group">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
                  <MapPin className="text-primary w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-1">Location</p>
                  <p className="text-sm font-medium">Cairo, Egypt (Available Globally)</p>
                </div>
              </div>

              <div className="pt-6 border-t border-border/50">
                <p className="text-sm text-muted-foreground leading-relaxed italic">
                  "I prioritize clear communication and fast responses to ensure your project stays on track."
                </p>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className={`md:col-span-3 transition-all duration-700 delay-300 ${isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"}`}>
            <form onSubmit={handleSubmit} className="glass neon-border rounded-2xl p-8 md:p-10 space-y-6">
              <div className="space-y-4">
                <div className="grid grid-cols-1 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground ml-1 flex items-center gap-2">
                      <User size={14} className="text-primary" /> Full Name
                    </label>
                    <Input
                      required
                      placeholder="Enter your name"
                      className="bg-background/50 border-border/50 focus:border-primary transition-all rounded-xl"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground ml-1 flex items-center gap-2">
                      <Phone size={14} className="text-primary" /> Email or Phone Number
                    </label>
                    <Input
                      required
                      placeholder="How can I reach you back?"
                      className="bg-background/50 border-border/50 focus:border-primary transition-all rounded-xl"
                      value={formData.contact}
                      onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
                    />
                    <p className="text-[10px] text-muted-foreground/70 italic ml-1">
                      * Required to enable me to respond to your inquiry.
                    </p>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground ml-1 flex items-center gap-2">
                    <MessageSquare size={14} className="text-primary" /> Your Message
                  </label>
                  <Textarea
                    required
                    placeholder="Describe your project or inquiry..."
                    className="min-h-[150px] bg-background/50 border-border/50 focus:border-primary transition-all rounded-xl resize-none"
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  />
                </div>
              </div>

              <Button
                disabled={isSubmitting}
                className="w-full h-12 rounded-xl font-bold uppercase tracking-widest text-sm relative group overflow-hidden"
              >
                <span className="relative z-10 flex items-center gap-2">
                  {isSubmitting ? "Sending Message..." : "Send Message"}
                  {!isSubmitting && <Send size={16} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />}
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </Button>
            </form>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-24 pt-12 border-t border-border/50 text-center">
          <p className="text-xs text-muted-foreground tracking-widest uppercase">
            © {new Date().getFullYear()} Mazen Moaz. Professional Digital Solutions.
          </p>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
