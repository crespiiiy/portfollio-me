import { useState, useEffect } from "react";
import { ExternalLink, X, ZoomIn } from "lucide-react";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { motion, AnimatePresence } from "framer-motion";
import { Dialog, DialogContent, DialogTrigger, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { AspectRatio } from "@/components/ui/aspect-ratio";

// Import all images from specified directories
const photos1 = import.meta.glob('../photos 1/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, import: 'default' });
const photos2 = import.meta.glob('../photos 2/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, import: 'default' });
const photos3 = import.meta.glob('../photos 3/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, import: 'default' });
const photos4 = import.meta.glob('../photos 4/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, import: 'default' });
const photos5 = import.meta.glob('../photos 5/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, import: 'default' });
const photos6 = import.meta.glob('../photos 6/*.{png,jpg,jpeg,webp,PNG,JPG,JPEG,WEBP}', { eager: true, import: 'default' });

const processPhotos = (photoGlob: Record<string, unknown>) => {
  return Object.keys(photoGlob)
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }))
    .map(path => photoGlob[path] as string);
};

const sections = [
  { title: "Design & Branding Projects", photos: processPhotos(photos1) },
  { title: "Digital Marketing Showcase", photos: processPhotos(photos2) },
  { title: "Creative Visual Works", photos: processPhotos(photos3) },
  { title: "Professional Portfolio", photos: processPhotos(photos4) },
  { title: "Recent Achievements", photos: [...processPhotos(photos5), ...processPhotos(photos6)] },
];

type PhotoCardProps = {
  photo: string;
  sectionTitle: string;
  photoIdx: number;
  onClick: (photo: string) => void;
};

const PhotoCard = ({ photo, sectionTitle, photoIdx, onClick }: PhotoCardProps) => {
  const [loaded, setLoaded] = useState(false);

  // Generate a professional description based on the section and index
  const getDescription = () => {
    const baseDesc = sectionTitle.replace(" Projects", "").replace(" Showcase", "").replace(" Portfolio", "");
    return `${baseDesc} - Achievement #${photoIdx + 1}`;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: (photoIdx % 10) * 0.05 }}
      viewport={{ once: true }}
      className="group relative cursor-pointer rounded-xl overflow-hidden bg-background/50 backdrop-blur-sm border border-white/10 shadow-lg hover:border-primary/50 transition-all duration-500"
      onClick={() => onClick(photo)}
    >
      <AspectRatio ratio={1 / 1} className="relative overflow-hidden">
        {!loaded && (
          <Skeleton className="absolute inset-0 w-full h-full bg-muted/20" />
        )}
        <img
          src={photo}
          alt={getDescription()}
          loading="lazy"
          onLoad={() => setLoaded(true)}
          className={`w-full h-full object-contain p-2 transition-all duration-700 ${loaded ? "opacity-100 scale-100" : "opacity-0 scale-95"} group-hover:scale-105`}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-end pb-6">
          <div className="bg-background/90 p-3 rounded-full shadow-xl transform translate-y-4 group-hover:translate-y-0 transition-transform duration-300 mb-3">
            <ZoomIn className="text-primary w-6 h-6" />
          </div>
          <p className="text-white text-xs font-bold px-4 text-center transform translate-y-2 group-hover:translate-y-0 transition-transform duration-300 uppercase tracking-widest">
            {getDescription()}
          </p>
        </div>
      </AspectRatio>
    </motion.div>
  );
};

const PortfolioSection = () => {
  const { ref, isVisible } = useScrollReveal();
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  return (
    <section id="portfolio" className="section-padding bg-muted/20 relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full pointer-events-none overflow-hidden opacity-20">
        <div className="absolute top-[10%] left-[-10%] w-[500px] h-[500px] rounded-full bg-accent/10 blur-[150px]" />
      </div>

      <div ref={ref} className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-primary font-bold uppercase tracking-[0.3em] text-sm"
          >
            Showcase
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="font-display font-black text-4xl md:text-6xl mt-4"
          >
            Visual <span className="text-gradient">Portfolio</span>
          </motion.h2>
          <p className="text-muted-foreground mt-6 max-w-2xl mx-auto text-lg leading-relaxed font-medium">
            Explore a comprehensive collection of my professional journey, creative projects, and significant career achievements.
          </p>
        </div>

        {sections.map((section, sectionIdx) => (
          <div key={section.title} className="mb-20 last:mb-0">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="flex items-center gap-4 mb-8"
            >
              <div className="h-px flex-1 bg-primary/20"></div>
              <h3 className="font-display font-bold text-2xl md:text-3xl text-primary whitespace-nowrap px-4">
                {section.title}
              </h3>
              <div className="h-px flex-1 bg-primary/20"></div>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {section.photos.map((photo, photoIdx) => (
                <PhotoCard key={photo} photo={photo} sectionTitle={section.title} photoIdx={photoIdx} onClick={setSelectedImage} />
              ))}
            </div>
          </div>
        ))}
      </div>

      <Dialog open={!!selectedImage} onOpenChange={(open) => !open && setSelectedImage(null)}>
        <DialogContent className="max-w-[95vw] max-h-[95vh] p-0 border-none bg-black/95 overflow-hidden flex items-center justify-center">
          <DialogTitle className="sr-only">Image Preview</DialogTitle>
          <AnimatePresence mode="wait">
            {selectedImage && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="relative w-full h-full flex items-center justify-center p-4"
              >
                <img
                  src={selectedImage}
                  alt="Full view"
                  className="max-w-full max-h-[90vh] object-contain shadow-2xl"
                />
                <button
                  onClick={() => setSelectedImage(null)}
                  className="absolute top-4 right-4 bg-white/10 hover:bg-white/20 text-white p-2 rounded-full transition-colors backdrop-blur-md"
                >
                  <X size={24} />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default PortfolioSection;
