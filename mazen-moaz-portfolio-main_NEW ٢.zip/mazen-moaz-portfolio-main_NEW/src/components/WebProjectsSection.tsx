import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ExternalLink, Globe, Shield, ShoppingCart, Layout, Users, Star, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { Skeleton } from "@/components/ui/skeleton";
import { AspectRatio } from "@/components/ui/aspect-ratio";

const categories = ["All", "Cybersecurity", "E-Commerce", "Landing Page", "Social"];

const projects = [
  {
    id: 1,
    title: "GreenHats Omega",
    url: "https://greenhats-omega.vercel.app/",
    category: "Cybersecurity",
    desc: "Advanced AI Platform for cybersecurity professionals, featuring vulnerability analysis and security script generation.",
    tech: ["AI/ML", "React", "Next.js", "Cybersecurity"],
    icon: <Shield className="w-5 h-5" />,
  },
  {
    id: 2,
    title: "Creative Snowy",
    url: "https://creative-snowy.vercel.app/",
    category: "Landing Page",
    desc: "Modern premium business landing page showcasing creative tools and professional digital products.",
    tech: ["Modern UI", "Vite", "Tailwind CSS", "Responsive"],
    icon: <Layout className="w-5 h-5" />,
  },
  {
    id: 3,
    title: "StoreOneCool",
    url: "http://storeonecool.netlify.app",
    category: "E-Commerce",
    desc: "Specialized HVAC systems and cooling solutions e-commerce storefront for GREE authorized distribution.",
    tech: ["E-Commerce", "Product Catalog", "Cart System", "Business"],
    icon: <ShoppingCart className="w-5 h-5" />,
  },
  {
    id: 4,
    title: "LinkedConnectPro",
    url: "https://linkedconnectpro.netlify.app/",
    category: "Social",
    desc: "Professional networking platform designed to enhance LinkedIn growth and professional connectivity.",
    tech: ["Networking", "AI Targeting", "Analytics", "Marketing"],
    icon: <Users className="w-5 h-5" />,
  },
  {
    id: 5,
    title: "GreenHats Platform",
    url: "https://greenhats.netlify.app/",
    category: "Cybersecurity",
    desc: "Comprehensive community hub and tools platform for ethical hackers and security researchers.",
    tech: ["Encryption", "Security Tools", "Community", "React"],
    icon: <Shield className="w-5 h-5" />,
  },
  {
    id: 6,
    title: "StoreLuxe",
    url: "https://storeluxe.netlify.app/",
    category: "E-Commerce",
    desc: "Premium luxury fashion and lifestyle e-commerce experience with curated signature pieces.",
    tech: ["Fashion UI", "Lifestyle", "Modern Design", "E-Commerce"],
    icon: <ShoppingCart className="w-5 h-5" />,
  },
  {
    id: 7,
    title: "TikTok VPN Gift",
    url: "https://tiktokvpn.netlify.app",
    category: "Social",
    desc: "Specialized platform for TikTok account growth, live support, and gift management center.",
    tech: ["Social Media", "Support Center", "Live Boost", "Digital Growth"],
    icon: <Globe className="w-5 h-5" />,
  },
];

const stats = [
  { label: "Completed Projects", value: "150+", icon: <CheckCircle2 className="w-6 h-6 text-primary" /> },
  { label: "Happy Clients", value: "98%", icon: <Star className="w-6 h-6 text-primary" /> },
  { label: "Active Services", value: "12+", icon: <Globe className="w-6 h-6 text-primary" /> },
];

const testimonials = [
  { name: "John D.", company: "Tech Solutions", text: "Outstanding web development skills. Delivered our project ahead of schedule with perfect execution." },
  { name: "Sarah M.", company: "Luxe Brand", text: "The e-commerce site created for us exceeded all expectations. Our sales increased by 30% in the first month." },
];

interface Project {
  id: number;
  title: string;
  url: string;
  category: string;
  desc: string;
  tech: string[];
  icon: React.ReactNode;
}

const ProjectCard = ({ project, idx }: { project: Project, idx: number }) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.5, delay: idx * 0.05 }}
      className="group relative h-full"
    >
      <div className="glass neon-border rounded-2xl overflow-hidden h-full flex flex-col hover:shadow-2xl hover:shadow-primary/10 transition-all duration-500 transform hover:-translate-y-2">
        <AspectRatio ratio={16 / 9} className="bg-gradient-to-br from-primary/10 to-accent/10 relative flex items-center justify-center overflow-hidden">
          {!loaded && (
            <Skeleton className="absolute inset-0 w-full h-full bg-muted/20" />
          )}
          <div className={`absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10`} />
          <div className={`p-6 rounded-full bg-background/50 backdrop-blur-sm transform group-hover:scale-125 transition-transform duration-500 z-20 ${loaded ? "opacity-100" : "opacity-0"}`}>
            {project.icon}
          </div>
          {/* We use the icon as a visual representation since we don't have screenshots */}
          <div className="hidden" aria-hidden="true">
            <img src="/placeholder.svg" onLoad={() => setLoaded(true)} alt="" />
          </div>
          {/* For now, let's simulate loading completion for the icon container */}
          <div className="absolute inset-0 flex items-center justify-center" ref={() => setTimeout(() => setLoaded(true), 500)}>
          </div>
        </AspectRatio>
        
        <div className="p-8 flex-1 flex flex-col">
          <div className="flex justify-between items-start mb-4">
            <Badge variant="secondary" className="bg-primary/10 text-primary border-none">
              {project.category}
            </Badge>
          </div>
          
          <h3 className="font-display font-bold text-xl mb-3 group-hover:text-primary transition-colors">
            {project.title}
          </h3>
          
          <p className="text-muted-foreground text-sm leading-relaxed mb-6 flex-1">
            {project.desc}
          </p>
          
          <div className="flex flex-wrap gap-2 mb-6">
            {project.tech.map(t => (
              <span key={t} className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground/60 border border-muted-foreground/20 px-2 py-0.5 rounded">
                {t}
              </span>
            ))}
          </div>
          
          <Button asChild className="w-full rounded-xl group/btn overflow-hidden relative">
            <a href={project.url} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2">
              <span className="relative z-10">Live Preview</span>
              <ExternalLink size={16} className="relative z-10 group-hover/btn:translate-x-1 group-hover/btn:-translate-y-1 transition-transform" />
              <div className="absolute inset-0 bg-gradient-to-r from-primary to-accent opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300" />
            </a>
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

const WebProjectsSection = () => {
  const [filter, setFilter] = useState("All");
  const { ref, isVisible } = useScrollReveal();

  const filteredProjects = projects.filter(p => filter === "All" || p.category === filter);

  return (
    <section id="web-projects" className="section-padding bg-muted/10 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none overflow-hidden opacity-30">
        <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] rounded-full bg-primary/20 blur-[150px] animate-pulse-glow" />
        <div className="absolute bottom-[-20%] left-[-10%] w-[600px] h-[600px] rounded-full bg-accent/20 blur-[150px] animate-pulse-glow" style={{ animationDelay: "2s" }} />
      </div>

      <div ref={ref} className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-primary font-bold uppercase tracking-[0.3em] text-sm"
          >
            Portfolio
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="font-display font-black text-4xl md:text-6xl mt-4"
          >
            Digital <span className="text-gradient">Creations</span>
          </motion.h2>
          <p className="text-muted-foreground mt-6 max-w-2xl mx-auto text-lg leading-relaxed font-medium">
            A showcase of high-performance web applications, from secure cybersecurity platforms to modern e-commerce experiences.
          </p>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {stats.map((stat, idx) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.1 }}
              viewport={{ once: true }}
              className="glass neon-border p-8 rounded-2xl text-center group hover:bg-primary/5 transition-colors duration-300"
            >
              <div className="flex justify-center mb-4 transform group-hover:scale-110 transition-transform duration-300">
                {stat.icon}
              </div>
              <div className="font-display font-bold text-4xl mb-2 text-gradient">{stat.value}</div>
              <div className="text-muted-foreground font-medium uppercase tracking-wider text-sm">{stat.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categories.map((cat) => (
            <Button
              key={cat}
              variant={filter === cat ? "default" : "outline"}
              onClick={() => setFilter(cat)}
              className={`rounded-full px-6 transition-all duration-300 ${filter === cat ? "shadow-lg shadow-primary/20" : "hover:bg-primary/10"}`}
            >
              {cat}
            </Button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project, idx) => (
              <ProjectCard key={project.id} project={project} idx={idx} />
            ))}
          </AnimatePresence>
        </div>

        {/* Testimonials */}
        <div className="mt-32">
          <div className="text-center mb-16">
            <h3 className="font-display font-bold text-2xl md:text-3xl">What <span className="text-gradient">Clients Say</span></h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {testimonials.map((t, idx) => (
              <motion.div
                key={t.name}
                initial={{ opacity: 0, x: idx % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="glass neon-border p-8 rounded-2xl relative"
              >
                <div className="absolute -top-4 -left-4 w-12 h-12 bg-primary flex items-center justify-center rounded-xl shadow-lg">
                  <Star className="text-white w-6 h-6 fill-white" />
                </div>
                <p className="italic text-muted-foreground mb-6">"{t.text}"</p>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent" />
                  <div>
                    <div className="font-bold text-sm">{t.name}</div>
                    <div className="text-xs text-primary">{t.company}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default WebProjectsSection;
