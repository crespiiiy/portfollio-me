import { motion } from "framer-motion";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { Badge } from "@/components/ui/badge";

const timeline = [
  {
    role: "Freelance Digital Specialist & Creative Designer",
    company: "Independent Freelancer",
    period: "2020 - Present",
    desc: "Expertly delivering end-to-end digital solutions including professional web development, strategic digital marketing, and full-spectrum graphic design. Successfully completed 50+ diverse projects including high-impact logos, promotional video commercials, and social media campaigns. Advanced proficiency in Adobe Creative Suite (Photoshop, Illustrator, Premiere Pro) for brand identity and multimedia assets. Proven track record in SEO optimization and user-centric web design, consistently driving a 40%+ increase in brand visibility for global clients.",
    current: true,
  },
  {
    role: "Marketing Specialist",
    company: "One Cool Qatar",
    period: "2023 - Present",
    desc: "Leading full-spectrum digital marketing campaigns, managing social media strategy, SEO, and paid advertising across multiple platforms to drive growth and engagement.",
    current: true,
  },
  {
    role: "Customer Service Representative",
    company: "Vodafone Cash",
    period: "2021 - 2023",
    desc: "Provided high-stakes financial customer support, mastering objection handling and customer retention techniques in a fast-paced environment.",
  },
  {
    role: "Technical Support Specialist",
    company: "Uber (Middle East)",
    period: "2019 - 2021",
    desc: "Delivered technical support for the Middle East region, resolving complex issues across a high-volume, fast-paced environment with a focus on user experience.",
  },
];

const ExperienceSection = () => {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section id="experience" className="section-padding relative overflow-hidden">
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-primary font-bold uppercase tracking-[0.3em] text-sm"
          >Custom Journey</motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="font-display font-black text-4xl md:text-6xl mt-4"
          >
            Professional <span className="text-gradient">Timeline</span>
          </motion.h2>
        </div>

        <div className="max-w-4xl mx-auto">
          {timeline.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              viewport={{ once: true }}
              className="relative pl-8 md:pl-0 mb-12"
            >
              {/* Timeline Line */}
              <div className="hidden md:block absolute left-1/2 top-0 bottom-0 w-px bg-white/10 -translate-x-1/2" />
              
              <div className={`flex flex-col md:flex-row items-center ${i % 2 === 0 ? "md:flex-row-reverse" : ""}`}>
                <div className="flex-1 w-full">
                  <motion.div 
                    whileHover={{ scale: 1.02 }}
                    className="glass p-8 rounded-3xl border-white/5 hover:border-primary/30 transition-all duration-500 relative"
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="font-display font-black text-xl group-hover:text-primary transition-colors">{item.role}</h3>
                        <p className="text-primary font-bold text-sm">{item.company}</p>
                      </div>
                      <Badge variant="outline" className="border-primary/30 text-primary font-bold">
                        {item.period}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
                    {item.current && (
                      <div className="absolute top-4 right-4 flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                        <span className="text-[10px] font-black text-green-500 uppercase">Present</span>
                      </div>
                    )}
                  </motion.div>
                </div>
                
                <div className="absolute left-0 md:static md:mx-12 z-20">
                  <div className="w-6 h-6 rounded-full bg-primary border-4 border-background shadow-[0_0_15px_rgba(14,165,233,0.5)]" />
                </div>
                
                <div className="flex-1 hidden md:block" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ExperienceSection;
