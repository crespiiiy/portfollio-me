import { motion } from "framer-motion";
import { CheckCircle2, FileDown, Target, Zap, Rocket } from "lucide-react";

const AboutSection = () => {
  const handleDownloadCV = () => {
    const link = document.createElement('a');
    link.href = '/Mazen Moaz - CV.pdf';
    link.download = 'Mazen Moaz - CV.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section id="about" className="section-padding bg-muted/20 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="absolute -top-10 -left-10 w-40 h-40 bg-primary/20 rounded-full blur-3xl animate-pulse" />
            <div className="relative glass p-10 rounded-[2rem] border-primary/20 shadow-2xl shadow-primary/5">
              <span className="text-primary font-bold uppercase tracking-widest text-sm mb-4 block">About Me</span>
              <h2 className="font-display font-black text-4xl md:text-5xl mb-8 leading-tight">
                Combining <span className="text-gradient">Logic</span> & <span className="text-gradient">Creativity</span>
              </h2>
              <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
                <p>
                  I am an automation-focused developer and creative designer specializing in building Telegram bots, automation tools, and high-quality visual content.
                </p>
                <p>
                  I combine technical development with professional graphic design to create powerful digital solutions that help businesses grow, automate processes, and stand out with visually engaging content.
                </p>
              </div>
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={handleDownloadCV}
                className="mt-10 flex items-center gap-3 px-8 py-4 bg-primary/10 text-primary border border-primary/20 rounded-2xl font-bold transition-all hover:bg-primary/20"
              >
                <FileDown size={20} />
                Download Full CV
              </motion.button>
            </div>
          </motion.div>

          <div className="grid sm:grid-cols-2 gap-6">
            {[
              { icon: <Zap className="text-primary" />, title: "Fast Execution", desc: "Rapid development and deployment of automation solutions." },
              { icon: <Target className="text-accent" />, title: "Precision Design", desc: "Pixel-perfect visual content tailored to your brand identity." },
              { icon: <Rocket className="text-primary" />, title: "Scale Up", desc: "Systems built to handle growth and high-volume operations." },
              { icon: <CheckCircle2 className="text-accent" />, title: "Reliability", desc: "Stable bots and scripts with 24/7 uptime monitoring." },
            ].map((item, idx) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5, backgroundColor: "rgba(255, 255, 255, 0.05)" }}
                className="glass p-8 rounded-3xl border-white/5 transition-all group"
              >
                <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mb-6 group-hover:bg-primary/10 transition-colors">
                  {item.icon}
                </div>
                <h3 className="font-display font-bold text-xl mb-3">{item.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
