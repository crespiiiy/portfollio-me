import { motion } from "framer-motion";
import { Code2, Palette, Wrench, Terminal, Database, Cpu, Layout, PenTool, Camera, Smartphone, Workflow, Layers } from "lucide-react";

const skillCategories = [
  {
    title: "Development",
    icon: <Terminal className="text-primary" />,
    skills: [
      { name: "Python", icon: <Code2 size={14} /> },
      { name: "Automation Scripts", icon: <Workflow size={14} /> },
      { name: "Telegram Bots", icon: <MessageSquare size={14} /> },
      { name: "Web Scraping", icon: <Search size={14} /> },
      { name: "API Integration", icon: <Database size={14} /> },
    ],
  },
  {
    title: "Design",
    icon: <Palette className="text-accent" />,
    skills: [
      { name: "Graphic Design", icon: <PenTool size={14} /> },
      { name: "Social Media Ads", icon: <Smartphone size={14} /> },
      { name: "Product Editing", icon: <Camera size={14} /> },
      { name: "Branding Visuals", icon: <Layout size={14} /> },
    ],
  },
  {
    title: "Tools",
    icon: <Wrench className="text-primary" />,
    skills: [
      { name: "Photoshop", icon: <Layers size={14} /> },
      { name: "Canva", icon: <Layout size={14} /> },
      { name: "AI Image Tools", icon: <Cpu size={14} /> },
      { name: "Automation Tools", icon: <Workflow size={14} /> },
    ],
  },
];

import { MessageSquare, Search } from "lucide-react";

const SkillsSection = () => {
  return (
    <section id="skills" className="section-padding bg-background/50 relative overflow-hidden">
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-primary font-bold uppercase tracking-[0.3em] text-sm"
          >
            Expertise
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="font-display font-black text-4xl md:text-6xl mt-4"
          >
            Technical <span className="text-gradient">Arsenal</span>
          </motion.h2>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {skillCategories.map((category, idx) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              viewport={{ once: true }}
              className="glass p-10 rounded-[2.5rem] border-white/5 hover:border-primary/20 transition-all duration-500"
            >
              <div className="flex items-center gap-4 mb-10">
                <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center">
                  {category.icon}
                </div>
                <h3 className="font-display font-black text-2xl">{category.title}</h3>
              </div>

              <div className="flex flex-wrap gap-3">
                {category.skills.map((skill) => (
                  <motion.div
                    key={skill.name}
                    whileHover={{ scale: 1.05, backgroundColor: "rgba(14, 165, 233, 0.15)" }}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/5 text-sm font-bold text-muted-foreground hover:text-primary transition-all cursor-default"
                  >
                    {skill.icon}
                    {skill.name}
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;
