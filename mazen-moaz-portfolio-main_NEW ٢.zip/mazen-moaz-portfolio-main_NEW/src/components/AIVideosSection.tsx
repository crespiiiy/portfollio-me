
import React from 'react';
import { motion } from 'framer-motion';
import { AspectRatio } from "@/components/ui/aspect-ratio";

const videos = [
  { url: '/videos/video_2026-03-24_08-35-46.mp4', title: 'AI Video Creation 1', description: 'Automated video generation based on text prompts.' },
  { url: '/videos/video_2026-03-24_08-35-54.mp4', title: 'AI Video Creation 2', description: 'AI-powered video editing and effects.' },
  { url: '/videos/video_2026-03-24_08-35-59.mp4', title: 'AI Video Creation 3', description: 'Generative video art from still images.' },
  { url: '/videos/video_2026-03-24_08-36-05.mp4', title: 'AI Video Creation 4', description: 'AI-driven character animation.' },
  { url: '/videos/video_2026-03-24_08-36-13.mp4', title: 'AI Video Creation 5', description: 'Dynamic video synthesis from data.' },
];

const AIVideosSection = () => {
  return (
    <section className="py-16 bg-muted/10">
      <div className="container mx-auto">
        <div className="text-center mb-20">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="text-primary font-bold uppercase tracking-[0.3em] text-sm"
          >
            AI Creations
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="font-display font-black text-4xl md:text-6xl mt-4"
          >
            AI Image & <span className="text-gradient">Video Creation</span>
          </motion.h2>
          <p className="text-muted-foreground mt-6 max-w-2xl mx-auto text-lg leading-relaxed font-medium">
            Explore a collection of videos created and manipulated using cutting-edge AI technologies.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {videos.map((video, index) => (
            <motion.div
              key={index}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
              className="group relative h-full"
            >
              <div className="glass neon-border rounded-2xl overflow-hidden h-full flex flex-col hover:shadow-2xl hover:shadow-primary/10 transition-all duration-500 transform hover:-translate-y-2">
                <AspectRatio ratio={16 / 9}>
                  <video
                    src={video.url}
                    controls
                    className="w-full h-full object-contain"
                  />
                </AspectRatio>
                <div className="p-6 flex-1 flex flex-col">
                  <h3 className="font-display font-bold text-xl mb-2 group-hover:text-primary transition-colors">
                    {video.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed flex-1">
                    {video.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AIVideosSection;
