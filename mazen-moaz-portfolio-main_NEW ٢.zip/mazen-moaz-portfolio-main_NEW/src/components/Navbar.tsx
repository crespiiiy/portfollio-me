import { Menu, X, FileDown } from "lucide-react";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const navItems = [
  { name: "About", id: "about" },
  { name: "Services", id: "services" },
  { name: "Experience", id: "experience" },
  { name: "Projects", id: "web-projects" },
  { name: "Portfolio", id: "portfolio" },
  { name: "Contact", id: "contact" },
];

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeSection, setActiveSection] = useState("hero");

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
      
      const sections = ["hero", "about", "services", "experience", "web-projects", "portfolio", "contact"];
      const current = sections.find(section => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 100 && rect.bottom >= 100;
        }
        return false;
      });
      if (current) setActiveSection(current);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
    setOpen(false);
  };

  const handleDownloadCV = () => {
    const link = document.createElement('a');
    link.href = '/Mazen Moaz - CV.pdf';
    link.download = 'Mazen Moaz - CV.pdf';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? "glass border-b border-primary/20 py-2 shadow-xl shadow-primary/5" : "bg-transparent py-4"}`}>
      <div className="container mx-auto flex items-center justify-between h-16 px-6">
        <motion.button 
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => scrollTo("hero")} 
          className="font-display font-black text-2xl text-gradient relative group tracking-tighter"
        >
          MAZEN.DEV
        </motion.button>
        
        <div className="hidden lg:flex items-center gap-2">
          {navItems.map((item) => (
            <motion.button
              key={item.id}
              whileHover={{ y: -2 }}
              whileTap={{ y: 0 }}
              onClick={() => scrollTo(item.id)}
              className={`px-4 py-2 text-sm transition-all font-bold rounded-xl relative ${activeSection === item.id ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-foreground hover:bg-white/5"}`}
            >
              {item.name}
              {activeSection === item.id && (
                <motion.div 
                  layoutId="nav-active"
                  className="absolute bottom-0 left-1/4 right-1/4 h-0.5 bg-primary rounded-full"
                />
              )}
            </motion.button>
          ))}
          
          <div className="w-px h-6 bg-white/10 mx-4" />
          
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: "0 0 20px hsl(199 89% 58% / 0.3)" }}
            whileTap={{ scale: 0.95 }}
            onClick={handleDownloadCV}
            className="flex items-center gap-2 px-6 py-2.5 bg-primary text-primary-foreground rounded-xl font-display font-black text-sm transition-all shadow-lg shadow-primary/10"
          >
            <FileDown size={16} />
            CV
          </motion.button>
        </div>
        
        <div className="flex items-center gap-4 lg:hidden">
          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={handleDownloadCV}
            className="p-2.5 bg-primary/10 text-primary rounded-xl border border-primary/20"
          >
            <FileDown size={20} />
          </motion.button>
          
          <motion.button 
            whileTap={{ scale: 0.9 }}
            onClick={() => setOpen(!open)} 
            className="text-foreground p-2.5 rounded-xl glass border border-primary/10"
          >
            {open ? <X size={24} /> : <Menu size={24} />}
          </motion.button>
        </div>
      </div>
      
      <AnimatePresence>
        {open && (
          <motion.div 
            initial={{ opacity: 0, height: 0, y: -20 }}
            animate={{ opacity: 1, height: "auto", y: 0 }}
            exit={{ opacity: 0, height: 0, y: -20 }}
            className="lg:hidden glass border-t border-primary/10 px-6 pb-8 overflow-hidden"
          >
            <div className="flex flex-col gap-1 pt-4">
              {navItems.map((item, idx) => (
                <motion.button
                  key={item.id}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: idx * 0.05 }}
                  onClick={() => scrollTo(item.id)}
                  className={`block w-full text-left py-4 px-4 transition-all font-bold rounded-xl ${activeSection === item.id ? "text-primary bg-primary/10" : "text-muted-foreground hover:text-foreground hover:bg-white/5"}`}
                >
                  {item.name}
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
