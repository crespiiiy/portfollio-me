"""Offline semantic/layer preparation for the ORIGINAL portal artwork, not SceneAI frames."""
from pathlib import Path
import json
import cv2
import numpy as np
from PIL import Image
from scipy.ndimage import binary_fill_holes

root = Path(__file__).resolve().parent / 'assets'
(root / 'motion-study').mkdir(parents=True, exist_ok=True)
a = cv2.imread(str(root / 'portals-clean-plate.png'))
h, w = a.shape[:2]
yy, xx = np.mgrid[:h, :w].astype(np.float32)

def soft(mask, amount=1.1):
    return np.clip(cv2.GaussianBlur(mask.astype(np.float32), (0, 0), amount), 0, 1)

def poly(points, blur=1.4):
    m = np.zeros((h, w), np.uint8)
    cv2.fillPoly(m, [np.array(points, np.int32)], 1)
    return soft(m, blur)

def arch(cx, rx, top=165, spring=305, bottom=804):
    x = (xx-cx)/rx
    boundary = spring-(spring-top)*np.sqrt(np.maximum(0, 1-x*x))
    return soft(((np.abs(x)<1) & (yy>boundary) & (yy<bottom)).astype(np.float32), .85)

portals = [arch(192, 95), arch(504, 93), arch(837, 126, 165, 308), arch(1169, 96), arch(1492, 96)]
b,g,r = [a[:,:,i].astype(float) for i in range(3)]
luma = .2126*r + .7152*g + .0722*b

# Transparent rigid islands and a separately animated, wind-responsive figure.
actors = np.zeros((h,w), np.float32)
actor_masks = {}
for name, points in {
    'island-near': [(486,185),(492,184),(497,201),(505,216),(513,232),(518,249),(513,268),(520,287),(523,300),(520,326),(517,346),(511,364),(508,383),(501,390),(497,402),(492,408),(486,396),(479,371),(475,349),(468,340),(461,317),(456,310),(453,294),(449,277),(449,259),(450,243),(455,234),(456,222),(462,228),(465,210),(473,213),(474,202),(481,193),(486,197)],
    'island-far': [(542,255),(549,247),(558,253),(566,265),(570,283),(567,302),(562,322),(557,337),(550,351),(545,339),(540,323),(536,304),(537,278)],
}.items():
    area = (poly(points, .35) > .25).astype(np.uint8)
    gc = np.zeros((h,w),np.uint8)
    gc[cv2.dilate(area,np.ones((9,9),np.uint8))>0]=cv2.GC_PR_BGD
    gc[area>0]=cv2.GC_PR_FGD
    gc[cv2.erode(area,np.ones((7,7),np.uint8))>0]=cv2.GC_FGD
    cv2.grabCut(a,gc,None,np.zeros((1,65),np.float64),np.zeros((1,65),np.float64),5,cv2.GC_INIT_WITH_MASK)
    mask = np.isin(gc,[cv2.GC_FGD,cv2.GC_PR_FGD]).astype(np.uint8)
    mask = soft(mask, .50)
    actor_masks[name] = mask
    actors = np.maximum(actors, mask)

roi = ((xx>817)&(xx<871)&(yy>681)&(yy<810))
candidate = ((luma<115)&roi).astype(np.uint8)
n, lab, stats, _ = cv2.connectedComponentsWithStats(candidate)
label = 1+np.argmax(stats[1:,cv2.CC_STAT_AREA])
figure = binary_fill_holes(lab==label).astype(np.float32)
# Retain the gap between the legs, instead of treating the silhouette as a solid bag.
figure[(yy>783)&(xx>842)&(xx<847)&(luma>105)] = 0
figure = soft(figure, .5)
actors = np.maximum(actors, figure)
actor_masks['figure'] = figure
rgba = cv2.cvtColor(a, cv2.COLOR_BGR2RGBA)
rgba[:,:,3] = np.uint8(actors*255)
Image.fromarray(rgba).save(root/'portals-actors.png')
remove = cv2.dilate((actors>.04).astype(np.uint8),np.ones((5,5),np.uint8))*255
background = cv2.inpaint(a,remove,9,cv2.INPAINT_TELEA)
cv2.imwrite(str(root/'portals-background.png'),background)

# Independent semantic flow fields: smoke/fire, open forest air, sea, castle air.
fire_terrain = poly([(98,605),(122,585),(149,636),(173,652),(207,577),(246,504),(266,469),(286,510),(288,803),(98,803)])
flame = np.clip((r-g*1.22-10)/50,0,1)*np.clip((r-75)/85,0,1)
fire = portals[0] * np.maximum(1-fire_terrain,flame*.94)
forest_sky = portals[1] * np.clip((luma-100)/75,0,1) * np.clip((b-g*.85)/27,0,1)
forest_sky = np.maximum(forest_sky,actors*(xx<700))
forest_sky = soft(forest_sky,2.2)*portals[1]

rocks = np.maximum.reduce([
    poly([(1266,535),(1246,518),(1233,531),(1220,563),(1200,582),(1170,603),(1155,631),(1190,652),(1266,648)]),
    poly([(1072,752),(1095,729),(1120,733),(1140,751),(1153,774),(1144,798),(1072,803)]),
    poly([(1192,790),(1206,755),(1223,725),(1245,719),(1266,724),(1266,803),(1192,803)]),
])
# Remove only actual dark rock pixels inside these polygons; white runoff still flows.
rock_core = rocks * (1-np.clip((luma-62)/60,0,1))
rock_core = soft(rock_core, .8)
surf = np.maximum((yy>547).astype(np.float32),poly([(1130,558),(1165,515),(1185,497),(1205,455),(1216,434),(1242,446),(1266,468),(1266,591),(1200,642),(1130,627)],2))
ocean = portals[3] * surf * (1-rock_core)
ocean = soft(ocean,1.2)*portals[3]
ocean_sky = portals[3]*(1-surf)

castle_shape = poly([(1588,216),(1547,216),(1543,290),(1523,315),(1513,362),(1485,372),(1473,347),(1460,379),(1450,414),(1424,459),(1443,493),(1451,514),(1460,536),(1489,540),(1503,575),(1547,590),(1588,551)],1)
castle_sky = portals[4]*(1-castle_shape)*np.clip((luma-112)/78,0,1)
castle_sky *= np.clip((665-yy)/110,0,1)
castle_mist = portals[4]*np.clip((luma-114)/80,0,1)*np.clip((yy-524)/80,0,1)
castle_air = np.maximum(castle_sky,castle_mist)

# Thin falling streams are separate from the rigid cliffs and the masonry.
falls = np.zeros((h,w), np.uint8)
for points,width in [
    ([(562,499),(558,531),(548,557)],8),
    ([(570,678),(566,708),(563,743)],9),
    ([(471,649),(468,682),(465,705)],6),
    ([(492,761),(485,787),(479,803)],7),
    ([(1486,520),(1481,555),(1477,578)],15),
    ([(1470,656),(1464,681),(1461,698)],9),
    ([(1542,539),(1539,558),(1537,571)],5),
]:
    cv2.polylines(falls,[np.array(points,np.int32)],False,255,width,cv2.LINE_AA)
falls = soft(falls/255,1.5)*np.clip((luma-75)/100,0,1)
falls *= np.maximum(portals[1],portals[4])
foliage = np.maximum(portals[1],portals[4]) * np.clip((g-b-2)/24,0,1) * np.clip((r-45)/75,0,1) * (yy>340)
foliage *= 1-actors
foliage = soft(foliage,1.0)

m1 = np.uint8(np.stack([fire,forest_sky,ocean,castle_air],-1).clip(0,1)*255)
m2 = np.uint8(np.stack([falls,foliage,ocean_sky,castle_mist],-1).clip(0,1)*255)
Image.fromarray(m1,'RGBA').save(root/'portals-motion-masks.png')
Image.fromarray(m2,'RGBA').save(root/'portals-detail-masks.png')

# Auditable layer coverage and a human-readable debug overlay (never published).
info = {'source':'original portals-clean-plate.png','source_size':[w,h], 'layers':{},'motion_regions':{}}
for name,m in actor_masks.items():
    ys,xs=np.where(m>.5)
    info['layers'][name]={'bounds':[int(xs.min()),int(ys.min()),int(xs.max()),int(ys.max())],'pixels':int((m>.5).sum())}
for name,m in {'fire':fire,'forest-air':forest_sky,'ocean':ocean,'castle-air':castle_air,'falls':falls,'foliage':foliage,'ocean-sky':ocean_sky,'castle-mist':castle_mist}.items():
    info['motion_regions'][name] = {'pixels':int((m>.2).sum()),'max':float(m.max())}
(root/'motion-study/layers.json').write_text(json.dumps(info,indent=2)+'\n')
overlay = a.astype(np.float32)
for m,color in [(fire,[20,70,255]),(forest_sky,[255,230,0]),(ocean,[255,120,20]),(castle_air,[20,220,255]),(falls,[255,0,255]),(actors,[0,255,0])]:
    overlay = overlay*(1-m[:,:,None]*.4) + np.array(color)[None,None,:]*m[:,:,None]*.4
cv2.imwrite(str(root/'motion-study/semantic-layers.jpg'),overlay.astype(np.uint8))
print(json.dumps(info,indent=2))
