import { chromium } from 'playwright';
import { fileURLToPath } from 'node:url';
import { readFile, writeFile } from 'node:fs/promises';
import { spawn, execFileSync } from 'node:child_process';
import { once } from 'node:events';

const directory = fileURLToPath(new URL('./assets/', import.meta.url));
const outputVideo = fileURLToPath(new URL('../../public/media/portal-hero.mp4', import.meta.url));
const stillsOnly = process.argv.includes('--stills');
const fps = 30, duration = 10, count = fps * duration;
const ffmpeg = execFileSync(process.env.PYTHON_BIN || 'python', ['-c', 'import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())'], { encoding: 'utf8' }).trim();
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || undefined,
  args: ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'],
});
try {
  const page = await browser.newPage({ viewport: { width:1536, height:864 } });
  page.on('pageerror', error => console.error(error.message));
  await page.setContent(await readFile(directory+'render-portals.html', 'utf8'));
  const sources = {};
  for (const [name, file] of Object.entries({
    plate:'portals-clean-plate.png', scenery:'portals-background.png', actors:'portals-actors.png',
    motion:'portals-motion-masks.png', detail:'portals-detail-masks.png',
  })) sources[name] = 'data:image/png;base64,'+(await readFile(directory+file)).toString('base64');
  await page.evaluate(sources => window.loadTextures(sources), sources);
  for (const [name, phase] of [['first',0],['wind',.17],['surf',.39],['clouds',.62],['loop',1]]) {
    const jpeg = await page.evaluate(phase => window.drawFrame(phase), phase);
    await writeFile(directory+'natural-'+name+'.jpg', Buffer.from(jpeg,'base64'));
  }
  if (!stillsOnly) {
    const encoder = spawn(ffmpeg, [
      '-y','-hide_banner','-loglevel','warning',
      '-f','image2pipe','-vcodec','mjpeg','-framerate',String(fps),'-i','pipe:0',
      '-an','-map_metadata','-1',
      '-vf','scale=in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv420p,sidedata=delete',
      '-c:v','libx264','-preset','medium','-crf','20',
      '-pix_fmt','yuv420p','-movflags','+faststart','-color_range','tv',
      '-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709',
      '-bsf:v','h264_metadata=video_full_range_flag=0:colour_primaries=1:transfer_characteristics=1:matrix_coefficients=1',
      outputVideo,
    ], { stdio:['pipe','ignore','pipe'] });
    let logs='';encoder.stderr.on('data',data=>{logs+=data;});
    const exited=once(encoder,'exit');
    for(let index=0;index<count;index++){
      const jpeg=await page.evaluate(phase=>window.drawFrame(phase),index/count);
      if(!encoder.stdin.write(Buffer.from(jpeg,'base64')))await once(encoder.stdin,'drain');
      if(index%30===0)console.log(`Rendered ${index}/${count} independent-motion frames`);
    }
    encoder.stdin.end();
    const [code]=await exited;
    if(code!==0)throw new Error('Encoding failed: '+logs.slice(-2000));
    console.log(`Encoded ${duration}s, 1536×864, ${fps}fps, silent H.264 seamless world/cloth/environment animation.`);
    console.log(logs.slice(-1000));
  } else console.log('Rendered five inspection stills, including identical loop endpoints.');
} finally { await browser.close(); }
