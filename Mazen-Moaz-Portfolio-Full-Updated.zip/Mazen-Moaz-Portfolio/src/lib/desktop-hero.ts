/** Match actual desktop/laptop input, not phones or touch-only tablets in landscape. */
export const DESKTOP_HERO_QUERY = '(min-width: 1024px) and (hover: hover) and (pointer: fine)';
export const HERO_REDUCED_MOTION_QUERY = '(prefers-reduced-motion: reduce)';
export const DESKTOP_HERO_POSTER = '/media/portal-hero-poster.jpg';
export const DESKTOP_HERO_VIDEO = '/media/portal-hero.mp4';
