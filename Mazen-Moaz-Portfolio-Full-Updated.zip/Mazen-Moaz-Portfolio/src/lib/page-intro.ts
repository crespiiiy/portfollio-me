import heroImage from '../assets/hero.jpg';
import { DESKTOP_HERO_POSTER, DESKTOP_HERO_QUERY } from './desktop-hero';

export const INTRO_READY_EVENT = 'portfolio:intro-ready';
export const INTRO_MINIMUM_MS = 850;
export const INTRO_MAXIMUM_MS = 4000;

declare global {
  interface Window {
    __portfolioIntro?: {
      startedAt: number;
      release: () => void;
    };
  }
}

export const isPageIntroReady = () => (
  typeof document === 'undefined'
  || !['loading', 'leaving'].includes(document.documentElement.dataset.siteIntro || '')
);

export const subscribeToPageIntro = (notify: () => void) => {
  window.addEventListener(INTRO_READY_EVENT, notify);
  return () => window.removeEventListener(INTRO_READY_EVENT, notify);
};

/** Wait for local above-the-fold assets, never the remote gallery or video files. */
export function preparePageIntro() {
  // React may arrive after the safety timeout on an exceptionally slow connection.
  delete document.documentElement.dataset.siteError;
  const boot = window.__portfolioIntro;
  if (!boot || isPageIntroReady()) {
    const root = document.getElementById('root');
    root?.removeAttribute('inert');
    root?.removeAttribute('aria-hidden');
    root?.setAttribute('aria-busy', 'false');
    return () => {};
  }

  let disposed = false;
  let releaseQueued = false;
  const timers = new Set<ReturnType<typeof setTimeout>>();
  const removeImageListeners: Array<() => void> = [];
  const schedule = (callback: () => void, delay: number) => {
    const timer = setTimeout(() => {
      timers.delete(timer);
      if (!disposed) callback();
    }, Math.max(0, delay));
    timers.add(timer);
    return timer;
  };
  const clearTimers = () => {
    timers.forEach(clearTimeout);
    timers.clear();
  };
  const clearImageListeners = () => removeImageListeners.forEach(remove => remove());

  const release = () => {
    if (disposed || releaseQueued) return;
    releaseQueued = true;
    clearTimers();
    clearImageListeners();
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const remaining = (reduced ? 0 : INTRO_MINIMUM_MS) - (performance.now() - boot.startedAt);
    if (remaining > 0) schedule(() => boot.release(), remaining);
    else boot.release();
  };

  const waitForImage = (image: HTMLImageElement | null) => new Promise<void>((resolve) => {
    if (!image) { resolve(); return; }
    const ready = () => {
      image.removeEventListener('load', ready);
      image.removeEventListener('error', ready);
      resolve();
    };
    if (image.complete) { resolve(); return; }
    image.addEventListener('load', ready, { once: true });
    image.addEventListener('error', ready, { once: true });
    removeImageListeners.push(() => {
      image.removeEventListener('load', ready);
      image.removeEventListener('error', ready);
    });
  });

  const hero = new Image();
  hero.decoding = 'async';
  hero.fetchPriority = 'high';
  // Only the lightweight first frame is needed; video never holds the intro open.
  hero.src = window.matchMedia(DESKTOP_HERO_QUERY).matches ? DESKTOP_HERO_POSTER : heroImage;
  const logo = document.getElementById('site-preloader-logo') as HTMLImageElement | null;
  const fontsReady = document.fonts
    ? Promise.race([document.fonts.ready, new Promise<void>(resolve => schedule(resolve, 800))])
    : Promise.resolve();

  Promise.all([waitForImage(logo), waitForImage(hero), fontsReady]).then(release, release);
  schedule(release, INTRO_MAXIMUM_MS - (performance.now() - boot.startedAt));

  return () => {
    disposed = true;
    clearTimers();
    clearImageListeners();
  };
}
