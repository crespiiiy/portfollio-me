/** Existing toolkit, in the same order as the original Skills section. */
export const ARSENAL_TECHNOLOGIES = [
  { name: 'Python', mark: 'Py' },
  { name: 'JavaScript', mark: 'JS' },
  { name: 'React', mark: 'Re' },
  { name: 'Node.js', mark: 'N' },
  { name: 'Telegram API', mark: 'Tg' },
  { name: 'TensorFlow', mark: 'Tf' },
  { name: 'PostgreSQL', mark: 'Pg' },
  { name: 'Redis', mark: 'Rd' },
  { name: 'Docker', mark: 'Dk' },
  { name: 'AWS', mark: 'aws' },
  { name: 'Figma', mark: 'Fi' },
  { name: 'Adobe CC', mark: 'Cc' },
] as const;

/** Visual associations organize existing tools; they are not new proficiency claims. */
export const ARSENAL_CAPABILITIES = [
  { id: 'bots', accent: '#b9a5ed', description: 'arsenal_bot_desc', tools: ['Python', 'Node.js', 'Telegram API', 'PostgreSQL'] },
  { id: 'web', accent: '#90cbd8', description: 'arsenal_web_desc', tools: ['JavaScript', 'React', 'Node.js', 'PostgreSQL', 'AWS'] },
  { id: 'design', accent: '#dfb0d0', description: 'arsenal_design_desc', tools: ['React', 'Figma', 'Adobe CC'] },
  { id: 'automation', accent: '#ddbd8f', description: 'arsenal_automation_desc', tools: ['Python', 'Node.js', 'TensorFlow', 'Redis', 'Docker', 'AWS'] },
  { id: 'api', accent: '#9bcebd', description: 'arsenal_api_desc', tools: ['JavaScript', 'Node.js', 'Telegram API', 'PostgreSQL', 'Redis'] },
  { id: 'data', accent: '#aaa8ee', description: 'arsenal_data_desc', tools: ['Python', 'TensorFlow', 'PostgreSQL', 'Redis'] },
] as const;
