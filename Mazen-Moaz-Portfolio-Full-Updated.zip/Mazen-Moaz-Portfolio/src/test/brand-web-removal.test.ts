import { createHash } from 'node:crypto';
import { describe, expect, it } from 'vitest';
import { PHOTOS, PHOTO_GROUPS, VIDEO_ITEMS, VIDEO_GROUPS, VIDEOS } from '../data/gallery';

const digest = (value: unknown) => createHash('sha256').update(JSON.stringify(value)).digest('hex');
const removedIds = [
  '1JpnN5391m-qaZEwOkPxKzJAKml8KleKe',
  '1grspS3tsNJF7k-neRFgVgcUZxIxe3MhM',
  '1aP35O54P5oGnCuT3Z-rYdrxehY9b65FT',
  '1-WtuWYhUE2BsjXR8o2rIp07lXqQhJ09_',
];

describe('Brand & Web Identity removal', () => {
  it('removes the category from English and Arabic gallery filters', () => {
    expect(PHOTO_GROUPS).toHaveLength(6);
    expect(PHOTO_GROUPS.some(group => String(group.id) === 'brand_web')).toBe(false);
    expect(PHOTO_GROUPS.some(group => group.title.includes('Brand & Web Identity'))).toBe(false);
    expect(PHOTO_GROUPS.some(group => group.titleAr.includes('الهوية والويب'))).toBe(false);
  });

  it('removes all four photos from the all-items gallery and lightbox data', () => {
    expect(PHOTOS).toHaveLength(89);
    expect(PHOTOS.some(photo => photo.group === 'brand_web')).toBe(false);
    for (const id of removedIds) expect(PHOTOS.some(photo => photo.id === id)).toBe(false);
  });

  it('preserves all other photos, their order, and their categories exactly', () => {
    expect(digest(PHOTOS)).toBe('4e913a9a7e1f3842b984f79173c3c8ce68dfc817306d1dbe26ff9e2bcccbbf32');
    expect(digest(PHOTO_GROUPS)).toBe('9193efa5f9774b7f62d93491c9265851f259969af12be1eef115ae729e657d2d');
  });

  it('keeps each remaining photo assigned to a valid category with the original count', () => {
    const counts = Object.fromEntries(PHOTO_GROUPS.map(group => [group.id, PHOTOS.filter(photo => photo.group === group.id).length]));
    expect(counts).toEqual({ ac_campaigns: 30, perfume_beauty: 25, fmcg_packaging: 13, food_beverage: 8, social_design: 9, jewelry: 4 });
    expect(Object.values(counts).reduce((sum, count) => sum + count, 0)).toBe(PHOTOS.length);
    expect(new Set(PHOTOS.map(photo => photo.id)).size).toBe(89);
  });

  it('does not change any video, title, order, or video filter', () => {
    expect(VIDEO_ITEMS).toHaveLength(20);
    expect(digest(VIDEO_ITEMS)).toBe('68649e9b7a3f061526ace0d3f401d7c5c934092163d709876ff6b4a079a06a63');
    expect(digest(VIDEO_GROUPS)).toBe('d8436967d5221237a859ccb10f0f5ba6f0bc2d553b1708141e58e5ead06b3c94');
    expect(digest(VIDEOS)).toBe('821ddee0b4fc660b13bf3a74762050e2151893bc15ae0faf361060f56d2e9000');
  });
});
