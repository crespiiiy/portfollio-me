import { describe, it, expect } from "vitest";
import { readFileSync, existsSync } from "node:fs";
import { resolve } from "node:path";

const root = process.cwd();
const read = (path: string) => readFileSync(resolve(root, path), "utf8");

describe("CV download removal", () => {
  it("removes controls and handlers from all portfolio components", () => {
    for (const name of ["PremiumPortfolio", "premiumPortfolio2", "HeroSection", "Navbar", "WhyMeSection"]) {
      const source = read(`src/components/${name}.tsx`);
      expect(source).not.toContain("handleDownloadCV");
      expect(source).not.toContain("FileDown");
      expect(source).not.toContain("CV.pdf");
      expect(source).not.toContain("hero_cta_cv");
    }
  });
  it("removes the CV label in both languages", () => {
    for (const lang of ["ar", "en"]) {
      const translations = JSON.parse(read(`src/locales/${lang}.json`));
      expect(translations).not.toHaveProperty("hero_cta_cv");
      expect(translations).toHaveProperty("hero_cta_work");
    }
  });
  it("does not publish the CV PDF", () => {
    expect(existsSync(resolve(root, "public/Mazen Moaz - CV.pdf"))).toBe(false);
  });
  it("retains the primary project CTA and all sixteen projects", () => {
    const source = read("src/components/PremiumPortfolio.tsx");
    expect(source).toContain("t('hero_cta_work')");
    const projectBlock = source.split("  const projects = [")[1].split("  const projectCategories")[0];
    expect(projectBlock.match(/\bid:\s*\d+/g)).toHaveLength(16);
    for (const url of ["https://greenhaven-rosy.vercel.app/", "https://organichoneyhouse.vercel.app/", "https://mazen-motion-portfolio.vercel.app/", "https://elghonemy-coffee.vercel.app/", "https://klarna-homepage-recreation.vercel.app/", "https://mmm-health.vercel.app/"]) {
      expect(projectBlock).toContain(url);
    }
  });
});
