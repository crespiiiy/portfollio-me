import { act, cleanup, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { readFileSync } from 'node:fs';
import TypewriterHeadline from '../components/TypewriterHeadline';
import { INTRO_MAXIMUM_MS, INTRO_MINIMUM_MS, INTRO_READY_EVENT, preparePageIntro } from '../lib/page-intro';

const html = readFileSync('index.html', 'utf8');
const script = html.match(/<script id="site-intro-boot">([\s\S]*?)<\/script>/)?.[1] || '';
const start = () => new Function(script)();
const advance = (milliseconds: number) => act(() => vi.advanceTimersByTime(milliseconds));
const phase = () => document.documentElement.dataset.siteIntro;

beforeEach(() => {
  vi.useFakeTimers();
  document.body.innerHTML = '<div id="site-preloader"><img id="site-preloader-logo" src="/preloader-logo.jpg" /></div><div id="root" inert aria-hidden="true" aria-busy="true"><p>App content</p></div>';
});

afterEach(() => {
  cleanup();
  vi.clearAllTimers();
  vi.useRealTimers();
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  delete window.__portfolioIntro;
  delete document.documentElement.dataset.siteIntro;
  delete document.documentElement.dataset.siteError;
  document.body.innerHTML = '';
});

describe('Opening logo preloader', () => {
  it('renders a byte-identical copy of the existing logo before the React bundle', () => {
    expect(html.indexOf('id="site-preloader"')).toBeLessThan(html.indexOf('id="root"'));
    expect(html.indexOf('id="site-preloader"')).toBeLessThan(html.indexOf('src="/src/main.tsx"'));
    expect(html).toContain('id="site-preloader-logo" class="site-preloader-mark" src="/preloader-logo.jpg"');
    expect(readFileSync('public/preloader-logo.jpg')).toEqual(readFileSync('public/favicon.ico'));
    expect(readFileSync('src/components/PremiumPortfolio.tsx', 'utf8')).toContain("import logoImage from '/preloader-logo.jpg';");
    expect(html).toContain('fetchpriority="high"');
    expect(html).toContain('role="status" aria-label="Loading portfolio / جارٍ تحميل الموقع"');
  });

  it('matches the reference opacity pulse and fade and supports reduced motion', () => {
    expect(html).toContain('portfolio-logo-pulse 1.8s ease-in-out infinite');
    expect(html).toContain('0%, 100% { opacity: .35; }');
    expect(html).toContain('50% { opacity: 1; }');
    expect(html).toContain('transition: opacity 600ms ease;');
    expect(html).toContain('@media (prefers-reduced-motion: reduce)');
    expect(html).toContain('.site-preloader { display: none; }');
    expect(html).toContain('<noscript>');
  });

  it('blocks interaction only while loading, then removes the overlay and unlocks the app', () => {
    const ready = vi.fn();
    window.addEventListener(INTRO_READY_EVENT, ready, { once: true });
    start();
    expect(phase()).toBe('loading');
    expect(document.getElementById('root')).toHaveAttribute('inert');
    window.__portfolioIntro?.release();
    expect(phase()).toBe('leaving');
    advance(599);
    expect(phase()).toBe('leaving');
    advance(1);
    expect(phase()).toBe('ready');
    expect(document.getElementById('site-preloader')).toBeNull();
    expect(document.getElementById('root')).not.toHaveAttribute('inert');
    expect(document.getElementById('root')).not.toHaveAttribute('aria-hidden');
    expect(document.getElementById('root')).toHaveAttribute('aria-busy', 'false');
    expect(ready).toHaveBeenCalledTimes(1);
    expect(vi.getTimerCount()).toBe(0);
  });

  it('ignores repeated release calls instead of replaying or leaking timers', () => {
    start();
    window.__portfolioIntro?.release();
    window.__portfolioIntro?.release();
    expect(vi.getTimerCount()).toBe(1);
    advance(600);
    window.__portfolioIntro?.release();
    advance(10000);
    expect(phase()).toBe('ready');
    expect(vi.getTimerCount()).toBe(0);
  });

  it('fails open with a reload option rather than spinning forever if the bundle fails', () => {
    document.getElementById('root')?.replaceChildren();
    start();
    advance(7000);
    expect(phase()).toBe('leaving');
    expect(document.documentElement.dataset.siteError).toBe('true');
    advance(600);
    expect(phase()).toBe('ready');
    expect(document.getElementById('site-preloader')).toBeNull();
    expect(html).toContain('إعادة التحميل / Reload site');
  });

  it('shortens the fade to 80 milliseconds for reduced-motion visitors', () => {
    const original = window.matchMedia;
    vi.spyOn(window, 'matchMedia').mockImplementation(query => ({ ...original(query), matches: true }));
    start();
    window.__portfolioIntro?.release();
    advance(79);
    expect(phase()).toBe('leaving');
    advance(1);
    expect(phase()).toBe('ready');
  });

  it('keeps the typewriter paused through loading and the complete fade, then starts at B', () => {
    start();
    render(<TypewriterHeadline firstLine="Building" accentLine="Intelligent" lastLine="Automation Tools" direction="ltr" />);
    const heading = screen.getByRole('heading');
    advance(5000);
    expect(heading).toHaveAttribute('data-character-count', '0');
    expect(heading).toHaveAttribute('data-typewriter-state', 'paused');
    expect(document.querySelector('.hero-typewriter-caret')).toBeNull();
    act(() => window.__portfolioIntro?.release());
    advance(599);
    expect(heading).toHaveAttribute('data-character-count', '0');
    advance(1);
    expect(heading).toHaveAttribute('data-typewriter-state', 'waiting');
    advance(319);
    expect(heading).toHaveAttribute('data-character-count', '0');
    advance(1);
    expect(heading).toHaveAttribute('data-character-count', '1');
    expect(heading.querySelector('.hero-typewriter-line')).toHaveAttribute('data-typed-text', 'B');
    advance(4000);
    expect(heading).toHaveAttribute('data-character-count', '35');
  });

  it('releases after a bounded wait even when an image never finishes loading', () => {
    start();
    const stop = preparePageIntro();
    advance(INTRO_MAXIMUM_MS - 1);
    expect(phase()).toBe('loading');
    advance(1);
    advance(0);
    expect(phase()).toBe('leaving');
    advance(600);
    expect(phase()).toBe('ready');
    stop();
  });

  it('keeps a short visible intro on a fully cached page without imposing a long fake delay', async () => {
    vi.stubGlobal('Image', class { complete = true; decoding = ''; fetchPriority = ''; src = ''; });
    Object.defineProperty(document.getElementById('site-preloader-logo'), 'complete', { value: true });
    start();
    const stop = preparePageIntro();
    await act(async () => { await Promise.resolve(); await Promise.resolve(); });
    advance(INTRO_MINIMUM_MS - 1);
    expect(phase()).toBe('loading');
    advance(1);
    expect(phase()).toBe('leaving');
    advance(600);
    expect(phase()).toBe('ready');
    stop();
  });

  it('still unlocks the page if the inline bootstrap was unavailable', () => {
    const stop = preparePageIntro();
    expect(document.getElementById('root')).not.toHaveAttribute('inert');
    expect(document.getElementById('root')).not.toHaveAttribute('aria-hidden');
    stop();
  });

  it('removes the temporary error message if the app arrives after the safety timeout', () => {
    document.getElementById('root')?.replaceChildren();
    start();
    advance(7600);
    expect(document.documentElement.dataset.siteError).toBe('true');
    document.getElementById('root')?.append(document.createElement('main'));
    const stop = preparePageIntro();
    expect(document.documentElement).not.toHaveAttribute('data-site-error');
    expect(document.getElementById('root')).not.toHaveAttribute('inert');
    stop();
  });

  it('cleans up its pending work when the app unmounts', () => {
    const release = vi.fn();
    document.documentElement.dataset.siteIntro = 'loading';
    window.__portfolioIntro = { startedAt: performance.now(), release };
    const stop = preparePageIntro();
    expect(vi.getTimerCount()).toBeGreaterThan(0);
    stop();
    expect(vi.getTimerCount()).toBe(0);
    advance(10000);
    expect(release).not.toHaveBeenCalled();
  });

  it('shows connected Arabic immediately after the intro for reduced-motion visitors', () => {
    const original = window.matchMedia;
    vi.spyOn(window, 'matchMedia').mockImplementation(query => ({ ...original(query), matches: true }));
    start();
    render(<TypewriterHeadline firstLine="بناء أدوات أتمتة" accentLine="ذكية ومبتكرة" lastLine="" direction="rtl" />);
    const heading = screen.getByRole('heading');
    advance(500);
    expect(heading).toHaveAttribute('data-character-count', '0');
    expect(heading).toHaveAttribute('data-typewriter-state', 'paused');
    act(() => window.__portfolioIntro?.release());
    advance(80);
    expect(heading).toHaveAttribute('data-typewriter-state', 'complete');
    expect(heading).toHaveAttribute('dir', 'rtl');
    expect([...heading.querySelectorAll('.hero-typewriter-line')].map(line => line.getAttribute('data-typed-text')))
      .toEqual(['بناء أدوات أتمتة', 'ذكية ومبتكرة']);
    expect(document.querySelector('.hero-typewriter-caret')).toBeNull();
  });
});
