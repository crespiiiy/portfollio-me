import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import en from '../locales/en.json';
import ar from '../locales/ar.json';

const source = readFileSync('src/components/PremiumPortfolio.tsx', 'utf8');
const array = source.match(/  const projects = \[\n([\s\S]*?)\n  \];/)![1];
const projects = array.match(/    \{\n[\s\S]*?\n    \},/g)!;
const health = projects.find(project => project.includes("t('project_mmm_health_title')"))!;
const digest = (text: string) => createHash('sha256').update(text).digest('hex');
const beforeHealth = (locale: Record<string, string>) => Object.fromEntries(
  Object.entries(locale).filter(([key]) => !key.startsWith('project_mmm_health_')).slice(0, 217),
);

describe('M&M Health portfolio addition', () => {
  it('appends project 16 while preserving the first fifteen projects byte-for-byte and in order', () => {
    expect(projects.slice(0, 16)).toHaveLength(16);
    expect(digest(projects.slice(0, 15).join('\n'))).toBe('7a5c1f796e1616cabfb23f99097870a1bb49eb9cd16e0cde7e8be611fdb73bac');
    const ids = projects.map(project => Number(project.match(/id: (\d+)/)![1]));
    expect(ids).toEqual(Array.from({ length: projects.length }, (_, index) => index + 1));
    expect(new Set(ids).size).toBe(projects.length);
  });

  it('uses the exact user-provided URL once and assigns a unique new project ID', () => {
    expect(health).toContain('id: 16');
    expect(health).toContain('url: "https://mmm-health.vercel.app/"');
    expect(source.match(/url: "https:\/\/mmm-health\.vercel\.app\/"/g)).toHaveLength(1);
  });

  it('reuses the E-Commerce filter and card styling rather than adding unrelated categories', () => {
    expect(health).toContain("category: t('project_category_ecommerce')");
    expect(health).toContain('icon: ShoppingCart');
    expect(health).toContain('featured: false');
    expect(health).toContain('"Product Pages"');
    expect(health).toContain('"Interactive Quiz"');
  });

  it('bundles an optimized actual homepage screenshot and keeps lazy loading', () => {
    expect(source).toContain("import projectMmmHealth from '../assets/project_mmm_health.webp';");
    expect(health).toContain('image: projectMmmHealth');
    expect(source).toContain('loading="lazy"');
    const image = readFileSync('src/assets/project_mmm_health.webp');
    expect(image.subarray(0, 4).toString()).toBe('RIFF');
    expect(image.subarray(8, 12).toString()).toBe('WEBP');
    expect(image.byteLength).toBeLessThan(100_000);
  });

  it('describes the visible storefront and quiz without repeating medical efficacy claims', () => {
    expect(en.project_mmm_health_title).toBe('M&M Health');
    expect(en.project_mmm_health_desc).toContain('storefront');
    expect(en.project_mmm_health_desc).toContain('quiz');
    expect(ar.project_mmm_health_title).toContain('M&M Health');
    expect(ar.project_mmm_health_desc).toContain('اختبارًا تفاعليًا');
    expect(en.project_mmm_health_desc).not.toMatch(/clinically|cures|treats|guaranteed/i);
    expect(health).toContain("description: t('project_mmm_health_desc')");
  });

  it('preserves all 217 existing English values including the accepted Klarna content', () => {
    const original = beforeHealth(en);
    expect(Object.keys(original)).toHaveLength(217);
    expect(digest(JSON.stringify(original))).toBe('dbc97841ab06392d1b6b4b7e7c0bf8ec2a800fb5f4832170b666df39944cb602');
  });

  it('preserves all 217 existing Arabic values and synchronized bilingual keys', () => {
    const original = beforeHealth(ar);
    expect(Object.keys(original)).toHaveLength(217);
    expect(digest(JSON.stringify(original))).toBe('e9978945b783fb9b74c52e0eaf40ebb22aae0c07f945340446c70cc15e64a332');
    expect(Object.keys(en).sort()).toEqual(Object.keys(ar).sort());
    expect(Object.keys(en).slice(0, 219)).toHaveLength(219);
  });

  it('preserves safe new-tab links, localized visit labels and accessible screenshot text', () => {
    expect(source).toMatch(/href=\{project\.url\}\s+target="_blank"\s+rel="noopener noreferrer"/);
    expect(source).toContain('alt={project.title}');
    expect(source).toContain("{t('project_enter_site')}");
  });
});
