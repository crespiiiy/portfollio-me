import { act, cleanup, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import TypewriterHeadline from '../components/TypewriterHeadline';

const english = {
  firstLine: 'Building',
  accentLine: 'Intelligent',
  lastLine: 'Automation Tools',
  direction: 'ltr' as const,
};

const totalCharacters = String(english.firstLine.length + english.accentLine.length + english.lastLine.length);

const advance = (milliseconds: number) => act(() => vi.advanceTimersByTime(milliseconds));

beforeEach(() => vi.useFakeTimers());
afterEach(() => {
  cleanup();
  vi.clearAllTimers();
  vi.useRealTimers();
  vi.restoreAllMocks();
});

describe('Home-page typewriter headline', () => {
  it('exposes the full accessible title immediately, without announcing every letter', () => {
    render(<TypewriterHeadline {...english} />);
    const heading = screen.getByRole('heading', { level: 1, name: 'Building Intelligent Automation Tools' });
    expect(heading).toHaveAttribute('data-typewriter-state', 'waiting');
    expect(heading).toHaveAttribute('data-character-count', '0');
    expect(heading).not.toHaveAttribute('aria-live');
    expect(heading.querySelectorAll('.hero-typewriter-line[aria-hidden="true"]')).toHaveLength(3);
  });

  it('starts promptly, types progressively, and finishes with the exact original copy', () => {
    render(<TypewriterHeadline {...english} />);
    const heading = screen.getByRole('heading');
    advance(319);
    expect(heading).toHaveAttribute('data-character-count', '0');
    advance(1);
    expect(heading).toHaveAttribute('data-character-count', '1');
    expect(heading.querySelector('.hero-typewriter-line')).toHaveAttribute('data-typed-text', 'B');
    advance(600);
    const progress = Number(heading.getAttribute('data-character-count'));
    expect(progress).toBeGreaterThan(1);
    expect(progress).toBeLessThan(Number(totalCharacters));
    advance(4000);
    expect(heading).toHaveAttribute('data-typewriter-state', 'complete');
    expect(heading).toHaveAttribute('data-character-count', totalCharacters);
    expect([...heading.querySelectorAll('.hero-typewriter-line')].map(line => line.getAttribute('data-typed-text')))
      .toEqual(['Building', 'Intelligent', 'Automation Tools']);
  });

  it('reserves full word widths before typing, so line wrapping remains stable', () => {
    render(<TypewriterHeadline {...english} />);
    expect([...document.querySelectorAll('.hero-typewriter-reserve')].map(word => word.textContent))
      .toEqual(['Building', 'Intelligent', 'Automation', 'Tools']);
    expect(document.querySelectorAll('.hero-typewriter-output')[1]).toHaveClass('hero-typewriter-accent');
    expect(document.querySelectorAll('.hero-typewriter-caret')).toHaveLength(1);
  });

  it('runs once, never deletes the title, and leaves no repeating JavaScript timers', () => {
    render(<TypewriterHeadline {...english} />);
    advance(5000);
    expect(screen.getByRole('heading')).toHaveAttribute('data-character-count', totalCharacters);
    expect(vi.getTimerCount()).toBe(0);
    advance(60000);
    expect(screen.getByRole('heading')).toHaveAttribute('data-typewriter-state', 'complete');
  });

  it('does not restart when the rest of the page rerenders', () => {
    const { rerender } = render(<TypewriterHeadline {...english} />);
    advance(700);
    const progress = screen.getByRole('heading').getAttribute('data-character-count');
    rerender(<TypewriterHeadline {...english} />);
    expect(screen.getByRole('heading')).toHaveAttribute('data-character-count', progress);
    advance(4000);
    expect(screen.getByRole('heading')).toHaveAttribute('data-typewriter-state', 'complete');
  });

  it('replays in Arabic on language change and preserves connected words and RTL', () => {
    const { rerender } = render(<TypewriterHeadline key="en" {...english} />);
    advance(5000);
    rerender(<TypewriterHeadline key="ar" firstLine="بناء أدوات أتمتة" accentLine="ذكية ومبتكرة" lastLine="" direction="rtl" />);
    const heading = screen.getByRole('heading', { name: 'بناء أدوات أتمتة ذكية ومبتكرة' });
    expect(heading).toHaveAttribute('dir', 'rtl');
    expect(heading).toHaveAttribute('data-character-count', '0');
    advance(5000);
    expect(heading).toHaveAttribute('data-typewriter-state', 'complete');
    expect([...heading.querySelectorAll('.hero-typewriter-output')].map(word => word.textContent))
      .toEqual(['بناء', 'أدوات', 'أتمتة', 'ذكية', 'ومبتكرة']);
    expect(heading.querySelectorAll('.hero-typewriter-line')).toHaveLength(2);
  });

  it('shows the entire headline immediately when reduced motion is requested', () => {
    const original = window.matchMedia;
    vi.spyOn(window, 'matchMedia').mockImplementation(query => ({ ...original(query), matches: true }));
    render(<TypewriterHeadline {...english} />);
    expect(screen.getByRole('heading')).toHaveAttribute('data-typewriter-state', 'complete');
    expect(screen.getByRole('heading')).toHaveAttribute('data-character-count', totalCharacters);
    expect(document.querySelector('.hero-typewriter-caret')).not.toBeInTheDocument();
    expect(vi.getTimerCount()).toBe(0);
  });

  it('cancels pending typing work when the headline unmounts', () => {
    const { unmount } = render(<TypewriterHeadline {...english} />);
    advance(700);
    unmount();
    expect(vi.getTimerCount()).toBe(0);
  });
});
