import { act, cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { readFileSync } from 'node:fs';
import DesktopHeroVideo from '../components/DesktopHeroVideo';
import { DESKTOP_HERO_POSTER, DESKTOP_HERO_QUERY, DESKTOP_HERO_VIDEO, HERO_REDUCED_MOTION_QUERY } from '../lib/desktop-hero';
import { INTRO_READY_EVENT } from '../lib/page-intro';

type Notify = () => void;
const matches = new Map<string, boolean>();
const subscribers = new Map<string, Set<Notify>>();
let intersection: IntersectionObserverCallback;
let disconnect: ReturnType<typeof vi.fn>;
let play: ReturnType<typeof vi.spyOn>;
let pause: ReturnType<typeof vi.spyOn>;
let hidden = false;

function setQuery(query: string, value: boolean) {
  matches.set(query, value);
  act(() => subscribers.get(query)?.forEach(notify => notify()));
}
const video = () => document.querySelector('video') as HTMLVideoElement;

beforeEach(() => {
  matches.clear(); subscribers.clear(); hidden = false;
  matches.set(DESKTOP_HERO_QUERY, true);
  vi.spyOn(window, 'matchMedia').mockImplementation(query => ({
    get matches() { return matches.get(query) || false; },
    media: query, onchange: null, addListener: () => {}, removeListener: () => {},
    addEventListener: (_type, notify) => {
      if (!subscribers.has(query)) subscribers.set(query, new Set());
      subscribers.get(query)?.add(notify as Notify);
    },
    removeEventListener: (_type, notify) => subscribers.get(query)?.delete(notify as Notify),
    dispatchEvent: () => true,
  }));
  play = vi.spyOn(HTMLMediaElement.prototype, 'play').mockResolvedValue();
  pause = vi.spyOn(HTMLMediaElement.prototype, 'pause').mockImplementation(() => {});
  vi.spyOn(document, 'hidden', 'get').mockImplementation(() => hidden);
  disconnect = vi.fn();
  vi.stubGlobal('IntersectionObserver', class {
    constructor(callback: IntersectionObserverCallback) { intersection = callback; }
    observe = vi.fn(); unobserve = vi.fn(); disconnect = disconnect;
  });
});

afterEach(() => {
  cleanup();
  delete document.documentElement.dataset.siteIntro;
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
});

describe('Desktop cinematic hero', () => {
  it('does not mount any cinema, video or poster source on a phone', () => {
    matches.set(DESKTOP_HERO_QUERY, false);
    const { container } = render(<DesktopHeroVideo />);
    expect(container).toBeEmptyDOMElement();
    expect(play).not.toHaveBeenCalled();
  });

  it('requires both desktop width and a fine hover-capable input', () => {
    expect(DESKTOP_HERO_QUERY).toBe('(min-width: 1024px) and (hover: hover) and (pointer: fine)');
  });

  it('automatically plays a local muted, inline, looping video without native controls', () => {
    render(<DesktopHeroVideo />);
    expect(video()).toHaveAttribute('src', DESKTOP_HERO_VIDEO);
    expect(video()).toHaveAttribute('poster', DESKTOP_HERO_POSTER);
    expect(video()).toHaveAttribute('autoplay');
    expect(video()).toHaveAttribute('loop');
    expect(video()).toHaveAttribute('playsinline');
    expect(video()).toHaveAttribute('tabindex', '-1');
    expect(video()).not.toHaveAttribute('controls');
    expect(video()).toHaveAttribute('disablepictureinpicture');
    expect(video()).toHaveAttribute('disableremoteplayback');
    expect(video().muted).toBe(true);
    expect(video().defaultMuted).toBe(true);
    expect(play).toHaveBeenCalled();
  });

  it('waits until the logo intro has disappeared before beginning playback', () => {
    document.documentElement.dataset.siteIntro = 'loading';
    render(<DesktopHeroVideo />);
    expect(play).not.toHaveBeenCalled();
    expect(video()).not.toHaveAttribute('autoplay');
    fireEvent.canPlay(video());
    fireEvent.pointerDown(document);
    expect(play).not.toHaveBeenCalled();
    act(() => { document.documentElement.dataset.siteIntro = 'leaving'; });
    expect(play).not.toHaveBeenCalled();
    act(() => {
      document.documentElement.dataset.siteIntro = 'ready';
      window.dispatchEvent(new Event(INTRO_READY_EVENT));
    });
    expect(play).toHaveBeenCalled();
    expect(video()).toHaveAttribute('autoplay');
  });

  it('shows only the poster and never mounts a video for reduced motion', () => {
    matches.set(HERO_REDUCED_MOTION_QUERY, true);
    const { container } = render(<DesktopHeroVideo />);
    expect(container.querySelector('[data-video-state="reduced-motion"]')).toBeInTheDocument();
    expect(container.querySelector('.hero-cinema-scene')).toHaveStyle({ backgroundImage: `url("${DESKTOP_HERO_POSTER}")` });
    expect(video()).toBeNull();
    expect(screen.queryByRole('button')).toBeNull();
    expect(play).not.toHaveBeenCalled();
  });

  it('has no visible or hidden play/pause button and adds no keyboard stop', () => {
    const { container } = render(<DesktopHeroVideo />);
    expect(container.querySelector('button, [role="button"], .hero-cinema-control')).toBeNull();
    expect(container.querySelector('.hero-cinema')).toHaveAttribute('aria-hidden', 'true');
    expect(container.querySelectorAll('[tabindex]:not([tabindex="-1"])')).toHaveLength(0);
  });

  it('retains the poster if the video cannot load', () => {
    const { container } = render(<DesktopHeroVideo />);
    fireEvent.error(video());
    expect(container.querySelector('[data-video-state="fallback"]')).toBeInTheDocument();
    expect(container.querySelector('.hero-cinema-scene')).toBeInTheDocument();
    expect(video()).toBeNull();
    expect(screen.queryByRole('button')).toBeNull();
  });

  it('fades the video in only after a frame has loaded', () => {
    render(<DesktopHeroVideo />);
    expect(video()).not.toHaveClass('is-frame-ready');
    fireEvent.loadedData(video());
    expect(video()).toHaveClass('is-frame-ready');
  });

  it('mounts or removes media when crossing the desktop breakpoint', () => {
    matches.set(DESKTOP_HERO_QUERY, false);
    render(<DesktopHeroVideo />);
    expect(video()).toBeNull();
    setQuery(DESKTOP_HERO_QUERY, true);
    expect(video()).toHaveAttribute('src', DESKTOP_HERO_VIDEO);
    setQuery(DESKTOP_HERO_QUERY, false);
    expect(video()).toBeNull();
  });

  it('pauses offscreen and resumes automatically when the hero is visible', () => {
    render(<DesktopHeroVideo />);
    const initial = play.mock.calls.length;
    act(() => intersection([{ isIntersecting: false } as IntersectionObserverEntry], {} as IntersectionObserver));
    expect(pause).toHaveBeenCalled();
    expect(video()).not.toHaveAttribute('autoplay');
    act(() => intersection([{ isIntersecting: true } as IntersectionObserverEntry], {} as IntersectionObserver));
    expect(play.mock.calls.length).toBeGreaterThan(initial);
    expect(video()).toHaveAttribute('autoplay');
  });

  it('does not let data or interaction events resume an offscreen background', () => {
    render(<DesktopHeroVideo />);
    act(() => intersection([{ isIntersecting: false } as IntersectionObserverEntry], {} as IntersectionObserver));
    const calls = play.mock.calls.length;
    fireEvent.canPlay(video());
    fireEvent.pointerDown(document);
    fireEvent.keyDown(document);
    fireEvent.focus(window);
    expect(play.mock.calls.length).toBe(calls);
  });

  it('pauses in a background tab and resumes when the page becomes visible', () => {
    render(<DesktopHeroVideo />);
    const initial = play.mock.calls.length;
    act(() => { hidden = true; document.dispatchEvent(new Event('visibilitychange')); });
    expect(pause).toHaveBeenCalled();
    act(() => { hidden = false; document.dispatchEvent(new Event('visibilitychange')); });
    expect(play.mock.calls.length).toBeGreaterThan(initial);
  });

  it('cleans up media-query listeners, the observer and all playback retries on unmount', () => {
    const { unmount } = render(<DesktopHeroVideo />);
    unmount();
    expect(disconnect).toHaveBeenCalled();
    expect(pause).toHaveBeenCalled();
    expect([...subscribers.values()].every(listeners => listeners.size === 0)).toBe(true);
    const calls = play.mock.calls.length;
    fireEvent.pointerDown(document);
    fireEvent.keyDown(document);
    fireEvent.focus(window);
    expect(play.mock.calls.length).toBe(calls);
  });

  it('keeps the exact requested English headline, description, availability and CTA', () => {
    const en = JSON.parse(readFileSync('src/locales/en.json', 'utf8'));
    expect(en.hero_availability).toBe('Available for new projects');
    expect([en.hero_title1, en.hero_title2, en.hero_title3]).toEqual(['Building', 'Intelligent', 'Automation Tools']);
    expect(en.hero_description).toBe('I craft Telegram bots, automation systems, and high-impact visual designs that help businesses scale and stand out in the digital landscape.');
    expect(en.hero_cta_work).toBe('View My Work');
    expect(en.hero_projects_delivered).toBe('Projects Delivered');
    const portfolio = readFileSync('src/components/PremiumPortfolio.tsx', 'utf8');
    expect(portfolio).toContain('>50+</span>');
    expect(portfolio).toContain("{i === 4 ? '+' : ''}");
  });

  it('preserves Arabic/RTL scenery without introducing a translated player control', () => {
    const { container } = render(<DesktopHeroVideo isRTL />);
    expect(container.querySelector('.hero-cinema')).toHaveAttribute('data-cinema-direction', 'rtl');
    expect(container.querySelector('button, [title], [aria-label]')).toBeNull();
    expect(video()).toHaveAttribute('autoplay');
  });

  it('quietly retries a rejected autoplay on canplay instead of creating a manual pause state', async () => {
    play.mockRejectedValueOnce(new DOMException('Autoplay blocked', 'NotAllowedError'));
    const { container } = render(<DesktopHeroVideo />);
    await act(async () => { await Promise.resolve(); });
    expect(container.querySelector('.hero-cinema-control')).toBeNull();
    expect(video()).toHaveAttribute('autoplay');
    const calls = play.mock.calls.length;
    fireEvent.canPlay(video());
    expect(play.mock.calls.length).toBeGreaterThan(calls);
  });

  it('automatically retries after ordinary interaction without needing a playback button', () => {
    render(<DesktopHeroVideo />);
    const calls = play.mock.calls.length;
    fireEvent.pointerDown(document);
    expect(play.mock.calls.length).toBeGreaterThan(calls);
  });

  it('reacts to a changed system reduced-motion preference without leaving a video source', () => {
    render(<DesktopHeroVideo />);
    expect(video()).not.toBeNull();
    setQuery(HERO_REDUCED_MOTION_QUERY, true);
    expect(video()).toBeNull();
    expect(pause).toHaveBeenCalled();
    setQuery(HERO_REDUCED_MOTION_QUERY, false);
    expect(video()).toHaveAttribute('autoplay');
  });
});
