import { act, cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { createInstance, type i18n as I18n } from 'i18next';
import { I18nextProvider, initReactI18next } from 'react-i18next';
import EditorialAbout from '../components/EditorialAbout';
import { HERO_REDUCED_MOTION_QUERY } from '../lib/desktop-hero';
import en from '../locales/en.json';
import ar from '../locales/ar.json';

type Notify = () => void;
let i18n: I18n;
let reduced = false;
let hidden = false;
let intersection: IntersectionObserverCallback;
let disconnect: ReturnType<typeof vi.fn>;
const subscribers = new Set<Notify>();
const section = () => document.querySelector<HTMLElement>('[data-desktop-editorial]')!;
const buttons = () => [...section().querySelectorAll<HTMLButtonElement>('.about-principle button')];
const openPanels = () => within(section().querySelector<HTMLElement>('.about-editorial-principles')!).queryAllByRole('region');
const visible = (isIntersecting: boolean) => act(() => intersection([{ isIntersecting } as IntersectionObserverEntry], {} as IntersectionObserver));
const renderAbout = (onContact = vi.fn()) => render(<I18nextProvider i18n={i18n}><EditorialAbout onContact={onContact} /></I18nextProvider>);

beforeEach(async () => {
  reduced = false; hidden = false; subscribers.clear();
  i18n = createInstance();
  await i18n.use(initReactI18next).init({
    lng: 'en', fallbackLng: 'en', resources: { en: { translation: en }, ar: { translation: ar } },
    interpolation: { escapeValue: false },
  });
  vi.spyOn(window, 'matchMedia').mockImplementation(query => ({
    get matches() { return query === HERO_REDUCED_MOTION_QUERY && reduced; },
    media: query, onchange: null, addListener: () => {}, removeListener: () => {},
    addEventListener: (_type, notify) => subscribers.add(notify as Notify),
    removeEventListener: (_type, notify) => subscribers.delete(notify as Notify),
    dispatchEvent: () => true,
  }));
  vi.spyOn(document, 'hidden', 'get').mockImplementation(() => hidden);
  disconnect = vi.fn();
  vi.stubGlobal('IntersectionObserver', class {
    constructor(callback: IntersectionObserverCallback) { intersection = callback; }
    observe = vi.fn(); unobserve = vi.fn(); disconnect = disconnect;
  });
});

afterEach(() => { cleanup(); vi.restoreAllMocks(); vi.unstubAllGlobals(); });

describe('Desktop cinematic editorial About', () => {
  it('retains the existing professional story, four principles and honest 7+/50+ figures', () => {
    renderAbout();
    expect(screen.getByRole('heading', { level: 2, name: en.about_title })).toBeInTheDocument();
    expect(screen.getByText(en.about_paragraph1)).toBeInTheDocument();
    expect(screen.getByText(en.about_paragraph2)).toBeInTheDocument();
    expect(buttons()).toHaveLength(4);
    expect(section().querySelectorAll('.about-editorial-specialties li')).toHaveLength(3);
    expect([...section().querySelectorAll('dd')].map(el => el.textContent)).toEqual(['7+', '50+']);
    expect(screen.getByRole('button', { name: en.about_editorial_cta })).toBeInTheDocument();
    expect(section().textContent).not.toContain('®');
    expect(section().textContent).not.toMatch(/download|\bCV\b|5\.0/);
  });

  it('uses one lazy, decorative local artwork and four SVG diagrams, without adding another video', () => {
    renderAbout();
    const artwork = section().querySelector('img')!;
    expect(artwork.getAttribute('src')).toContain('about-identity.webp');
    expect(artwork).toHaveAttribute('loading', 'lazy');
    expect(artwork).toHaveAttribute('alt', '');
    expect(artwork).toHaveAttribute('aria-hidden', 'true');
    expect(artwork).toHaveAttribute('width', '896');
    expect(artwork).toHaveAttribute('height', '1120');
    expect(section().querySelectorAll('video, iframe, canvas')).toHaveLength(0);
    expect(section().querySelectorAll('.about-principle-diagram[aria-hidden="true"]')).toHaveLength(4);
  });

  it('connects native disclosure buttons and regions with unique accessible IDs', () => {
    renderAbout();
    for (const [index, button] of buttons().entries()) {
      const panel = document.getElementById(button.getAttribute('aria-controls')!)!;
      expect(panel).toHaveAttribute('role', 'region');
      expect(panel).toHaveAttribute('aria-labelledby', button.id);
      expect(button).toHaveAttribute('type', 'button');
      expect(button).toHaveAttribute('aria-expanded', String(index === 0));
      expect(panel).toHaveAttribute('aria-hidden', String(index !== 0));
    }
    expect(openPanels()).toHaveLength(1);
    expect(screen.getByText(en.about_feature1_desc)).toBeInTheDocument();
  });

  it('opens only one principle at a time and allows the active row to close', () => {
    renderAbout();
    fireEvent.click(buttons()[2]);
    expect(buttons().map(b => b.getAttribute('aria-expanded'))).toEqual(['false', 'false', 'true', 'false']);
    expect(screen.getByRole('region', { name: en.about_feature3_title })).toHaveAttribute('aria-hidden', 'false');
    fireEvent.click(buttons()[2]);
    expect(buttons().every(b => b.getAttribute('aria-expanded') === 'false')).toBe(true);
    expect(openPanels()).toHaveLength(0);
    fireEvent.click(buttons()[3]);
    expect(screen.getByRole('region', { name: en.about_feature4_title })).toBeInTheDocument();
  });

  it('supports ArrowUp/Down, Home and End focus navigation without changing selection', () => {
    renderAbout();
    const rows = buttons(); rows[0].focus();
    fireEvent.keyDown(rows[0], { key: 'ArrowDown' }); expect(rows[1]).toHaveFocus();
    fireEvent.keyDown(rows[1], { key: 'End' }); expect(rows[3]).toHaveFocus();
    fireEvent.keyDown(rows[3], { key: 'ArrowDown' }); expect(rows[0]).toHaveFocus();
    fireEvent.keyDown(rows[0], { key: 'ArrowUp' }); expect(rows[3]).toHaveFocus();
    fireEvent.keyDown(rows[3], { key: 'Home' }); expect(rows[0]).toHaveFocus();
    expect(rows[0]).toHaveAttribute('aria-expanded', 'true');
  });

  it('uses exactly one contact CTA and delegates to the existing contact flow', () => {
    const onContact = vi.fn(); renderAbout(onContact);
    expect(section().querySelectorAll('button')).toHaveLength(5);
    expect(section().querySelectorAll('a')).toHaveLength(0);
    fireEvent.click(screen.getByRole('button', { name: en.about_editorial_cta }));
    expect(onContact).toHaveBeenCalledTimes(1);
  });

  it('updates the complete editorial content and direction for Arabic while retaining facts', async () => {
    renderAbout();
    await act(async () => { await i18n.changeLanguage('ar'); });
    expect(section()).toHaveAttribute('dir', 'rtl');
    expect(screen.getByRole('heading', { level: 2, name: ar.about_title })).toBeInTheDocument();
    expect(screen.getByText(ar.about_paragraph1)).toBeInTheDocument();
    expect(screen.getByText(ar.about_editorial_title_start)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: ar.about_editorial_cta })).toBeInTheDocument();
    expect([...section().querySelectorAll('dd')].map(el => el.textContent)).toEqual(['7+', '50+']);
    expect(section().textContent).not.toMatch(/about_editorial_/);
  });

  it('reveals only once on entry and pauses subtle animation when offscreen', () => {
    renderAbout();
    expect(section()).toHaveAttribute('data-entered', 'false');
    expect(section()).toHaveAttribute('data-motion', 'paused');
    visible(true);
    expect(section()).toHaveAttribute('data-entered', 'true');
    expect(section()).toHaveAttribute('data-motion', 'running');
    visible(false);
    expect(section()).toHaveAttribute('data-entered', 'true');
    expect(section()).toHaveAttribute('data-motion', 'paused');
  });

  it('stops animation in a hidden document and resumes only while visible', () => {
    renderAbout(); visible(true);
    act(() => { hidden = true; document.dispatchEvent(new Event('visibilitychange')); });
    expect(section()).toHaveAttribute('data-motion', 'paused');
    act(() => { hidden = false; document.dispatchEvent(new Event('visibilitychange')); });
    expect(section()).toHaveAttribute('data-motion', 'running');
  });

  it('respects reduced motion initially and when the preference changes live', () => {
    reduced = true; renderAbout(); visible(true);
    expect(section()).toHaveAttribute('data-entered', 'true');
    expect(section()).toHaveAttribute('data-motion', 'paused');
    act(() => { reduced = false; subscribers.forEach(notify => notify()); });
    expect(section()).toHaveAttribute('data-motion', 'running');
    act(() => { reduced = true; subscribers.forEach(notify => notify()); });
    expect(section()).toHaveAttribute('data-motion', 'paused');
  });

  it('shows all content safely when IntersectionObserver is unavailable', () => {
    vi.stubGlobal('IntersectionObserver', undefined); renderAbout();
    expect(section()).toHaveAttribute('data-entered', 'true');
    expect(section()).toHaveAttribute('data-motion', 'running');
    expect(within(section()).getByRole('button', { name: en.about_editorial_cta })).toBeInTheDocument();
  });

  it('disconnects observers, media and visibility subscriptions on unmount', () => {
    const remove = vi.spyOn(document, 'removeEventListener');
    const { unmount } = renderAbout();
    expect(subscribers.size).toBe(1); unmount();
    expect(disconnect).toHaveBeenCalledTimes(1);
    expect(subscribers.size).toBe(0);
    expect(remove).toHaveBeenCalledWith('visibilitychange', expect.any(Function));
  });
});
