import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';
import en from '../locales/en.json';
import ar from '../locales/ar.json';

const source = readFileSync('src/components/PremiumPortfolio.tsx', 'utf8');
const projectArray = source.match(/  const projects = \[\n([\s\S]*?)\n  \];/)![1];
const projectObjects = projectArray.match(/    \{\n[\s\S]*?\n    \},/g)!;
const klarna = projectObjects.find(project => project.includes("t('project_klarna_title')"))!;
const digest = (text: string) => createHash('sha256').update(text).digest('hex');
const withoutKlarna = (locale: Record<string, string>) => Object.fromEntries(
  Object.entries(locale).filter(([key]) => !key.startsWith('project_klarna_')).slice(0, 215),
);

describe('Klarna portfolio project addition', () => {
  it('adds a fifteenth uniquely identified project without modifying the original fourteen', () => {
    expect(projectObjects.slice(0, 15)).toHaveLength(15);
    expect(digest(projectObjects.slice(0, 14).join('\n'))).toBe('1e1f923ca82983954b349fb61e462dfe11b5ba2ec90f8e8128f74c7f557a6bd0');
    const ids = projectObjects.slice(0, 15).map(project => Number(project.match(/id: (\d+)/)![1]));
    expect(ids).toEqual(Array.from({ length: 15 }, (_, index) => index + 1));
    expect(new Set(ids).size).toBe(15);
  });

  it('links to the exact user-provided deployment once, not the official Klarna site', () => {
    expect(klarna).toContain('url: "https://klarna-homepage-recreation.vercel.app/"');
    expect(source.match(/url: "https:\/\/klarna-homepage-recreation\.vercel\.app\/"/g)).toHaveLength(1);
    expect(klarna).toContain('id: 15');
  });

  it('uses the existing Landing Page category without changing project filters', () => {
    expect(klarna).toContain("category: t('project_category_landing_page')");
    expect(klarna).toContain('icon: Layout');
    expect(klarna).toContain('featured: false');
  });

  it('uses a bundled real homepage screenshot through the existing lazy-loaded card', () => {
    expect(source).toContain("import projectKlarna from '../assets/project_klarna.webp';");
    expect(klarna).toContain('image: projectKlarna');
    expect(source).toContain('loading="lazy"');
    const image = readFileSync('src/assets/project_klarna.webp');
    expect(image.subarray(0, 4).toString()).toBe('RIFF');
    expect(image.subarray(8, 12).toString()).toBe('WEBP');
    expect(image.byteLength).toBeLessThan(100_000);
  });

  it('clearly describes a homepage recreation in both languages rather than a working banking platform', () => {
    expect(en.project_klarna_title).toBe('Klarna Homepage Recreation');
    expect(en.project_klarna_desc).toContain('recreation');
    expect(ar.project_klarna_title).toContain('محاكاة');
    expect(ar.project_klarna_desc).toContain('محاكاة');
    expect(klarna).toContain("description: t('project_klarna_desc')");
    expect(klarna).toContain('"Hero Slider"');
  });

  it('preserves all 215 pre-existing English translation values exactly', () => {
    const original = withoutKlarna(en);
    expect(Object.keys(original)).toHaveLength(215);
    expect(digest(JSON.stringify(original))).toBe('43ca42cb48a7bdfa39498ba1ca4d7afb907f851733cf9ed65cc2f8124123003c');
  });

  it('preserves all 215 pre-existing Arabic values and keeps the 217 bilingual keys synchronized', () => {
    const original = withoutKlarna(ar);
    expect(Object.keys(original)).toHaveLength(215);
    expect(digest(JSON.stringify(original))).toBe('1e5ad3e0d6a2ae4b30417673faea475395c896573c9459f75265bacc068c8000');
    expect(Object.keys(en).sort()).toEqual(Object.keys(ar).sort());
    expect(Object.keys(en).slice(0, 217)).toHaveLength(217);
  });

  it('preserves safe external-link and accessible-image behavior for every project card', () => {
    expect(source).toMatch(/href=\{project\.url\}\s+target="_blank"\s+rel="noopener noreferrer"/);
    expect(source).toContain('alt={project.title}');
    expect(source).toContain("{t('project_enter_site')}");
  });
});
