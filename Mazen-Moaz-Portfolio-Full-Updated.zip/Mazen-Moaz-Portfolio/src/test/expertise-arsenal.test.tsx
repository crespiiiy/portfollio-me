import { act, cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { createInstance, type i18n as I18n } from 'i18next';
import { I18nextProvider, initReactI18next, useTranslation } from 'react-i18next';
import { Bot, Code2, Palette, Zap, Layers, Database } from 'lucide-react';
import ExpertiseArsenal from '../components/ExpertiseArsenal';
import { ARSENAL_CAPABILITIES, ARSENAL_TECHNOLOGIES } from '../lib/expertise';
import { HERO_REDUCED_MOTION_QUERY } from '../lib/desktop-hero';
import en from '../locales/en.json';
import ar from '../locales/ar.json';

type Notify = () => void;
let i18n: I18n;
let reduced = false;
let hidden = false;
let intersection: IntersectionObserverCallback;
let disconnect: ReturnType<typeof vi.fn>;
const subscribers = new Set<Notify>();
const levels = [95, 90, 88, 92, 85, 87];
const names = ['skill_bot_development', 'skill_web_development', 'skill_ui_ux_design', 'skill_automation', 'skill_api_integration', 'skill_data_scraping'] as const;
const icons = [Bot, Code2, Palette, Zap, Layers, Database];
const originalTools = ['Python', 'JavaScript', 'React', 'Node.js', 'Telegram API', 'TensorFlow', 'PostgreSQL', 'Redis', 'Docker', 'AWS', 'Figma', 'Adobe CC'];
const section = () => document.querySelector<HTMLElement>('[data-desktop-arsenal]')!;
const tabs = () => within(section()).getAllByRole('tab');
const associated = () => [...section().querySelectorAll<HTMLElement>('.arsenal-tool[data-associated="true"]')].map(el => el.dataset.tool);
const visible = (isIntersecting: boolean) => act(() => intersection([{ isIntersecting } as IntersectionObserverEntry], {} as IntersectionObserver));
function Fixture() {
  const { t } = useTranslation();
  return <ExpertiseArsenal skills={names.map((name, index) => ({ name: t(name), level: levels[index], icon: icons[index], color: '' }))} />;
}
const renderArsenal = () => render(<I18nextProvider i18n={i18n}><Fixture /></I18nextProvider>);

beforeEach(async () => {
  reduced = false; hidden = false; subscribers.clear();
  i18n = createInstance();
  await i18n.use(initReactI18next).init({
    lng: 'en', fallbackLng: 'en', resources: { en: { translation: en }, ar: { translation: ar } },
    interpolation: { escapeValue: false },
  });
  vi.spyOn(window, 'matchMedia').mockImplementation(query => ({
    get matches() { return query === HERO_REDUCED_MOTION_QUERY && reduced; },
    media: query, onchange: null, addListener: () => {}, removeListener: () => {},
    addEventListener: (_type, notify) => subscribers.add(notify as Notify),
    removeEventListener: (_type, notify) => subscribers.delete(notify as Notify),
    dispatchEvent: () => true,
  }));
  vi.spyOn(document, 'hidden', 'get').mockImplementation(() => hidden);
  disconnect = vi.fn();
  vi.stubGlobal('IntersectionObserver', class {
    constructor(callback: IntersectionObserverCallback) { intersection = callback; }
    observe = vi.fn(); unobserve = vi.fn(); disconnect = disconnect;
  });
});

afterEach(() => { cleanup(); vi.restoreAllMocks(); vi.unstubAllGlobals(); });

describe('Connected Arsenal desktop Skills', () => {
  it('retains the six original skills and their exact proficiency values in one section', () => {
    renderArsenal();
    expect(document.querySelectorAll('#skills')).toHaveLength(1);
    expect(screen.getByRole('heading', { level: 2, name: en.skills_title })).toBeInTheDocument();
    expect(tabs().map(tab => tab.getAttribute('aria-label'))).toEqual(names.map((name, index) => `${en[name]} — ${levels[index]}%`));
    expect(section().textContent).not.toMatch(/download|\bCV\b|arsenal_/);
  });

  it('retains exactly the twelve existing technologies without creating new tools or claims', () => {
    renderArsenal();
    expect(ARSENAL_TECHNOLOGIES.map(tool => tool.name)).toEqual(originalTools);
    expect([...section().querySelectorAll<HTMLElement>('.arsenal-tool')].map(el => el.dataset.tool)).toEqual(originalTools);
    expect(screen.getByRole('list', { name: en.skills_tech_stack_title }).children).toHaveLength(12);
    expect(new Set(ARSENAL_CAPABILITIES.flatMap(capability => [...capability.tools]))).toEqual(new Set(originalTools));
  });

  it('uses connected native tabs, a single labelled panel and an accessible meter', () => {
    renderArsenal();
    expect(screen.getByRole('tablist', { name: en.arsenal_capabilities_label })).toBeInTheDocument();
    const panel = screen.getByRole('tabpanel', { name: `${en.skill_bot_development} — 95%` });
    expect(panel).toHaveAttribute('tabindex', '0');
    for (const [index, tab] of tabs().entries()) {
      expect(tab).toHaveAttribute('type', 'button');
      expect(tab).toHaveAttribute('aria-selected', String(index === 0));
      expect(tab).toHaveAttribute('tabindex', index === 0 ? '0' : '-1');
      expect(tab).toHaveAttribute('aria-controls', panel.id);
      expect(tab.id).not.toBe('');
    }
    expect(panel).toHaveAttribute('aria-labelledby', tabs()[0].id);
    expect(screen.getByRole('meter')).toHaveAttribute('aria-valuenow', '95');
    expect(screen.getByRole('meter')).toHaveAttribute('aria-valuetext', '95%');
    expect(screen.getByRole('meter')).toHaveAttribute('aria-valuemin', '0');
    expect(screen.getByRole('meter')).toHaveAttribute('aria-valuemax', '100');
  });

  it('updates each of the six descriptions, meters and network associations on selection', () => {
    renderArsenal();
    for (const [index, capability] of ARSENAL_CAPABILITIES.entries()) {
      fireEvent.click(tabs()[index]);
      expect(tabs().filter(tab => tab.getAttribute('aria-selected') === 'true')).toEqual([tabs()[index]]);
      expect(screen.getByRole('tabpanel')).toHaveAttribute('aria-labelledby', tabs()[index].id);
      expect(screen.getByRole('heading', { level: 3, name: en[names[index]] })).toBeInTheDocument();
      expect(screen.getByText(en[capability.description])).toBeInTheDocument();
      expect(screen.getByRole('meter')).toHaveAttribute('aria-valuenow', String(levels[index]));
      expect(new Set(associated())).toEqual(new Set(capability.tools));
      expect(section().querySelectorAll('.arsenal-tool')).toHaveLength(12);
      expect(section().querySelectorAll('.arsenal-connections .is-associated')).toHaveLength(capability.tools.length);
    }
  });

  it('keeps exactly one selected tab when the active choice is clicked again', () => {
    renderArsenal();
    fireEvent.click(tabs()[0]); fireEvent.click(tabs()[0]);
    expect(tabs()[0]).toHaveAttribute('aria-selected', 'true');
    expect(screen.getAllByRole('tabpanel')).toHaveLength(1);
    expect(screen.getByRole('heading', { level: 3, name: en.skill_bot_development })).toBeInTheDocument();
  });

  it('supports roving Left/Right focus, automatic activation, wrap-around, Home and End', () => {
    renderArsenal();
    const rows = tabs(); rows[0].focus();
    fireEvent.keyDown(rows[0], { key: 'ArrowRight' }); expect(rows[1]).toHaveFocus();
    expect(rows[1]).toHaveAttribute('aria-selected', 'true');
    fireEvent.keyDown(rows[1], { key: 'End' }); expect(rows[5]).toHaveFocus();
    fireEvent.keyDown(rows[5], { key: 'ArrowRight' }); expect(rows[0]).toHaveFocus();
    fireEvent.keyDown(rows[0], { key: 'ArrowLeft' }); expect(rows[5]).toHaveFocus();
    fireEvent.keyDown(rows[5], { key: 'Home' }); expect(rows[0]).toHaveFocus();
    fireEvent.keyDown(rows[0], { key: 'Escape' }); expect(rows[0]).toHaveFocus();
    expect(rows.filter(row => row.tabIndex === 0)).toEqual([rows[0]]);
  });

  it('translates the complete experience and keeps technology names LTR in Arabic', async () => {
    renderArsenal(); fireEvent.click(tabs()[2]);
    await act(async () => { await i18n.changeLanguage('ar'); });
    expect(section()).toHaveAttribute('dir', 'rtl');
    expect(screen.getByRole('heading', { level: 2, name: ar.skills_title })).toBeInTheDocument();
    expect(screen.getByRole('heading', { level: 3, name: ar.skill_ui_ux_design })).toBeInTheDocument();
    expect(screen.getByText(ar.arsenal_design_desc)).toBeInTheDocument();
    expect(screen.getByRole('meter')).toHaveAttribute('aria-valuenow', '88');
    expect(screen.getByRole('list', { name: ar.skills_tech_stack_title }).closest('[dir="ltr"]')).toBeInTheDocument();
    expect(section().textContent).not.toMatch(/arsenal_|skill_/);
    expect([...section().querySelectorAll<HTMLElement>('.arsenal-tool')].map(el => el.dataset.tool)).toEqual(originalTools);
  });

  it('mirrors horizontal arrow navigation in RTL without reversing Home/End semantics', async () => {
    await i18n.changeLanguage('ar'); renderArsenal(); const rows = tabs();
    rows[0].focus(); fireEvent.keyDown(rows[0], { key: 'ArrowLeft' }); expect(rows[1]).toHaveFocus();
    fireEvent.keyDown(rows[1], { key: 'ArrowRight' }); expect(rows[0]).toHaveFocus();
    fireEvent.keyDown(rows[0], { key: 'ArrowRight' }); expect(rows[5]).toHaveFocus();
    fireEvent.keyDown(rows[5], { key: 'Home' }); expect(rows[0]).toHaveFocus();
    fireEvent.keyDown(rows[0], { key: 'End' }); expect(rows[5]).toHaveFocus();
  });

  it('uses one lazy decorative local WebP and a decorative SVG, with no video or additional controls', () => {
    renderArsenal(); const artwork = section().querySelector('img')!;
    expect(artwork).toHaveAttribute('loading', 'lazy');
    expect(artwork).toHaveAttribute('decoding', 'async');
    expect(artwork).toHaveAttribute('alt', '');
    expect(artwork.closest('[aria-hidden="true"]')).toBeInTheDocument();
    expect(artwork).toHaveAttribute('width', '768'); expect(artwork).toHaveAttribute('height', '768');
    expect(artwork.getAttribute('src')).toContain('arsenal-core.webp');
    expect(section().querySelector('.arsenal-connections')).toHaveAttribute('aria-hidden', 'true');
    expect(section().querySelectorAll('video, iframe, canvas, a')).toHaveLength(0);
    expect(section().querySelectorAll('button')).toHaveLength(6);
  });

  it('reveals once and runs decorative motion only while the section is in view', () => {
    renderArsenal(); expect(section()).toHaveAttribute('data-entered', 'false');
    expect(section()).toHaveAttribute('data-motion', 'paused');
    visible(true); expect(section()).toHaveAttribute('data-entered', 'true');
    expect(section()).toHaveAttribute('data-motion', 'running');
    visible(false); expect(section()).toHaveAttribute('data-entered', 'true');
    expect(section()).toHaveAttribute('data-motion', 'paused');
    visible(true); expect(section()).toHaveAttribute('data-motion', 'running');
  });

  it('pauses in a hidden document and does not resume until the section is visible', () => {
    renderArsenal(); visible(true);
    act(() => { hidden = true; document.dispatchEvent(new Event('visibilitychange')); });
    expect(section()).toHaveAttribute('data-motion', 'paused');
    visible(false);
    act(() => { hidden = false; document.dispatchEvent(new Event('visibilitychange')); });
    expect(section()).toHaveAttribute('data-motion', 'paused');
    visible(true); expect(section()).toHaveAttribute('data-motion', 'running');
  });

  it('respects reduced motion on initial render and when the preference changes live', () => {
    reduced = true; renderArsenal(); visible(true);
    expect(section()).toHaveAttribute('data-entered', 'true');
    expect(section()).toHaveAttribute('data-motion', 'paused');
    act(() => { reduced = false; subscribers.forEach(notify => notify()); });
    expect(section()).toHaveAttribute('data-motion', 'running');
    act(() => { reduced = true; subscribers.forEach(notify => notify()); });
    expect(section()).toHaveAttribute('data-motion', 'paused');
  });

  it('renders visible content safely if IntersectionObserver is unavailable', () => {
    vi.stubGlobal('IntersectionObserver', undefined); renderArsenal();
    expect(section()).toHaveAttribute('data-entered', 'true');
    expect(section()).toHaveAttribute('data-motion', 'running');
    expect(screen.getByRole('heading', { level: 2, name: en.skills_title })).toBeInTheDocument();
  });

  it('disconnects intersection, media and document visibility subscriptions on unmount', () => {
    const remove = vi.spyOn(document, 'removeEventListener');
    const { unmount } = renderArsenal(); expect(subscribers.size).toBe(1);
    unmount(); expect(disconnect).toHaveBeenCalledTimes(1);
    expect(subscribers.size).toBe(0);
    expect(remove).toHaveBeenCalledWith('visibilitychange', expect.any(Function));
  });

  it('keeps generated IDs unique when multiple component instances are tested', () => {
    renderArsenal(); renderArsenal();
    const ids = [...document.querySelectorAll('[id]')].map(el => el.id).filter(id => id !== 'skills');
    expect(new Set(ids).size).toBe(ids.length);
    expect(screen.getAllByRole('tablist')).toHaveLength(2);
    expect(screen.getAllByRole('tabpanel')).toHaveLength(2);
  });
});
