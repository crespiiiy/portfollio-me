import { useCallback, useSyncExternalStore } from 'react';
import { DESKTOP_HERO_QUERY } from '../lib/desktop-hero';

export function useHeroMediaQuery(query: string) {
  const subscribe = useCallback((notify: () => void) => {
    const media = window.matchMedia(query);
    media.addEventListener('change', notify);
    return () => media.removeEventListener('change', notify);
  }, [query]);
  const snapshot = useCallback(() => typeof window !== 'undefined' && window.matchMedia(query).matches, [query]);
  return useSyncExternalStore(subscribe, snapshot, () => false);
}

export const useDesktopHero = () => useHeroMediaQuery(DESKTOP_HERO_QUERY);
