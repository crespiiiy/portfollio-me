import { useSyncExternalStore } from 'react';
import { isPageIntroReady, subscribeToPageIntro } from '../lib/page-intro';

/** The title stays at zero characters until the preloader's fade has finished. */
export const usePageIntroReady = () => useSyncExternalStore(
  subscribeToPageIntro,
  isPageIntroReady,
  () => true,
);
