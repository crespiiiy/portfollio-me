// ملف مُولَّد — بيانات المعرض (صور وفيديوات Google Drive).
// لا تُعدّل المعرّفات يدويًا: كل معرّف هو ملف عام على Drive (anyone with link → Reader).

export interface GalleryPhoto { id: string; group: string; }
export interface GalleryVideo { id: string; }

const DRIVE = {
  // lh3: رابط مباشر (بلا تحويل 302) → أسرع وأقل عرضة لحدّ الطلبات
  image: (id: string, w = 800) => `https://lh3.googleusercontent.com/d/${id}=w${w}`,
  full:  (id: string, w = 1600) => `https://lh3.googleusercontent.com/d/${id}=w${w}`,
  poster:(id: string, w = 1200) => `https://lh3.googleusercontent.com/d/${id}=w${w}`,
  // احتياطي: نقطة thumbnail الرسمية (تعمل عبر تحويل 302)
  thumb: (id: string, w = 800) => `https://drive.google.com/thumbnail?id=${id}&sz=w${w}`,
  // تدفّق الفيديو
  // confirm=t ضروري للملفات الكبيرة (>~25MB) وإلا يعيد Drive صفحة تحذير HTML
  stream:(id: string) => `https://drive.usercontent.google.com/download?id=${id}&export=download&confirm=t`,
  streamAlt:(id: string) => `https://drive.google.com/uc?export=download&id=${id}&confirm=t`,
  view:  (id: string) => `https://drive.google.com/file/d/${id}/view`,
  embed: (id: string) => `https://drive.google.com/file/d/${id}/preview`,
};

export const driveUrls = DRIVE;

export const PHOTO_GROUPS = [
  { id: "ac_campaigns", title: "Air Conditioning Campaigns", titleAr: "حملات التكييف" },
  { id: "perfume_beauty", title: "Perfume & Beauty", titleAr: "العطور والتجميل" },
  { id: "fmcg_packaging", title: "Packaging & FMCG", titleAr: "التغليف والمنتجات" },
  { id: "food_beverage", title: "Food & Beverage", titleAr: "الأطعمة والمشروبات" },
  { id: "social_design", title: "Social Media Design", titleAr: "تصميم السوشيال ميديا" },
  { id: "jewelry", title: "Jewelry & Accessories", titleAr: "المجوهرات والإكسسوارات" },
] as const;

export const PHOTOS: GalleryPhoto[] = [
  // Air Conditioning Campaigns — 30
  { id: "1iHm8DuggpShhT7RAlbt-8dXQZf9mmH5v", group: "ac_campaigns" },
  { id: "1rBJjNS9qcEt40BwZI42e3i_3N4232O-K", group: "ac_campaigns" },
  { id: "16VgVs-LOSTFXt4o9WCn5Wxlbyu1Wnwtw", group: "ac_campaigns" },
  { id: "1uP7olo8BgXG215LbmgIZOgy6XhF97Ftn", group: "ac_campaigns" },
  { id: "1GVAGaBEwHW0PyA6ptd1Swh3gNdT7VZXv", group: "ac_campaigns" },
  { id: "1hvPnUKoFVgTreAD1FdFxYzsdAUTCuha8", group: "ac_campaigns" },
  { id: "1VxXKDlTFald3z20DccN7DhKKt2_GuXU0", group: "ac_campaigns" },
  { id: "1E7646IfZsnFdTETyLna556Ub-3DjBDJZ", group: "ac_campaigns" },
  { id: "1Vz3vUxBQMp9K4nJdqigcooOYWw8TYx04", group: "ac_campaigns" },
  { id: "1OrPiTaKD-bVWN7eLE9ph2bpCDOWThmLX", group: "ac_campaigns" },
  { id: "1f_D62_sKRBKvqS6kkOOQ9yESzIHj8xxl", group: "ac_campaigns" },
  { id: "15FgzlbNwokpVTEe1fzz8WSkz8x-h2Pu8", group: "ac_campaigns" },
  { id: "1NJN96bT8sFSZfxBvg56JKIpgnq2QPwPA", group: "ac_campaigns" },
  { id: "1YeRW7vFQYwKhuxy3Fdn3IYrFm66q_loC", group: "ac_campaigns" },
  { id: "1KmCqC_KpemhblePEjuJwUbmDPhJby9gq", group: "ac_campaigns" },
  { id: "110jIHwtHp0e9gZM8ynxggQwA9LtToqk3", group: "ac_campaigns" },
  { id: "1S8ldGZW2p9lTS1SFieaWBqhcQjgu4VbP", group: "ac_campaigns" },
  { id: "1ssYvoX5RaM1AYcR24hPieV6Y212uxeYt", group: "ac_campaigns" },
  { id: "1fEJeVc5x_awwayirXOvixkxITDgDEe5v", group: "ac_campaigns" },
  { id: "1AYcj-2uAVNy5JSseXdS1NmcQ_W_6a9TJ", group: "ac_campaigns" },
  { id: "1HsoCfhHyEREuB1SDTS436A3lpeiWJc3f", group: "ac_campaigns" },
  { id: "1JUHEplxx7XQWXJEBW_qSJv29nkSfmszS", group: "ac_campaigns" },
  { id: "1ZQtR7AjfFqQ1J9kKyZ8S31UsIkAqRyQT", group: "ac_campaigns" },
  { id: "1-XCVh0CLbC2RFIBBNRI2bNncrUnw4bnl", group: "ac_campaigns" },
  { id: "1UdRfDAj9cFzKK4hnXs3CAJuMGWyQM4ow", group: "ac_campaigns" },
  { id: "1-7wXMr9DCWJQkQsW37FrptflywCd4H4o", group: "ac_campaigns" },
  { id: "1iGiAt_liCRJVVRD2nm47TjNnw8vnLil1", group: "ac_campaigns" },
  { id: "1WJ-vhsYN8nIn9TibACTipE8kLWzjqhbY", group: "ac_campaigns" },
  { id: "1Lz2UghLvPdZLE8A7-i2m0mVKx-PrT2Uz", group: "ac_campaigns" },
  { id: "14chlcsrXgEyJuzk6APyn3TaVNojsQfrX", group: "ac_campaigns" },
  // Perfume & Beauty — 25
  { id: "1di_eEcZg6ouSmEyDgJTsRaRQCU-avHy5", group: "perfume_beauty" },
  { id: "12ysP4G6ktjOgy62nTH2SFqpQxKHrtE9B", group: "perfume_beauty" },
  { id: "15hivWtENvw7tjwkfFvEVxLseTfGPmYdz", group: "perfume_beauty" },
  { id: "1bXBS8ut1ECyRtpZ1Ferf3HA006sw8eM-", group: "perfume_beauty" },
  { id: "1I8PL2FA2BSEDk83EfQ-785yxJ8NB_Tox", group: "perfume_beauty" },
  { id: "1J19i1YqcOhLMTkrlv8NV__uQfFVCWdOu", group: "perfume_beauty" },
  { id: "1fY6-HZijPTHNLhLU4RF5n3b4HNjMjtAx", group: "perfume_beauty" },
  { id: "1OqFuNKQsOs1JKojS54xubRR1vJ34aD8c", group: "perfume_beauty" },
  { id: "15EZaHU7L1ZQ-iG9TrR-3HIr-2EoOGlio", group: "perfume_beauty" },
  { id: "1zXeo5glMDh-k-EM9inLqMuRWtWKqx8ti", group: "perfume_beauty" },
  { id: "10AJ25GE4M5e1sAxZvWXNFUEhuriE1kI6", group: "perfume_beauty" },
  { id: "1J-hrnyNHNW2-9fhQI2RJm7F_ZvTbemCY", group: "perfume_beauty" },
  { id: "1AgbXQxqEDC3u8g65SY3K6NO2wfszv8ix", group: "perfume_beauty" },
  { id: "1fjwH8yDDTrp0W4VbGA5Lb1t427YGG43V", group: "perfume_beauty" },
  { id: "12c0YGNXyWfXBgDvCr9d5TaCN1A-383UY", group: "perfume_beauty" },
  { id: "1mQHd_XjNhoOEAmmbUek8_1qGGpEGsouk", group: "perfume_beauty" },
  { id: "1u1BcH_HNyO2JzkdOUrwykoEMBoaTbM2Q", group: "perfume_beauty" },
  { id: "1dj6S7AJXtUnMiV4zgWGt_FiUpqu1AOuA", group: "perfume_beauty" },
  { id: "17MJUU96auDLyEzg1Qo9VhftG1x0zode6", group: "perfume_beauty" },
  { id: "1HFyTZJuZ5-I7ekw3IFi-kBvjwTS3-V9M", group: "perfume_beauty" },
  { id: "1Gq3Z9vn332rZ9e-aMnq61-ThskXfj6f2", group: "perfume_beauty" },
  { id: "1ISX1rKYfuROBl5ORfVmMrW0FMFO2jr0E", group: "perfume_beauty" },
  { id: "1rl_szpDxOBJYlz6jjZQs68hrHSCh3-dQ", group: "perfume_beauty" },
  { id: "1pvr1HV_UoS03x_s_NfFDT4_O3Uqmjmd2", group: "perfume_beauty" },
  { id: "11w6Z_f8SzSrles5l7mpfL2Fjywjd_QYO", group: "perfume_beauty" },
  // Packaging & FMCG — 13
  { id: "196gSlNesjjSib5Msad9o8YIGltxqRIql", group: "fmcg_packaging" },
  { id: "1TuW-TKrcfMWWe1LXYSvf7dNWQMRVZVia", group: "fmcg_packaging" },
  { id: "1hwPpIokxDM9_iRs35YFDU7BWPBpcRjoi", group: "fmcg_packaging" },
  { id: "1TznCvMUiPtu5NPI72zGly0KiNZdehv03", group: "fmcg_packaging" },
  { id: "1iULVog9NrO4X9jhAlWNGInDOMLeufOMi", group: "fmcg_packaging" },
  { id: "1vs1arasZeH8yDovYp-YDTuupyc5vXKpp", group: "fmcg_packaging" },
  { id: "12hLQ2phdGelCPpyrxVeNHyhksrLmnc1_", group: "fmcg_packaging" },
  { id: "1KKxYhp1XsWHxPSJUAALoFbkzKcMixsSJ", group: "fmcg_packaging" },
  { id: "134Joxq6Z7Q6rSRRsfnJMdfiz4cZrx0k1", group: "fmcg_packaging" },
  { id: "1EK7XUbEIsPKxRzP5PXhHjKhnhGa4qagO", group: "fmcg_packaging" },
  { id: "1xrTBAqBiX0jLA04fORT32UeM68SYH5iD", group: "fmcg_packaging" },
  { id: "1mQzcHHIQgrTUGQXHdy9rHyhdvWLvse-U", group: "fmcg_packaging" },
  { id: "1ZFf4dKVn-Ov9NxpJKWvHbaJN-WxCBFqQ", group: "fmcg_packaging" },
  // Food & Beverage — 8
  { id: "1UoaezlZq_fdYsy0D3FRI17XgbzqqJZqu", group: "food_beverage" },
  { id: "1MtTOm0YZCMIt7t9W8YIF_xv5Fjyx1DIY", group: "food_beverage" },
  { id: "10z11cBUVC69zgT1UkRDWEGfosebD5eo1", group: "food_beverage" },
  { id: "1v5HkooiwzpqQDclovkFXG0RdY_NXdJy6", group: "food_beverage" },
  { id: "1euB3k6G0GE4nvD0iPAi7fgWOT6v2TMZP", group: "food_beverage" },
  { id: "1wocGLmPYgy4mzEbbqtVwzD3oWeJE0V1E", group: "food_beverage" },
  { id: "1mDpOTj98EfnISquWAGC-9azlQPaI238S", group: "food_beverage" },
  { id: "1wQQC_-byFYMJSntCZEwPUpKvBsGk81u0", group: "food_beverage" },
  // Social Media Design — 9
  { id: "1ZFdurVp8fkvosxf7DmAGlPZBkq3YZlcg", group: "social_design" },
  { id: "1CbueXnqKWMoi_hUEGIFx_09mjJWaUT-w", group: "social_design" },
  { id: "1e2r8febwAT4XQlTfNczdJSIF-XKAavnL", group: "social_design" },
  { id: "1QmRzp_2ofIkqDnl1lMD0P2qhuqlxa1WE", group: "social_design" },
  { id: "11UUUqMMw1_oii0UEcrmLVSzfIW_WPLbJ", group: "social_design" },
  { id: "16qJZ_dJJ7hb6Q57XGBrCRGZYqGRY3Zjo", group: "social_design" },
  { id: "1zn-0ZOFjhZAO0V2a6xW9TZVp05V2tOdq", group: "social_design" },
  { id: "1CktMrXiShqJM9UHS-b7natK1ztCYYp6J", group: "social_design" },
  { id: "1FRzvUzSRrhaiF3ksR5_LzTjWFKmyU9fQ", group: "social_design" },
  // Jewelry & Accessories — 4
  { id: "1j2KjIcy8aRypnDhpLBdIJowJfNE20F8i", group: "jewelry" },
  { id: "1nEgJNzuLPHWsBEJgZuISj5Sq8tAe_-Zu", group: "jewelry" },
  { id: "1oMedBwrnnZykdJGlVaZgTOKJGUhqdwkJ", group: "jewelry" },
  { id: "13E_JmL6f0fDe2bEWgyx38BUtw0Us5LOu", group: "jewelry" },
];

export const VIDEOS: GalleryVideo[] = [
  { id: "16zHcUXOJYgRmvM8JL1FZz86JRJet7EXR" }, // Night Drive / Car Spot
  { id: "1yEnUgFfC1hIxqY-LBjvyGG7eIO-1QmRV" }, // Gourmet Burger
  { id: "1WJNYf8xRSSNFBE5O6Gtb_NJr9GdXnG8b" }, // Jaguar Desert
  { id: "1l0oym92s7KhikBjLgOf0z-FMz9BwYQwN" }, // KitKat Impact
  { id: "1QJdQaJfv47Zf8-VGqEOgQOBxR0BH77_R" }, // Porsche vs Mustang
];

// ── فيديوهات Neon Motion (نفس معرّفات موقع neon-motion — عامة على Drive) ──
export interface GalleryVideoFull extends GalleryVideo {
  group: string;
  titleEn: string;
  titleAr: string;
}

export const VIDEO_GROUPS = [
  { id: "nm_motion",  title: "Motion Graphics", titleAr: "موشن جرافيك" },
  { id: "nm_saas",    title: "SaaS Videos",    titleAr: "فيديوهات SaaS" },
  { id: "nm_collage", title: "Collage Edits",  titleAr: "كولاج" },
  { id: "nm_reel",    title: "Reels",          titleAr: "ريلز" },
  { id: "ai_custom",  title: "AI Ads",         titleAr: "إعلانات AI" },
] as const;

export const VIDEO_ITEMS: GalleryVideoFull[] = [
  { id: "12m1KE3ogWhA_NYD95S9M7BV-_RbmN2uT", group: "nm_motion", titleEn: "Car Safety — Motion Graphics", titleAr: "سلامة السيارات — موشن جرافيك" },
  { id: "1iSTvVzWdk1i91Tfqp0zlbuDF4rEhpRN6", group: "nm_motion", titleEn: "Car Station — Motion Graphics", titleAr: "محطة السيارات — موشن جرافيك" },
  { id: "1qQWjXBmEp1PD4bkZRnFT35nO97HvzxGt", group: "nm_motion", titleEn: "Ibram — Motion Graphics", titleAr: "إبرام — موشن جرافيك" },
  { id: "1bxGq4vNY6usT8olsSCmVKPVuBM51u2Fe", group: "nm_motion", titleEn: "Gate of Success — Motion Graphics", titleAr: "بوابة النجاح — موشن جرافيك" },
  { id: "15gChdsUFpmJrqNJOhVdU0lM_D0ZDugq0", group: "nm_saas", titleEn: "Tamheer — App UI Video", titleAr: "تمهير — فيديو واجهة تطبيق" },
  { id: "10fCFfx0oJLz-io7Isn0HgtHgbzqKJzEe", group: "nm_saas", titleEn: "Sprinat — App UI Video", titleAr: "سبرينات — فيديو واجهة تطبيق" },
  { id: "1QpYfpsTmNOtyZq99zat7NEVds_dRI4-n", group: "nm_saas", titleEn: "Serve — App UI Video", titleAr: "سيرف — فيديو واجهة تطبيق" },
  { id: "1wGLsaPa2R8CJ3-lhzDzh9E6vf48bGoG5", group: "nm_saas", titleEn: "SecretHost — Promo", titleAr: "سيكريت هوست — برومو" },
  { id: "1vdgeq0-ZLVEHu45viMoAIfyrZpyJBBc1", group: "nm_collage", titleEn: "Deer — Collage", titleAr: "الغزال — كولاج" },
  { id: "1Mo7t6HN4ESwa4B0CmhrHM1jdZ0A8u1Sx", group: "nm_collage", titleEn: "Sprinat — Collage", titleAr: "سبرينات — كولاج" },
  { id: "1q5mU6xpXG0nE-e72tUvNBL8QXG53WmrH", group: "nm_collage", titleEn: "Treek — Collage", titleAr: "تريك — كولاج" },
  { id: "1tlP7De_bOAipb82gHiMmO17e6o5t-TM3", group: "nm_reel", titleEn: "Noadina — App Promo Reel", titleAr: "نوعادينا — ريل برومو تطبيق" },
  { id: "18dVp_TdGQ2BavMhmJX5CUZIYadUcS9jr", group: "nm_reel", titleEn: "Creative Hub — Meme Reel", titleAr: "كرييتف هب — ريل ميم" },
  { id: "1Vh4rZlUaIMKR8KZVsKfLlqUTWndQfW4f", group: "nm_reel", titleEn: "Creative Hub — Campaign Reel", titleAr: "كريتيف هب — ريل حملة" },
  { id: "1DIEJVItKmbeLS_T3GI7JMtGc7LrCtp7A", group: "nm_reel", titleEn: "Nail Health Facts — Reel", titleAr: "حقائق صحة الأظافر — ريل" },
  { id: "16zHcUXOJYgRmvM8JL1FZz86JRJet7EXR", group: "ai_custom", titleEn: "Night Drive — Cinematic Car Spot", titleAr: "إعلان سينمائي — سيارة ليلية" },
  { id: "1yEnUgFfC1hIxqY-LBjvyGG7eIO-1QmRV", group: "ai_custom", titleEn: "Gourmet Burger — Product Ad", titleAr: "إعلان منتج — برجر شهي" },
  { id: "1WJNYf8xRSSNFBE5O6Gtb_NJr9GdXnG8b", group: "ai_custom", titleEn: "Jaguar Desert — Panther Campaign", titleAr: "حملة جاكوار — الفهد والصحراء" },
  { id: "1l0oym92s7KhikBjLgOf0z-FMz9BwYQwN", group: "ai_custom", titleEn: "KitKat Impact — Chocolate Ad", titleAr: "إعلان كيت كات — لحظة الانفجار" },
  { id: "1QJdQaJfv47Zf8-VGqEOgQOBxR0BH77_R", group: "ai_custom", titleEn: "Porsche vs Mustang — Road Race", titleAr: "بورش ضد الحصان — سباق الطريق" },
];
