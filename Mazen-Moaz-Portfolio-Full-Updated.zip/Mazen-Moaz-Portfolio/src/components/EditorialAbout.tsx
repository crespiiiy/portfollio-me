import { useEffect, useId, useRef, useState, type KeyboardEvent } from 'react';
import { ArrowUpRight, Plus } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useHeroMediaQuery } from '../hooks/useDesktopHero';
import { HERO_REDUCED_MOTION_QUERY } from '../lib/desktop-hero';
import identityArtwork from '../assets/about-identity.webp';
import './EditorialAbout.css';

const principles = ['execution', 'precision', 'scale', 'reliability'] as const;

/** Small real SVG diagrams, not a video of somebody else's interface. */
function PrincipleDiagram({ kind }: { kind: typeof principles[number] }) {
  return (
    <svg className="about-principle-diagram" viewBox="0 0 190 65" fill="none" aria-hidden="true">
      {kind === 'execution' && <>
        <path className="about-diagram-track" d="M23 33H165" />
        <path className="about-diagram-signal" d="M23 33H165" />
        {[23, 94, 165].map((x, i) => <g key={x}>
          <rect x={x - 16} y="17" width="32" height="32" rx="10" className="about-diagram-node" />
          {i === 0 ? <path d="m21 25-5 9h7l-2 8 9-12h-7l2-5" className="about-diagram-mark" />
            : i === 1 ? <path d="m90 27-5 6 5 6m8-12 5 6-5 6" className="about-diagram-mark" />
            : <path d="m158 33 5 5 9-11" className="about-diagram-mark" />}
        </g>)}
      </>}
      {kind === 'precision' && <>
        <path className="about-diagram-track" d="M23 12v42m47-42v42m47-42v42m47-42v42M15 20h160M15 45h160" />
        <path className="about-diagram-mark" d="M29 44C52 45 56 21 92 21s43 23 67 23" />
        {[29, 92, 159].map((x, i) => <rect key={x} x={x - 3} y={i === 1 ? 18 : 41} width="6" height="6" className="about-diagram-handle" />)}
        <path className="about-diagram-signal" d="M29 44C52 45 56 21 92 21s43 23 67 23" />
      </>}
      {kind === 'scale' && <>
        <path className="about-diagram-track" d="M36 33h30m0 0V13h37m-37 20h37m-37 0v20h37M137 13h18m-18 20h18m-18 20h18" />
        <rect x="9" y="20" width="28" height="26" rx="8" className="about-diagram-node" />
        {[5, 25, 45].map(y => <g key={y}>
          <rect x="103" y={y} width="35" height="16" rx="5" className="about-diagram-node" />
          <circle cx="112" cy={y + 8} r="2" className="about-diagram-light" />
          <path d={`M120 ${y + 8}h10`} className="about-diagram-track" />
        </g>)}
        <path className="about-diagram-signal" d="M36 33h30V13h37" />
      </>}
      {kind === 'reliability' && <>
        <path className="about-diagram-track" d="M8 17h174M8 33h174M8 49h174" />
        <path className="about-diagram-mark" d="M9 34h26l9-8 9 16 13-28 13 39 12-22h19l9-10 10 18 11-5h40" />
        <path className="about-diagram-signal" d="M9 34h26l9-8 9 16 13-28 13 39 12-22h19l9-10 10 18 11-5h40" />
        <circle cx="178" cy="34" r="3" className="about-diagram-light" />
      </>}
    </svg>
  );
}

/** Mounted only for desktop/fine-pointer visitors; mobile keeps its exact old About. */
export default function EditorialAbout({ onContact }: { onContact: () => void }) {
  const { t, i18n } = useTranslation();
  const rtl = i18n.dir() === 'rtl';
  const reducedMotion = useHeroMediaQuery(HERO_REDUCED_MOTION_QUERY);
  const root = useRef<HTMLElement>(null);
  const buttons = useRef<(HTMLButtonElement | null)[]>([]);
  const id = useId();
  const [active, setActive] = useState<number | null>(0);
  const [entered, setEntered] = useState(false);
  const [inView, setInView] = useState(false);
  const [pageVisible, setPageVisible] = useState(() => !document.hidden);

  useEffect(() => {
    const visibility = () => setPageVisible(!document.hidden);
    document.addEventListener('visibilitychange', visibility);
    const observer = typeof IntersectionObserver === 'undefined' ? null : new IntersectionObserver(entries => {
      const visible = entries[0]?.isIntersecting ?? false;
      setInView(visible);
      if (visible) setEntered(true);
    }, { threshold: 0.08 });
    if (observer && root.current) observer.observe(root.current);
    else { setEntered(true); setInView(true); }
    return () => {
      observer?.disconnect();
      document.removeEventListener('visibilitychange', visibility);
    };
  }, []);

  const navigatePrinciples = (event: KeyboardEvent<HTMLButtonElement>, index: number) => {
    let next: number;
    if (event.key === 'ArrowDown') next = (index + 1) % principles.length;
    else if (event.key === 'ArrowUp') next = (index + principles.length - 1) % principles.length;
    else if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = principles.length - 1;
    else return;
    event.preventDefault();
    buttons.current[next]?.focus();
  };

  return (
    <section
      id="about"
      ref={root}
      className="about-editorial"
      data-desktop-editorial=""
      data-entered={entered || reducedMotion}
      data-motion={inView && pageVisible && !reducedMotion ? 'running' : 'paused'}
      aria-labelledby={`${id}-title`}
      dir={rtl ? 'rtl' : 'ltr'}
    >
      <div className="about-editorial-inner">
        <header className="about-editorial-heading about-editorial-reveal">
          <div>
            <div className="about-editorial-eyebrow"><span aria-hidden="true">01</span><i aria-hidden="true" />{t('about_subtitle')}</div>
            <h2 id={`${id}-title`} aria-label={t('about_title')}>
              <span>{t('about_editorial_title_start')}</span>
              <span className="about-editorial-title-accent">{t('about_editorial_title_end')}</span>
            </h2>
          </div>
          <div className="about-editorial-heading-note">
            <svg viewBox="0 0 32 32" aria-hidden="true"><path d="M16 0c1 11 5 15 16 16-11 1-15 5-16 16C15 21 11 17 0 16 11 15 15 11 16 0Z" fill="currentColor" /></svg>
            <p>{t('about_editorial_note_start')}<br /><span>{t('about_editorial_note_end')}</span></p>
          </div>
        </header>

        <div className="about-editorial-layout">
          <div className="about-editorial-story about-editorial-reveal">
            <div className="about-editorial-bio">
              <p>{t('about_paragraph1')}</p>
              <p>{t('about_paragraph2')}</p>
            </div>
            <ul className="about-editorial-specialties" aria-label={t('about_editorial_specialties_label')}>
              <li>{t('skill_automation')}</li>
              <li>{t('skill_bot_development')}</li>
              <li>{t('service_graphic_design_title')}</li>
            </ul>

            <div className="about-editorial-principles" role="group" aria-label={t('about_editorial_principles_label')}>
              {principles.map((kind, index) => {
                const open = active === index;
                return (
                  <div className={`about-principle${open ? ' is-active' : ''}`} key={kind}>
                    <h3>
                      <button
                        ref={element => { buttons.current[index] = element; }}
                        type="button"
                        id={`${id}-principle-${index}`}
                        aria-expanded={open}
                        aria-controls={`${id}-panel-${index}`}
                        onClick={() => setActive(current => current === index ? null : index)}
                        onKeyDown={event => navigatePrinciples(event, index)}
                      >
                        <span className="about-principle-number" aria-hidden="true">0{index + 1}</span>
                        <span className="about-principle-title">{t(`about_feature${index + 1}_title`)}</span>
                        <span className="about-principle-toggle" aria-hidden="true"><Plus size={16} /></span>
                      </button>
                    </h3>
                    <div
                      className="about-principle-panel"
                      id={`${id}-panel-${index}`}
                      role="region"
                      aria-labelledby={`${id}-principle-${index}`}
                      aria-hidden={!open}
                    >
                      <div className="about-principle-panel-inner">
                        <div className="about-principle-content">
                          <p>{t(`about_feature${index + 1}_desc`)}</p>
                          <PrincipleDiagram kind={kind} />
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <aside className="about-identity-card about-editorial-reveal" aria-label={t('about_editorial_profile_label')}>
            <div className="about-identity-visual">
              <img src={identityArtwork} alt="" aria-hidden="true" loading="lazy" decoding="async" width="896" height="1120" />
              <div className="about-identity-art-shade" />
              <div className="about-identity-topline" aria-hidden="true"><span>MM / 01</span><span className="about-identity-orbit"><i /><i /><i /></span></div>
              <div className="about-identity-discipline"><span />{t('about_editorial_focus')}</div>
            </div>
            <div className="about-identity-content">
              <p className="about-identity-name" dir="ltr">Mazen Moaz<span aria-hidden="true">✳</span></p>
              <p className="about-identity-role">{t('about_editorial_role')}</p>
              <dl className="about-identity-stats">
                <div><dt>{t('about_experience_badge')}</dt><dd dir="ltr">7<span>+</span></dd></div>
                <div><dt>{t('hero_projects_delivered')}</dt><dd dir="ltr">50<span>+</span></dd></div>
              </dl>
              <button type="button" className="about-editorial-contact" onClick={onContact}>
                <span>{t('about_editorial_cta')}</span><span className="about-editorial-contact-icon"><ArrowUpRight size={20} aria-hidden="true" /></span>
              </button>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}
