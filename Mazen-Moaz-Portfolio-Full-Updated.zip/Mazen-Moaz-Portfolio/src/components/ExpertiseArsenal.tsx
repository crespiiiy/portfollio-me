import { useEffect, useId, useRef, useState, type CSSProperties, type KeyboardEvent } from 'react';
import { ArrowUpRight, Layers3, type LucideIcon } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useHeroMediaQuery } from '../hooks/useDesktopHero';
import { HERO_REDUCED_MOTION_QUERY } from '../lib/desktop-hero';
import { ARSENAL_CAPABILITIES, ARSENAL_TECHNOLOGIES } from '../lib/expertise';
import coreArtwork from '../assets/arsenal-core.webp';
import './ExpertiseArsenal.css';

type ArsenalSkill = { name: string; level: number; icon: LucideIcon; color: string };

/** Original desktop toolkit explorer. The original Skills branch still serves phones. */
export default function ExpertiseArsenal({ skills }: { skills: ArsenalSkill[] }) {
  const { t, i18n } = useTranslation();
  const rtl = i18n.dir() === 'rtl';
  const reducedMotion = useHeroMediaQuery(HERO_REDUCED_MOTION_QUERY);
  const root = useRef<HTMLElement>(null);
  const tabs = useRef<(HTMLButtonElement | null)[]>([]);
  const id = `arsenal-${useId().replace(/:/g, '')}`;
  const [active, setActive] = useState(0);
  const [entered, setEntered] = useState(false);
  const [inView, setInView] = useState(false);
  const [pageVisible, setPageVisible] = useState(() => !document.hidden);
  const selected = skills[active] ?? skills[0];
  const capability = ARSENAL_CAPABILITIES[active] ?? ARSENAL_CAPABILITIES[0];
  const related = new Set<string>(capability.tools);

  useEffect(() => {
    const visibility = () => setPageVisible(!document.hidden);
    document.addEventListener('visibilitychange', visibility);
    const observer = typeof IntersectionObserver === 'undefined' ? null : new IntersectionObserver(entries => {
      const visible = entries[0]?.isIntersecting ?? false;
      setInView(visible);
      if (visible) setEntered(true);
    }, { threshold: 0.08 });
    if (observer && root.current) observer.observe(root.current);
    else { setEntered(true); setInView(true); }
    return () => { observer?.disconnect(); document.removeEventListener('visibilitychange', visibility); };
  }, []);

  const navigate = (event: KeyboardEvent<HTMLButtonElement>, index: number) => {
    let next: number;
    if (event.key === 'ArrowRight') next = (index + (rtl ? -1 : 1) + skills.length) % skills.length;
    else if (event.key === 'ArrowLeft') next = (index + (rtl ? 1 : -1) + skills.length) % skills.length;
    else if (event.key === 'Home') next = 0;
    else if (event.key === 'End') next = skills.length - 1;
    else return;
    event.preventDefault();
    setActive(next);
    tabs.current[next]?.focus();
  };

  if (!selected) return null;
  const SelectedIcon = selected.icon;

  return (
    <section
      id="skills"
      ref={root}
      className="arsenal-section"
      dir={rtl ? 'rtl' : 'ltr'}
      data-desktop-arsenal=""
      data-entered={entered || reducedMotion}
      data-motion={inView && pageVisible && !reducedMotion ? 'running' : 'paused'}
      aria-labelledby={`${id}-title`}
      style={{ '--arsenal-accent': capability.accent } as CSSProperties}
    >
      <div className="arsenal-inner">
        <header className="arsenal-heading arsenal-reveal">
          <div>
            <div className="arsenal-eyebrow"><span aria-hidden="true">02</span><i aria-hidden="true" />{t('skills_subtitle')}</div>
            <h2 id={`${id}-title`} aria-label={t('skills_title')}>
              <span>{t('arsenal_title_start')}</span>{' '}<span className="arsenal-title-accent">{t('arsenal_title_end')}</span>
            </h2>
          </div>
          <div className="arsenal-heading-note">
            <Layers3 size={24} strokeWidth={1.15} aria-hidden="true" />
            <p>{t('arsenal_note_start')}<br /><span>{t('arsenal_note_end')}</span></p>
          </div>
        </header>

        <div className="arsenal-workbench arsenal-reveal">
          <div className="arsenal-capabilities" role="tablist" aria-label={t('arsenal_capabilities_label')}>
            {skills.map((skill, index) => {
              const Icon = skill.icon;
              const current = active === index;
              return (
                <button
                  key={ARSENAL_CAPABILITIES[index].id}
                  ref={element => { tabs.current[index] = element; }}
                  type="button"
                  role="tab"
                  id={`${id}-tab-${index}`}
                  aria-selected={current}
                  aria-controls={`${id}-panel`}
                  aria-label={`${skill.name} — ${skill.level}%`}
                  tabIndex={current ? 0 : -1}
                  className={`arsenal-capability${current ? ' is-selected' : ''}`}
                  style={{ '--capability-accent': ARSENAL_CAPABILITIES[index].accent } as CSSProperties}
                  onClick={() => setActive(index)}
                  onKeyDown={event => navigate(event, index)}
                >
                  <span className="arsenal-capability-top"><Icon size={20} strokeWidth={1.45} aria-hidden="true" /><span aria-hidden="true">0{index + 1}</span></span>
                  <span className="arsenal-capability-name">{skill.name}</span>
                  <span className="arsenal-capability-bottom"><span dir="ltr">{skill.level}%</span><ArrowUpRight size={15} aria-hidden="true" /></span>
                </button>
              );
            })}
          </div>

          <div className="arsenal-detail" role="tabpanel" id={`${id}-panel`} aria-labelledby={`${id}-tab-${active}`} tabIndex={0}>
            <div className="arsenal-summary">
              <div className="arsenal-summary-top"><span>{t('arsenal_selected_capability')}</span><span className="arsenal-selected-icon"><SelectedIcon size={20} strokeWidth={1.35} aria-hidden="true" /></span></div>
              <h3>{selected.name}</h3>
              <p className="arsenal-description">{t(capability.description)}</p>
              <div className="arsenal-proficiency">
                <div className="arsenal-proficiency-label"><span>{t('arsenal_proficiency')}</span><span dir="ltr">{selected.level}<small>%</small></span></div>
                <div className="arsenal-meter" role="meter" aria-label={`${selected.name} — ${t('arsenal_proficiency')}`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={selected.level} aria-valuetext={`${selected.level}%`}>
                  <span style={{ width: `${selected.level}%` }} />
                </div>
              </div>
            </div>

            <div className="arsenal-system" dir="ltr">
              <div className="arsenal-system-grid" aria-hidden="true" />
              <div className="arsenal-system-topline" aria-hidden="true"><span>MM / TOOLKIT</span><span>0{active + 1} — 06</span></div>
              <svg className="arsenal-connections" viewBox="0 0 100 100" preserveAspectRatio="none" fill="none" aria-hidden="true">
                {ARSENAL_TECHNOLOGIES.map((technology, index) => {
                  const row = index % 6;
                  const y = 15 + row * 14;
                  const left = index < 6;
                  const path = `M50 50 C${left ? 33 : 67} 50, ${left ? 34 : 66} ${y}, ${left ? 18 : 82} ${y}`;
                  return <g key={technology.name} className={related.has(technology.name) ? 'is-associated' : ''}>
                    <path d={path} pathLength={100} className="arsenal-connection-track" />
                    <path d={path} pathLength={100} className="arsenal-connection-signal" />
                  </g>;
                })}
              </svg>
              <div className="arsenal-core" aria-hidden="true">
                <div className="arsenal-core-aura" />
                <img src={coreArtwork} alt="" loading="lazy" decoding="async" width="768" height="768" />
              </div>
              <ul className="arsenal-toolkit" aria-label={t('skills_tech_stack_title')}>
                {ARSENAL_TECHNOLOGIES.map((technology, index) => {
                  const associated = related.has(technology.name);
                  return (
                    <li
                      key={technology.name}
                      className={`arsenal-tool${associated ? ' is-associated' : ''}`}
                      data-tool={technology.name}
                      data-side={index < 6 ? 'left' : 'right'}
                      data-associated={associated}
                      style={{ top: `${15 + (index % 6) * 14}%` }}
                    >
                      <span className="arsenal-tool-mark" aria-hidden="true">{technology.mark}</span>
                      <span className="arsenal-tool-name">{technology.name}</span>
                      {associated && <span className="arsenal-sr-only"> — {t('arsenal_related_technologies')}</span>}
                    </li>
                  );
                })}
              </ul>
              <h4 className="arsenal-system-caption">{t('skills_tech_stack_title')}</h4>
            </div>
          </div>
          <div className="arsenal-workbench-footer"><span><i aria-hidden="true" />{t('arsenal_select_hint')}</span><span>{t('arsenal_toolkit_hint')}</span></div>
        </div>
      </div>
    </section>
  );
}
