import { useEffect, useRef, useState } from 'react';
import { useDesktopHero, useHeroMediaQuery } from '../hooks/useDesktopHero';
import { usePageIntroReady } from '../hooks/usePageIntroReady';
import { DESKTOP_HERO_POSTER, DESKTOP_HERO_VIDEO, HERO_REDUCED_MOTION_QUERY } from '../lib/desktop-hero';
import './DesktopHeroVideo.css';

/** Decorative, automatic scenery: no controls, audio or reference-site lettering. */
export default function DesktopHeroVideo({ isRTL = false }: { isRTL?: boolean }) {
  const desktop = useDesktopHero();
  const reducedMotion = useHeroMediaQuery(HERO_REDUCED_MOTION_QUERY);
  const introReady = usePageIntroReady();
  const container = useRef<HTMLDivElement>(null);
  const video = useRef<HTMLVideoElement>(null);
  const [inView, setInView] = useState(true);
  const [pageVisible, setPageVisible] = useState(() => typeof document === 'undefined' || !document.hidden);
  const [frameReady, setFrameReady] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [failed, setFailed] = useState(false);
  const shouldPlay = desktop && !reducedMotion && introReady && inView && pageVisible && !failed;

  useEffect(() => {
    if (!desktop) return;
    const visibility = () => setPageVisible(!document.hidden);
    document.addEventListener('visibilitychange', visibility);
    const observer = typeof IntersectionObserver === 'undefined' ? null : new IntersectionObserver(
      entries => setInView(entries[0]?.isIntersecting ?? true), { threshold: 0.01 },
    );
    if (container.current) observer?.observe(container.current);
    return () => {
      document.removeEventListener('visibilitychange', visibility);
      observer?.disconnect();
    };
  }, [desktop]);

  useEffect(() => {
    const element = video.current;
    if (!element) return;
    let active = true;
    const attemptPlayback = () => {
      if (!active || !shouldPlay) return;
      element.muted = true;
      element.defaultMuted = true;
      // A browser policy rejection is not a permanent pause. Retry quietly when
      // data becomes available or on the next ordinary page interaction.
      element.play()?.catch(() => { /* Keep the clean poster; no playback UI. */ });
    };
    if (shouldPlay) attemptPlayback();
    else element.pause();
    element.addEventListener('canplay', attemptPlayback);
    element.addEventListener('loadeddata', attemptPlayback);
    window.addEventListener('focus', attemptPlayback);
    document.addEventListener('pointerdown', attemptPlayback, { passive: true });
    document.addEventListener('keydown', attemptPlayback);
    return () => {
      active = false;
      element.removeEventListener('canplay', attemptPlayback);
      element.removeEventListener('loadeddata', attemptPlayback);
      window.removeEventListener('focus', attemptPlayback);
      document.removeEventListener('pointerdown', attemptPlayback);
      document.removeEventListener('keydown', attemptPlayback);
      element.pause();
    };
  }, [shouldPlay]);

  // Do not even mount an image/video source on phones: no hidden mobile download.
  if (!desktop) return null;
  const state = failed ? 'fallback' : reducedMotion ? 'reduced-motion'
    : !shouldPlay ? 'suspended' : playing ? 'playing' : 'loading';

  return (
    <div ref={container} className="hero-cinema" data-desktop-cinema="" data-video-state={state} data-cinema-direction={isRTL ? 'rtl' : 'ltr'} aria-hidden="true">
      <div className="hero-cinema-scene" style={{ backgroundImage: `url("${DESKTOP_HERO_POSTER}")` }}>
        {!reducedMotion && !failed && (
          <video
            ref={video}
            className={`hero-cinema-video${frameReady ? ' is-frame-ready' : ''}`}
            src={DESKTOP_HERO_VIDEO}
            poster={DESKTOP_HERO_POSTER}
            autoPlay={shouldPlay}
            controls={false}
            controlsList="nodownload nofullscreen noremoteplayback"
            loop
            muted
            playsInline
            preload="auto"
            disablePictureInPicture
            disableRemotePlayback
            tabIndex={-1}
            onLoadedData={() => setFrameReady(true)}
            onPlay={() => setPlaying(true)}
            onPause={() => setPlaying(false)}
            onError={() => { setFailed(true); setPlaying(false); }}
          />
        )}
        <div className="hero-cinema-scrim" />
      </div>
    </div>
  );
}
