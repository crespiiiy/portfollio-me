import { memo, useEffect, useMemo, useState } from 'react';
import { usePageIntroReady } from '../hooks/usePageIntroReady';
import './TypewriterHeadline.css';

type TypewriterHeadlineProps = {
  firstLine: string;
  accentLine: string;
  lastLine: string;
  direction: 'ltr' | 'rtl';
};

// Keep connected Arabic letters in a single text node, not separate letter spans.
const letters = (text: string) => Array.from(text);

/** A one-shot, layout-stable introduction. A reload or language change replays it. */
const TypewriterHeadline = memo(function TypewriterHeadline({
  firstLine,
  accentLine,
  lastLine,
  direction,
}: TypewriterHeadlineProps) {
  const introReady = usePageIntroReady();
  const lines = useMemo(() => {
    let lineOffset = 0;
    return [firstLine, accentLine, lastLine].map((text, index) => {
      let wordOffset = 0;
      const tokens = text.split(/(\s+)/).filter(Boolean).map((word) => {
        const characters = letters(word);
        const token = { text: word, characters, start: wordOffset, isSpace: /^\s+$/.test(word) };
        wordOffset += characters.length;
        return token;
      });
      const line = { text, index, tokens, start: lineOffset, length: letters(text).length };
      lineOffset += line.length;
      return line;
    }).filter((line) => line.length > 0);
  }, [firstLine, accentLine, lastLine]);

  const total = lines.reduce((sum, line) => sum + line.length, 0);
  const [reducedMotion, setReducedMotion] = useState(
    () => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches,
  );
  const [typed, setTyped] = useState(() => reducedMotion ? total : 0);

  useEffect(() => {
    const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
    const updatePreference = () => setReducedMotion(preference.matches);
    updatePreference();
    preference.addEventListener('change', updatePreference);
    return () => preference.removeEventListener('change', updatePreference);
  }, []);

  useEffect(() => {
    if (!introReady) {
      setTyped(0);
      return;
    }
    if (reducedMotion) {
      setTyped(total);
      return;
    }

    setTyped(0);
    let position = 0;
    let timer: ReturnType<typeof setTimeout>;
    const lineEnds = new Set(lines.map((line) => line.start + line.length));
    const allCharacters = lines.flatMap((line) => letters(line.text));

    const typeNext = () => {
      position += 1;
      setTyped(position);
      if (position >= total) return;

      // A gentle, deterministic cadence with a short breath between lines.
      const delay = lineEnds.has(position) ? 210
        : allCharacters[position] === ' ' ? 80
        : 43 + (position * 7 % 24);
      timer = setTimeout(typeNext, delay);
    };

    if (total > 0) timer = setTimeout(typeNext, 320);
    return () => clearTimeout(timer);
  }, [introReady, lines, reducedMotion, total]);

  const complete = reducedMotion || typed >= total;
  const activeLine = lines.findIndex((line) => typed <= line.start + line.length);

  return (
    <h1
      className="hero-typewriter text-4xl sm:text-5xl md:text-7xl font-bold leading-tight break-words"
      dir={direction}
      aria-label={lines.map((line) => line.text).join(' ')}
      data-typewriter-state={!introReady ? 'paused' : complete ? 'complete' : typed === 0 ? 'waiting' : 'typing'}
      data-character-count={!introReady ? 0 : reducedMotion ? total : typed}
      data-total-characters={total}
    >
      {lines.map((line, lineIndex) => {
        const visible = !introReady ? 0 : reducedMotion ? line.length : Math.max(0, Math.min(line.length, typed - line.start));
        const words = line.tokens.filter((token) => !token.isSpace);
        const cursorWord = [...words].reverse().find((token) => token.start < visible) || words[0];

        return (
          <span
            key={line.index}
            className={`hero-typewriter-line block ${line.index < 2 ? 'mb-2 md:mb-4' : ''}`}
            aria-hidden="true"
            data-typed-text={letters(line.text).slice(0, visible).join('')}
          >
            {line.tokens.map((token, tokenIndex) => token.isSpace ? (
              <span key={tokenIndex}>{token.text}</span>
            ) : (
              <span key={tokenIndex} className="hero-typewriter-word">
                {/* Reserve each complete word so wrapping and the CTA never jump. */}
                <span className="hero-typewriter-reserve">{token.text}</span>
                <span className={`hero-typewriter-output ${line.index === 1 ? 'hero-typewriter-accent' : ''}`}>
                  {token.characters.slice(0, Math.max(0, visible - token.start)).join('')}
                  {introReady && !reducedMotion && lineIndex === activeLine && token === cursorWord && (
                    <span className="hero-typewriter-caret" />
                  )}
                </span>
              </span>
            ))}
          </span>
        );
      })}
    </h1>
  );
});

export default TypewriterHeadline;
