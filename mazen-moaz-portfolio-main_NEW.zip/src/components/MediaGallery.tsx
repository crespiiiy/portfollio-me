import React, { useState, useEffect, useCallback, useMemo, useRef, FC } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTranslation } from 'react-i18next';
import {
  X, ChevronLeft, ChevronRight, Maximize2, Download, ExternalLink,
  Play, Pause, Volume2, VolumeX, Images, Film,
} from 'lucide-react';
import { PHOTOS, PHOTO_GROUPS, VIDEOS, VIDEO_ITEMS, VIDEO_GROUPS, driveUrls } from '../data/gallery';

/* ============================================================================
   Neon Motion — Media Gallery
   صور وفيديوات مستضافة على Google Drive (روابط عامة per-file).
   - شبكة موزاييك بأسلوب bento تتكيّف مع العدد
   - فلاتر مجموعات + عارض (lightbox) بلوحة مفاتيح وتنقّل
   - مشغّل فيديو مخصّص: poster + play + تحكّم كامل
   ========================================================================== */

const EASE = [0.22, 1, 0.36, 1] as const;

const Fonts = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap');
  `}</style>
);

/* ---------------------------------- أدوات --------------------------------- */

const useIsRTL = (lang?: string) => (lang ?? 'en').startsWith('ar');

/** أول N صورة بحجم أكبر في الشبكة لإعطاء إيقاع بصري (bento) */
const featureFlags = (count: number) =>
  new Set(Array.from({ length: count }, (_, i) => i).filter(i => i % 7 === 0 || i % 11 === 3));


/* -------------------- صورة Drive بسلسلة احتياطي -------------------- */
/**
 * Drive يحدّ الطلبات (429) ويصدر صفحات HTML عند التقييد، فيرفضها المتصفح (ORB).
 * الحل: referrerPolicy="no-referrer" + إعادة محاولة متدرّجة + تبديل النمط.
 */
type DriveImageProps = {
  id: string;
  width?: number;
  alt: string;
  className?: string;
  eager?: boolean;
  onReady?: () => void;
};

const ATTEMPTS = 4;               // 2 محاولات لكل نمط
const RETRY_MS = [0, 900, 2500, 5000];

export const DriveImage: FC<DriveImageProps> = ({
  id, width = 800, alt, className = '', eager = false, onReady,
}) => {
  const [attempt, setAttempt] = useState(0);
  const [done, setDone] = useState(false);
  const [giveUp, setGiveUp] = useState(false);
  const [nonce, setNonce] = useState(0);   // لكسر الكاش عند إعادة المحاولة

  const useThumb = attempt >= 2;           // النمط الرسمي في المحاولات المتأخرة
  const src = useThumb ? driveUrls.thumb(id, width) : driveUrls.image(id, width);

  const handleError = () => {
    if (attempt + 1 >= ATTEMPTS) { setGiveUp(true); return; }
    const delay = RETRY_MS[Math.min(attempt + 1, RETRY_MS.length - 1)];
    window.setTimeout(() => {
      setAttempt(a => a + 1);
      setNonce(n => n + 1);
    }, delay);
  };

  const retry = () => { setGiveUp(false); setAttempt(0); setNonce(n => n + 1); };

  return (
    <>
      {!done && !giveUp && (
        <span className="absolute inset-0 animate-pulse bg-[linear-gradient(110deg,rgba(255,255,255,0.06),rgba(255,255,255,0.02))]" />
      )}

      {giveUp ? (
        <button
          type="button"
          onClick={retry}
          className="absolute inset-0 grid place-items-center gap-1 bg-white/[0.03] text-slate-500 hover:text-indigo-300 transition-colors"
          aria-label="reload"
        >
          <Images size={24} />
        </button>
      ) : (
        <img
          key={`${src}#${nonce}`}
          src={src}
          alt={alt}
          loading={eager ? 'eager' : 'lazy'}
          decoding="async"
          referrerPolicy="no-referrer"
          onLoad={() => { setDone(true); onReady?.(); }}
          onError={handleError}
          className={`${className} transition-opacity duration-700 ${done ? 'opacity-100' : 'opacity-0'}`}
        />
      )}
    </>
  );
};

/* ============================== شبكة الصور =============================== */

interface PhotoGridProps {
  onOpen: (index: number) => void;
  lang?: string;
}

export const PhotoGallery: FC<PhotoGridProps> = ({ onOpen, lang }) => {
  const { t } = useTranslation();
  const isRTL = useIsRTL(lang);
  const [active, setActive] = useState<string>('all');
  const [visible, setVisible] = useState(12);
  const [loaded, setLoaded] = useState<Record<string, boolean>>({});

  const filtered = useMemo(
    () => (active === 'all' ? PHOTOS : PHOTOS.filter(p => p.group === active)),
    [active],
  );

  useEffect(() => { setVisible(12); }, [active]);

  const featured = useMemo(() => featureFlags(filtered.length), [filtered.length]);
  const shown = filtered.slice(0, visible);

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: PHOTOS.length };
    PHOTOS.forEach(p => { map[p.group] = (map[p.group] ?? 0) + 1; });
    return map;
  }, []);

  return (
    <div className="w-full">
      <Fonts />

      {/* ------- فلاتر ------- */}
      <div
        className="flex flex-wrap items-center justify-center gap-2 mb-10"
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        {[{ id: 'all', label: t('gallery_all') }, ...PHOTO_GROUPS.map(g => ({
          id: g.id,
          label: isRTL ? g.titleAr : g.title,
        }))].map(g => {
          const selected = active === g.id;
          return (
            <motion.button
              key={g.id}
              onClick={() => setActive(g.id)}
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.96 }}
              className={`relative px-4 py-2 rounded-full text-xs sm:text-sm font-semibold border transition-colors duration-300 ${
                selected
                  ? 'text-white border-transparent'
                  : 'text-slate-300 border-white/10 bg-white/[0.03] hover:border-indigo-400/40 hover:text-white'
              }`}
            >
              {selected && (
                <motion.span
                  layoutId="gallery-chip"
                  transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                  className="absolute inset-0 rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 shadow-lg shadow-indigo-500/30"
                />
              )}
              <span className="relative z-10 flex items-center gap-1.5">
                {g.label}
                <span className={`text-[10px] tabular-nums ${selected ? 'text-white/70' : 'text-slate-500'}`}>
                  {counts[g.id] ?? 0}
                </span>
              </span>
            </motion.button>
          );
        })}
      </div>

      {/* ------- الشبكة ------- */}
      <motion.div
        layout
        className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 auto-rows-[9rem] sm:auto-rows-[11rem] lg:auto-rows-[12.5rem] gap-3 sm:gap-4 [grid-auto-flow:dense]"
        dir={isRTL ? 'rtl' : 'ltr'}
      >
        <AnimatePresence mode="popLayout">
          {shown.map((photo, i) => {
            const big = featured.has(i);
            return (
              <motion.button
                key={photo.id}
                layout
                initial={{ opacity: 0, scale: 0.94, y: 14 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.94 }}
                transition={{ duration: 0.45, ease: EASE, delay: Math.min(i * 0.02, 0.3) }}
                onClick={() => onOpen(PHOTOS.indexOf(photo))}
                aria-label={`${t('gallery_view')} ${i + 1}`}
                className={`group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.03] text-start focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 ${
                  big ? 'sm:col-span-2 sm:row-span-2' : ''
                }`}
              >
                {/* هالة نيون تظهر عند المرور */}
                <span className="pointer-events-none absolute -inset-px rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-br from-indigo-500/50 via-violet-500/30 to-cyan-400/40 blur-[10px]" />

                <DriveImage
                  id={photo.id}
                  width={big ? 1600 : 800}
                  alt={`${isRTL ? 'عمل تصميمي' : 'Design work'} ${i + 1}`}
                  eager={i < 6}
                  className="relative h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
                />

                <span className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400" />

                <span className="absolute inset-x-0 bottom-0 p-3 flex items-center justify-between translate-y-3 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-400">
                  <span className="text-[11px] font-semibold tracking-wide text-white/90 uppercase">
                    {isRTL
                      ? PHOTO_GROUPS.find(g => g.id === photo.group)?.titleAr
                      : PHOTO_GROUPS.find(g => g.id === photo.group)?.title}
                  </span>
                  <span className="grid place-items-center w-8 h-8 rounded-full bg-white/90 text-slate-900">
                    <Maximize2 size={14} />
                  </span>
                </span>
              </motion.button>
            );
          })}
        </AnimatePresence>
      </motion.div>

      {/* ------- تحميل المزيد ------- */}
      {visible < filtered.length && (
        <div className="mt-12 text-center">
          <motion.button
            whileHover={{ y: -2 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => setVisible(v => v + 12)}
            className="inline-flex items-center gap-2 px-7 py-3 rounded-full border border-white/15 bg-white/[0.04] text-white text-sm font-semibold hover:border-indigo-400/50 hover:bg-white/[0.07] transition-colors"
          >
            <Images size={16} className="text-indigo-400" />
            {t('gallery_load_more')}
            <span className="text-slate-500 tabular-nums">
              {filtered.length - visible}
            </span>
          </motion.button>
        </div>
      )}
    </div>
  );
};

/* ============================== معرض الفيديو ============================== */

interface VideoCardProps {
  video: { id: string; group: string; titleEn: string; titleAr: string };
  index: number;
  lang?: string;
  onOpen: (index: number) => void;
}

const VideoCard: FC<VideoCardProps> = ({ video, index, lang, onOpen }) => {
  const { t } = useTranslation();
  const isRTL = useIsRTL(lang);
  const [hovering, setHovering] = useState(false);
  const [ready, setReady] = useState(false);

  const title = isRTL ? video.titleAr : video.titleEn;

  return (
    <motion.article
      initial={{ opacity: 0, y: 26 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.6, ease: EASE, delay: Math.min(index * 0.08, 0.4) }}
      onMouseEnter={() => setHovering(true)}
      onMouseLeave={() => setHovering(false)}
      className="group relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-b from-white/[0.06] to-white/[0.02] backdrop-blur-xl"
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      <span className="pointer-events-none absolute -inset-px rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-br from-indigo-500/40 via-violet-500/20 to-cyan-400/30 blur-[12px]" />

      <div className="relative aspect-video overflow-hidden bg-black">
        {/* المعاينة: صورة poster من Drive + توهج نيون — لا تحميل فيديو قبل الطلب (توفير بيانات) */}
        <DriveImage
          id={video.id}
          width={1200}
          alt={title}
          onReady={() => setReady(true)}
          className={`h-full w-full object-cover transition-transform duration-[900ms] ease-out ${hovering ? 'scale-105' : 'scale-100'}`}
        />
        <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/85 via-black/15 to-black/5" />

        {/* زر التشغيل */}
        <button
          onClick={() => onOpen(index)}
          aria-label={t('video_play')}
          className="absolute inset-0 grid place-items-center focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-400 rounded-3xl"
        >
          <motion.span
            animate={hovering ? { scale: 1.08 } : { scale: 1 }}
            transition={{ duration: 0.35, ease: EASE }}
            className="relative grid place-items-center w-16 h-16 rounded-full bg-white/95 text-slate-900 shadow-2xl shadow-indigo-500/40"
          >
            <span className="absolute inset-0 rounded-full bg-indigo-400/60 blur-xl animate-pulse" />
            <Play size={22} className="relative ms-0.5 fill-current" />
          </motion.span>
        </button>

        <span className="absolute top-3 end-3 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/55 backdrop-blur-md border border-white/15 text-[10px] font-semibold text-white/85 uppercase tracking-wider">
          <Film size={11} className="text-indigo-300" />
          {isRTL
            ? VIDEO_GROUPS.find(g => g.id === video.group)?.titleAr
            : VIDEO_GROUPS.find(g => g.id === video.group)?.title}
        </span>
      </div>

      <div className="p-5">
        <h3 className="text-lg font-bold text-white group-hover:text-indigo-300 transition-colors">
          {title}
        </h3>

        <button
          onClick={() => onOpen(index)}
          className="mt-4 inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-300 hover:text-white transition-colors"
        >
          {t('video_watch')}
          <ExternalLink size={12} className={isRTL ? 'rotate-90' : ''} />
        </button>
      </div>
    </motion.article>
  );
};

export const VideoGallery: FC<{ lang?: string; onOpen: (index: number) => void }> = ({
  lang, onOpen,
}) => {
  const { t } = useTranslation();
  const isRTL = useIsRTL(lang);
  const [active, setActive] = useState<string>('all');

  const items = useMemo(
    () => (active === 'all' ? VIDEO_ITEMS : VIDEO_ITEMS.filter(v => v.group === active)),
    [active],
  );

  const counts = useMemo(() => {
    const map: Record<string, number> = { all: VIDEO_ITEMS.length };
    VIDEO_ITEMS.forEach(v => { map[v.group] = (map[v.group] ?? 0) + 1; });
    return map;
  }, []);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-center gap-2 mb-10" dir={isRTL ? 'rtl' : 'ltr'}>
        {[{ id: 'all', title: t('gallery_all'), titleAr: t('gallery_all') },
          ...VIDEO_GROUPS].map(g => {
          const selected = active === g.id;
          return (
            <motion.button
              key={g.id}
              onClick={() => setActive(g.id)}
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.96 }}
              className={`relative px-4 py-2 rounded-full text-xs sm:text-sm font-semibold border transition-colors duration-300 ${
                selected
                  ? 'text-white border-transparent'
                  : 'text-slate-300 border-white/10 bg-white/[0.03] hover:border-indigo-400/40 hover:text-white'
              }`}
            >
              {selected && (
                <motion.span
                  layoutId="video-chip"
                  transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                  className="absolute inset-0 rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 shadow-lg shadow-indigo-500/30"
                />
              )}
              <span className="relative z-10 flex items-center gap-1.5">
                {isRTL ? g.titleAr : g.title}
                <span className={`text-[10px] tabular-nums ${selected ? 'text-white/70' : 'text-slate-500'}`}>
                  {counts[g.id] ?? 0}
                </span>
              </span>
            </motion.button>
          );
        })}
      </div>

      <motion.div layout className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        <AnimatePresence mode="popLayout">
          {items.map((v, i) => (
            <VideoCard
              key={v.id}
              video={v}
              index={VIDEO_ITEMS.indexOf(v)}
              lang={lang}
              onOpen={onOpen}
            />
          ))}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

/* ============================ عارض الصور (Lightbox) ======================= */

export const PhotoLightbox: FC<{
  index: number | null;
  onClose: () => void;
  onNavigate: (index: number) => void;
  lang?: string;
}> = ({ index, onClose, onNavigate, lang }) => {
  const { t } = useTranslation();
  const isRTL = useIsRTL(lang);
  const open = index !== null;
  const photo = open ? PHOTOS[index as number] : null;

  const go = useCallback((dir: number) => {
    if (index === null) return;
    const next = (index + dir + PHOTOS.length) % PHOTOS.length;
    onNavigate(next);
  }, [index, onNavigate]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') go(1);
      if (e.key === 'ArrowLeft') go(-1);
    };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open, go, onClose]);

  return (
    <AnimatePresence>
      {open && photo && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 z-[120] flex items-center justify-center p-4 sm:p-8"
          role="dialog"
          aria-modal="true"
          aria-label={t('gallery_view')}
        >
          <div className="absolute inset-0 bg-[#050407]/95 backdrop-blur-xl" onClick={onClose} />

          {/* أدوات */}
          <div className="absolute top-4 inset-x-4 z-10 flex items-center justify-between gap-3">
            <span className="px-3 py-1.5 rounded-full bg-white/[0.07] border border-white/10 text-xs font-semibold text-slate-300 tabular-nums">
              {(index as number) + 1} / {PHOTOS.length}
            </span>
            <div className="flex items-center gap-2">
              <a
                href={driveUrls.view(photo.id)}
                target="_blank"
                rel="noopener noreferrer"
                className="grid place-items-center w-10 h-10 rounded-full bg-white/[0.07] border border-white/10 text-white hover:bg-white/15 transition-colors"
                aria-label={t('gallery_open_drive')}
              >
                <Download size={17} />
              </a>
              <button
                onClick={onClose}
                className="grid place-items-center w-10 h-10 rounded-full bg-white/[0.07] border border-white/10 text-white hover:bg-white/15 transition-colors"
                aria-label={t('close')}
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* السهمان */}
          {[-1, 1].map(dir => (
            <button
              key={dir}
              onClick={() => go(dir)}
              aria-label={dir === -1 ? t('previous') : t('next')}
              className={`absolute z-10 top-1/2 -translate-y-1/2 grid place-items-center w-11 h-11 rounded-full bg-white/[0.07] border border-white/10 text-white hover:bg-white/20 transition-colors ${
                (dir === -1) !== isRTL ? 'left-3 sm:left-6' : 'right-3 sm:right-6'
              }`}
            >
              {dir === -1 ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
            </button>
          ))}

          {/* الصورة */}
          <AnimatePresence mode="wait">
            <motion.figure
              key={photo.id}
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.32, ease: EASE }}
              className="relative z-[1] max-h-full"
              onClick={e => e.stopPropagation()}
            >
              <div className="relative max-h-[82vh]">
                <DriveImage
                  id={photo.id}
                  width={1600}
                  eager
                  alt={`${isRTL ? 'عمل' : 'Work'} ${(index as number) + 1}`}
                  className="max-h-[82vh] w-auto max-w-full rounded-2xl object-contain shadow-[0_30px_120px_-20px_rgba(99,102,241,0.55)] ring-1 ring-white/10"
                />
              </div>
              <figcaption className="mt-4 text-center text-xs font-medium text-slate-400">
                {isRTL
                  ? PHOTO_GROUPS.find(g => g.id === photo.group)?.titleAr
                  : PHOTO_GROUPS.find(g => g.id === photo.group)?.title}
              </figcaption>
            </motion.figure>
          </AnimatePresence>

          {/* شريط مصغّر */}
          <div className="absolute bottom-4 inset-x-0 z-10 hidden sm:flex justify-center">
            <div className="flex gap-1.5 p-1.5 rounded-2xl bg-black/60 border border-white/10 backdrop-blur-md max-w-[80vw] overflow-x-auto">
              {PHOTOS.slice(
                Math.max(0, Math.min((index as number) - 6, PHOTOS.length - 13)),
                Math.max(0, Math.min((index as number) - 6, PHOTOS.length - 13)) + 13,
              ).map((p, k, arr) => {
                const base = Math.max(0, Math.min((index as number) - 6, PHOTOS.length - 13));
                const realIdx = base + k;
                return (
                  <button
                    key={p.id}
                    onClick={() => onNavigate(realIdx)}
                    className={`relative h-11 w-11 shrink-0 overflow-hidden rounded-lg ring-1 transition-all ${
                      realIdx === index ? 'ring-2 ring-indigo-400' : 'ring-white/10 opacity-60 hover:opacity-100'
                    }`}
                    aria-label={`${k + 1}`}
                  >
                    <DriveImage id={p.id} width={200} alt="" className="h-full w-full object-cover" />
                  </button>
                );
              })}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

/* ============================= عارض الفيديو ============================== */

export const VideoLightbox: FC<{
  index: number | null;
  onClose: () => void;
  onNavigate: (index: number) => void;
  lang?: string;
}> = ({ index, onClose, onNavigate, lang }) => {
  const { t } = useTranslation();
  const isRTL = useIsRTL(lang);
  const open = index !== null;
  const video = open ? VIDEO_ITEMS[index as number] : null;
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(true);
  const [muted, setMuted] = useState(false);
  const [fallback, setFallback] = useState(false);   // مشغّل Drive المدمج عند تعذّر HTML5
  const [srcMode, setSrcMode] = useState<0 | 1>(0);  // 0: /uc  |  1: usercontent

  const src = srcMode === 0 ? driveUrls.stream(video?.id ?? '') : driveUrls.streamAlt(video?.id ?? '');

  const onVideoError = () => {
    if (srcMode === 0) setSrcMode(1);      // جرّب النمط الثاني أولًا
    else setFallback(true);                // ثم اعرض مشغّل Drive
  };

  const go = useCallback((dir: number) => {
    if (index === null) return;
    onNavigate((index + dir + VIDEO_ITEMS.length) % VIDEO_ITEMS.length);
  }, [index, onNavigate]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') go(1);
      if (e.key === 'ArrowLeft') go(-1);
    };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [open, go, onClose]);

  const toggle = () => {
    const el = videoRef.current;
    if (!el) return;
    if (el.paused) { el.play().catch(() => {}); setPlaying(true); }
    else { el.pause(); setPlaying(false); }
  };

  return (
    <AnimatePresence>
      {open && video && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          className="fixed inset-0 z-[120] flex items-center justify-center p-4 sm:p-8"
          role="dialog"
          aria-modal="true"
          aria-label={isRTL ? video.titleAr : video.titleEn}
        >
          <div className="absolute inset-0 bg-[#050407]/95 backdrop-blur-xl" onClick={onClose} />

          <div className="absolute top-4 inset-x-4 z-10 flex items-center justify-between gap-3">
            <span className="px-3 py-1.5 rounded-full bg-white/[0.07] border border-white/10 text-xs font-semibold text-slate-300 tabular-nums">
              {(index as number) + 1} / {VIDEO_ITEMS.length}
            </span>
            <div className="flex items-center gap-2">
              <a
                href={driveUrls.view(video.id)}
                target="_blank"
                rel="noopener noreferrer"
                className="grid place-items-center w-10 h-10 rounded-full bg-white/[0.07] border border-white/10 text-white hover:bg-white/15 transition-colors"
                aria-label={t('gallery_open_drive')}
              >
                <Download size={17} />
              </a>
              <button
                onClick={onClose}
                className="grid place-items-center w-10 h-10 rounded-full bg-white/[0.07] border border-white/10 text-white hover:bg-white/15 transition-colors"
                aria-label={t('close')}
              >
                <X size={18} />
              </button>
            </div>
          </div>

          <motion.div
            key={video.id}
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.35, ease: EASE }}
            className="relative z-[1] w-full max-w-5xl"
            onClick={e => e.stopPropagation()}
            dir={isRTL ? 'rtl' : 'ltr'}
          >
            <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-black shadow-[0_30px_120px_-20px_rgba(99,102,241,0.6)]">
              {fallback ? (
                <iframe
                  src={driveUrls.embed(video.id)}
                  title={isRTL ? video.titleAr : video.titleEn}
                  allow="autoplay; encrypted-media; fullscreen"
                  allowFullScreen
                  className="w-full aspect-video bg-black"
                />
              ) : (
                <video
                  key={src}
                  ref={videoRef}
                  src={src}
                  poster={driveUrls.poster(video.id, 1600)}
                  autoPlay
                  playsInline
                  muted={muted}
                  onPlay={() => setPlaying(true)}
                  onPause={() => setPlaying(false)}
                  onError={onVideoError}
                  className="w-full aspect-video bg-black object-contain"
                />
              )}
              {/* تحكّم مخصّص أدنى */}
              <div className={`absolute inset-x-0 bottom-0 flex items-center gap-3 bg-gradient-to-t from-black/90 to-transparent px-4 pb-3 pt-10 ${fallback ? 'hidden' : ''}`}>
                <button onClick={toggle} aria-label={playing ? t('pause') : t('play')} className="text-white/90 hover:text-white">
                  {playing ? <Pause size={18} /> : <Play size={18} className="fill-current" />}
                </button>
                <button
                  onClick={() => { setMuted(m => !m); if (videoRef.current) videoRef.current.muted = !muted; }}
                  aria-label={muted ? t('unmute') : t('mute')}
                  className="text-white/90 hover:text-white"
                >
                  {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
                </button>
                <div className="flex-1" />
                <button onClick={() => go(1)} className="text-xs font-semibold text-white/80 hover:text-white inline-flex items-center gap-1">
                  {t('next')}
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>

            <div className="mt-5 px-1">
              <h3 className="text-xl sm:text-2xl font-bold text-white">
                {isRTL ? video.titleAr : video.titleEn}
              </h3>
              <p className="mt-1.5 text-sm text-slate-400 leading-relaxed max-w-3xl">
                {isRTL ? video.titleAr : video.titleEn}
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default { PhotoGallery, VideoGallery, PhotoLightbox, VideoLightbox };
