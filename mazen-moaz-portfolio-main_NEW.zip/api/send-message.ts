/**
 * Vercel Serverless Function — POST /api/send-message
 * يستقبل رسائل نموذج التواصل ويبعتها على تليجرام.
 * المتغيرات المطلوبة (Environment Variables على Vercel):
 *   TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
 */

type Body = {
  name?: string;
  contact?: string;
  subject?: string;
  message?: string;
};

const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

export default async function handler(req: any, res: any) {
  // CORS / method guard
  if (req.method === "OPTIONS") {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
    return res.status(204).end();
  }
  if (req.method !== "POST") {
    return res.status(405).json({ ok: false, error: "Method Not Allowed" });
  }

  const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
  const CHAT_ID = process.env.TELEGRAM_CHAT_ID;

  if (!TOKEN || !CHAT_ID) {
    console.error("[send-message] missing env vars", {
      hasToken: Boolean(TOKEN),
      hasChatId: Boolean(CHAT_ID),
    });
    return res
      .status(500)
      .json({ ok: false, error: "Server not configured" });
  }

  // قراءة الجسم (Vercel قد يمرّره كـ object أو string)
  let body: Body = {};
  try {
    body =
      typeof req.body === "string" ? JSON.parse(req.body || "{}") : req.body || {};
  } catch {
    return res.status(400).json({ ok: false, error: "Invalid JSON" });
  }

  const name = String(body.name ?? "").trim().slice(0, 200);
  const contact = String(body.contact ?? "").trim().slice(0, 200);
  const subject = String(body.subject ?? "").trim().slice(0, 300);
  const message = String(body.message ?? "").trim().slice(0, 4000);

  // تحقّق أساسي
  if (!name || !contact || !message) {
    return res
      .status(400)
      .json({ ok: false, error: "name, contact and message are required" });
  }
  // حماية بسيطة من السبام: أي محاولة إرسال روابط كثيرة جدًا
  if ((message.match(/https?:\/\//gi) || []).length > 5) {
    return res.status(400).json({ ok: false, error: "Too many links" });
  }

  const now = new Date().toLocaleString("en-GB", {
    timeZone: "Africa/Cairo",
    dateStyle: "medium",
    timeStyle: "short",
  });

  const text =
    `🚀 <b>New Inquiry — Portfolio</b>\n` +
    `━━━━━━━━━━━━━━━━━━\n` +
    `👤 <b>Name:</b> ${esc(name)}\n` +
    `📱 <b>Contact:</b> ${esc(contact)}\n` +
    (subject ? `📌 <b>Subject:</b> ${esc(subject)}\n` : ``) +
    `━━━━━━━━━━━━━━━━━━\n` +
    `💬 ${esc(message)}\n` +
    `━━━━━━━━━━━━━━━━━━\n` +
    `🕐 ${esc(now)} (Cairo)`;

  try {
    const tg = await fetch(
      `https://api.telegram.org/bot${TOKEN}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: CHAT_ID,
          text,
          parse_mode: "HTML",
          disable_web_page_preview: true,
        }),
      }
    );
    const data = await tg.json();

    if (!tg.ok || !data.ok) {
      console.error("[send-message] telegram error", data);
      return res
        .status(502)
        .json({ ok: false, error: "Telegram rejected the message" });
    }
    return res.status(200).json({ ok: true, messageId: data.result?.message_id });
  } catch (err) {
    console.error("[send-message] network error", err);
    return res.status(502).json({ ok: false, error: "Network error" });
  }
}
