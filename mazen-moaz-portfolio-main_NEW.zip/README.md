# Mazen Moaz — Portfolio

موقع بورتفوليو شخصي — تسويق رقمي، أتمتة بالذكاء الاصطناعي، وتصميم جرافيك.

**الموقع المباشر:** https://mazenmoaz.vercel.app

---

## ⚡ التشغيل السريع

```bash
npm install          # تثبيت الحزم (مرة واحدة)
npm run dev          # تشغيل محلي → http://localhost:8080
npm run build        # بناء للإنتاج → مجلد dist/
npm run preview      # معاينة نسخة الإنتاج محليًا
```

> إن واجهت مشكلة في `npm install`، جرّب: `npm ci`

---

## 🚀 النشر

المشروع منشور على **Vercel** باسم `portfollio`.

### الطريقة الأولى — عبر CLI
```bash
npx vercel --prod
```

### الطريقة الثانية — عبر Git
```bash
git add .
git commit -m "update"
git push
```
Vercel بينشر تلقائيًا عند كل push.

### ⚠️ متغيّرات البيئة المطلوبة
لازم تُضاف في Vercel → Settings → Environment Variables:

| المتغير | الوصف |
|---|---|
| `TELEGRAM_BOT_TOKEN` | توكن بوت تليجرام (@BotFather) |
| `TELEGRAM_CHAT_ID` | الـ Chat ID اللي هيستقبل الرسايل |

**بدونهم نموذج التواصل هيرجع خطأ 500.**

---

## 📁 بنية المشروع

```
├── api/
│   └── send-message.ts      ← Vercel Function: يبعت رسائل الفورم لتليجرام
├── public/
│   ├── robots.txt           ← تعليمات محركات البحث
│   ├── sitemap.xml          ← خريطة الموقع
│   ├── og-image.jpg         ← صورة المشاركة الاجتماعية 1200×630
│   └── google9a67...html    ← ملف التحقق من Google Search Console
├── src/
│   ├── assets/              ← 10 صور مشاريع + هيرو + لوجو
│   ├── components/
│   │   ├── PremiumPortfolio.tsx  ← المكوّن الرئيسي (كل الصفحة)
│   │   ├── MediaGallery.tsx      ← معرض الصور والفيديوهات
│   │   └── ChatBotWidget.tsx     ← الشات بوت
│   ├── data/
│   │   └── gallery.ts       ← صور المعرض + 20 فيديو
│   └── locales/
│       ├── ar.json          ← الترجمة العربية (182 مفتاح)
│       └── en.json          ← الترجمة الإنجليزية (182 مفتاح)
├── index.html               ← SEO + JSON-LD + محتوى احتياطي
└── vercel.json              ← إعدادات النشر
```

---

## ✏️ التعديلات الشائعة

### تغيير الفيديوهات
`src/data/gallery.ts` → مصفوفة `VIDEO_ITEMS`

```ts
{ id: "DRIVE_FILE_ID", group: "nm_motion", titleEn: "...", titleAr: "..." }
```

الفئات: `nm_motion` · `nm_saas` · `nm_collage` · `nm_reel` · `ai_custom`

### تغيير صور المشاريع
`src/assets/` — الأسماء لازم تطابق الاستيرادات في `PremiumPortfolio.tsx`

### تغيير النصوص
`src/locales/en.json` و `src/locales/ar.json` — **لازم يكونوا نفس عدد المفاتيح**

### تغيير بيانات SEO
`index.html` — العنوان، الوصف، JSON-LD، وروابط og

---

## ✅ المميزات

- 🌐 عربي/إنجليزي مع دعم RTL كامل
- 📱 متجاوب بالكامل
- 📨 نموذج تواصل → يبعت على تليجرام
- 🖼️ 10 مشاريع بصور حقيقية
- 🎬 20 فيديو مع فلترة بالفئات
- 🔍 SEO كامل: JSON-LD، sitemap، OG image، 318 كلمة في HTML
- ⚡ Vite + React + TypeScript + Tailwind

---

## ⚠️ ملاحظة أمنية

`.env` في المشروع فيه **قيم افتراضية (placeholders)** مش توكن حقيقي — متحطّش التوكن الحقيقي فيه.
التوكن الصحيح بيتحط في Vercel Environment Variables فقط.

---

**آخر تحديث:** 9 نوفمبر 2026
