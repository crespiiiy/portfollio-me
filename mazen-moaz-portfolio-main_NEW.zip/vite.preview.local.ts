import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";

// ملف محلي للاختبار فقط (غير مُسلَّم) — يسمح باستضافة المعاينة
export default defineConfig({
  preview: { host: "0.0.0.0", port: 8200, strictPort: true, allowedHosts: true },
  plugins: [react()],
  resolve: { alias: { "@": path.resolve(__dirname, "./src") } },
});
